/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        // ClaimForge Design Tokens
        forest: {
          DEFAULT: '#123F3A',
          50: '#F2F7F6',
          100: '#E4EFEB',
          200: '#C7DFD7',
          300: '#9EBEB4',
          700: '#17524B',
          800: '#154842',
          900: '#123F3A',
          950: '#0A2421',
        },
        primary: {
          DEFAULT: '#16856B',
          50: '#EBF7F4',
          100: '#D7F0E9',
          200: '#B0E1D4',
          500: '#1CB08E',
          600: '#16856B',
          700: '#126B56',
          800: '#0E5242',
          900: '#0A3B2F',
        },
        mint: {
          DEFAULT: '#E6F4EF',
          light: '#F4FAF7',
          dark: '#CCE7DC',
        },
        surface: {
          warm: '#FAFAF7',
          muted: '#F1F3F2',
          border: '#E1E7E4',
          card: '#FFFFFF',
        },
        ink: {
          DEFAULT: '#202B2A',
          primary: '#202B2A',
          secondary: '#687573',
          muted: '#8E9C99',
          faint: '#BAC4C2',
        },
        gold: {
          DEFAULT: '#C39B4A',
          subtle: '#FDF8EC',
          border: '#ECD8A5',
          text: '#8E6B1D',
        },
        coral: {
          DEFAULT: '#D87568',
          subtle: '#FCF3F1',
          border: '#F4CAC5',
          text: '#A64336',
        },
        // Legacy compatibility
        teal: {
          50: '#f0fdfa',
          100: '#ccfbf1',
          200: '#99f6e4',
          300: '#5eead4',
          400: '#2dd4bf',
          500: '#14b8a6',
          600: '#16856B',
          700: '#123F3A',
          800: '#115e59',
          900: '#123F3A',
          950: '#0A2421',
        },
      },
      fontFamily: {
        sans: ['Inter', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto', 'sans-serif'],
        mono: ['JetBrains Mono', 'ui-monospace', 'SFMono-Regular', 'Menlo', 'Monaco', 'monospace'],
      },
      boxShadow: {
        'subtle': '0 1px 3px 0 rgba(18, 63, 58, 0.04), 0 1px 2px -1px rgba(18, 63, 58, 0.04)',
        'card': '0 1px 3px rgba(18, 63, 58, 0.06), 0 1px 2px rgba(18, 63, 58, 0.04)',
        'elevated': '0 4px 6px -1px rgba(18, 63, 58, 0.07), 0 2px 4px -2px rgba(18, 63, 58, 0.05)',
      },
    },
  },
  plugins: [],
};
