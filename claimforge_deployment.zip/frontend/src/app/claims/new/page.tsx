'use client';

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import {
  Upload,
  FileText,
  X,
  AlertCircle,
  CheckCircle2,
  ArrowRight,
  ArrowLeft,
  Sparkles,
  RefreshCw,
  Plus,
  ShieldAlert,
  Info,
  Layers,
  FileCheck
} from 'lucide-react';
import { api } from '@/lib/api';

interface StagedFile {
  file: File;
  type: string;
}

export default function NewClaimWizard() {
  const router = useRouter();

  // Wizard Step State (1: Claim Info, 2: Denial Details, 3: Documents, 4: Review & Submit)
  const [currentStep, setCurrentStep] = useState<number>(1);

  // Form Fields - Step 1: Claim Info
  const [claimReference, setClaimReference] = useState('CLM-2026-' + Math.floor(1000 + Math.random() * 9000));
  const [patientReference, setPatientReference] = useState('PAT-' + Math.floor(100 + Math.random() * 900));
  const [insurerName, setInsurerName] = useState('BlueShield Horizon');
  const [claimAmount, setClaimAmount] = useState('4850.00');
  const [policyNumber, setPolicyNumber] = useState('POL-' + Math.floor(10000 + Math.random() * 90000));
  const [dateOfService, setDateOfService] = useState('2026-02-14');

  // Form Fields - Step 2: Denial Details
  const [rejectionReason, setRejectionReason] = useState('Claim denied: Missing prior authorization for inpatient surgical admission.');
  const [rejectionCode, setRejectionCode] = useState('CO-197');
  const [reviewPriority, setReviewPriority] = useState<'low' | 'medium' | 'high' | 'urgent'>('high');
  const [reviewerNotes, setReviewerNotes] = useState('');

  // Form Fields - Step 3: Documents
  const [stagedFiles, setStagedFiles] = useState<StagedFile[]>([]);
  const [isDragging, setIsDragging] = useState(false);

  // Submission State
  const [submitting, setSubmitting] = useState(false);
  const [createdClaimId, setCreatedClaimId] = useState<string | null>(null);
  const [statusMessage, setStatusMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Validation
  const isStep1Valid = Boolean(
    claimReference.trim() &&
    patientReference.trim() &&
    insurerName.trim() &&
    parseFloat(claimAmount) > 0
  );

  const isStep2Valid = Boolean(rejectionReason.trim());

  const handleAddFiles = (fileList: FileList | null) => {
    if (!fileList) return;
    const added: StagedFile[] = Array.from(fileList).map((file) => {
      let defaultType = 'other';
      const name = file.name.toLowerCase();
      if (name.includes('bill') || name.includes('invoice') || name.includes('charge')) defaultType = 'medical_bill';
      else if (name.includes('discharge') || name.includes('summary')) defaultType = 'discharge_summary';
      else if (name.includes('denial') || name.includes('eob') || name.includes('rejection')) defaultType = 'denial_letter';
      else if (name.includes('mri') || name.includes('report') || name.includes('lab') || name.includes('diag')) defaultType = 'diagnostic_report';
      else if (name.includes('rx') || name.includes('prescription')) defaultType = 'prescription';
      else if (name.includes('auth')) defaultType = 'pre_auth';

      return { file, type: defaultType };
    });
    setStagedFiles((prev) => [...prev, ...added]);
  };

  const removeFile = (index: number) => {
    setStagedFiles((prev) => prev.filter((_, i) => i !== index));
  };

  const updateFileType = (index: number, newType: string) => {
    setStagedFiles((prev) =>
      prev.map((item, i) => (i === index ? { ...item, type: newType } : item))
    );
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    handleAddFiles(e.dataTransfer.files);
  };

  const handleSubmit = async () => {
    setSubmitting(true);
    setErrorMessage(null);

    try {
      let targetClaimId = createdClaimId;

      // 1. Create Claim Record (if not already created)
      if (!targetClaimId) {
        setStatusMessage('Creating claim case record in database...');
        const createdClaim = await api.createClaim({
          claim_reference: claimReference.trim(),
          patient_reference: patientReference.trim(),
          insurer_name: insurerName.trim(),
          claim_amount: parseFloat(claimAmount),
          rejection_reason: rejectionReason.trim(),
          rejection_code: rejectionCode.trim() || undefined,
          policy_number: policyNumber.trim() || undefined,
          date_of_service: dateOfService || undefined,
          review_priority: reviewPriority,
          reviewer_notes: reviewerNotes.trim() || undefined,
        });
        targetClaimId = createdClaim.id;
        setCreatedClaimId(createdClaim.id);
      }

      // 2. Upload Staged Documents
      if (stagedFiles.length > 0) {
        for (let i = 0; i < stagedFiles.length; i++) {
          setStatusMessage(`Extracting document ${i + 1} of ${stagedFiles.length}: ${stagedFiles[i].file.name}...`);
          await api.uploadDocument(targetClaimId, stagedFiles[i].file, stagedFiles[i].type);
        }
      }

      // 3. Trigger Cross-Document Analysis
      setStatusMessage('Running cross-document verification & computing Appeal Readiness Score...');
      await api.triggerAnalysis(targetClaimId);

      // 4. Redirect to Document Intelligence Workspace
      setStatusMessage('Analysis complete! Redirecting to case file...');
      router.push(`/claims/${targetClaimId}`);
    } catch (err: any) {
      console.error('Intake failed:', err);
      setErrorMessage(err.message || String(err));
      setSubmitting(false);
    }
  };

  const docTypes = [
    { value: 'medical_bill', label: 'Itemized Medical Bill (UB-04 / HCFA)' },
    { value: 'discharge_summary', label: 'Clinical Discharge / Operative Note' },
    { value: 'diagnostic_report', label: 'Diagnostic / Pathology / MRI Report' },
    { value: 'denial_letter', label: 'Denial Letter / EOB Determination' },
    { value: 'prescription', label: 'Prescription / Pharmacy Order' },
    { value: 'pre_auth', label: 'Prior Authorization Record' },
    { value: 'other', label: 'Other Clinical Supporting Record' },
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Wizard Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#E1E7E4] pb-5">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-[#202B2A]">
            New Claim Intake Wizard
          </h1>
          <p className="text-xs text-[#687573] mt-0.5">
            Ingest insurance claim determination, attach medical records, and trigger cross-document entity verification.
          </p>
        </div>

        <Link
          href="/dashboard"
          className="text-xs font-semibold text-[#687573] hover:text-[#202B2A] flex items-center gap-1"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back to Dashboard</span>
        </Link>
      </div>

      {/* 4-Step Progress Indicator */}
      <div className="grid grid-cols-4 gap-2 bg-white p-3 rounded-xl border border-[#E1E7E4] shadow-xs text-xs font-semibold">
        {[
          { num: 1, label: 'Claim Details' },
          { num: 2, label: 'Denial Reason' },
          { num: 3, label: 'Upload Evidence' },
          { num: 4, label: 'Review & Run' },
        ].map((s) => {
          const isDone = currentStep > s.num;
          const isCurrent = currentStep === s.num;

          return (
            <button
              key={s.num}
              type="button"
              onClick={() => {
                if (s.num === 1) setCurrentStep(1);
                else if (s.num === 2 && isStep1Valid) setCurrentStep(2);
                else if (s.num === 3 && isStep1Valid && isStep2Valid) setCurrentStep(3);
                else if (s.num === 4 && isStep1Valid && isStep2Valid) setCurrentStep(4);
              }}
              className={`flex items-center gap-2 px-2 py-1.5 rounded-lg transition-colors text-left ${
                isCurrent
                  ? 'bg-[#E6F4EF] text-[#123F3A] border border-[#B0E1D4]'
                  : isDone
                  ? 'text-[#16856B] hover:bg-[#F1F3F2]'
                  : 'text-[#8E9C99] cursor-not-allowed'
              }`}
            >
              <span
                className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0 ${
                  isCurrent
                    ? 'bg-[#123F3A] text-white'
                    : isDone
                    ? 'bg-[#16856B] text-white'
                    : 'bg-[#F1F3F2] text-[#687573]'
                }`}
              >
                {isDone ? '✓' : s.num}
              </span>
              <span className="hidden sm:inline truncate">{s.label}</span>
            </button>
          );
        })}
      </div>

      {/* Error Alert */}
      {errorMessage && (
        <div className="p-4 bg-[#FCF3F1] border border-[#F4CAC5] rounded-xl text-xs text-[#A64336] flex items-start gap-2.5">
          <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
          <div className="flex-1 space-y-1">
            <div><strong>Intake Error:</strong> {errorMessage}</div>
            {createdClaimId && (
              <div className="pt-1">
                <Link
                  href={`/claims/${createdClaimId}`}
                  className="font-bold underline text-[#A64336] hover:text-[#802B20] inline-flex items-center gap-1"
                >
                  <span>Claim was saved in registry. Click here to open case file directly &rarr;</span>
                </Link>
              </div>
            )}
          </div>
          <button onClick={() => setErrorMessage(null)} className="text-[#A64336] hover:text-[#802B20]">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* STEP 1: Claim Information */}
      {currentStep === 1 && (
        <div className="bg-white rounded-xl border border-[#E1E7E4] shadow-xs p-6 space-y-5">
          <div>
            <h2 className="text-sm font-bold text-[#202B2A] uppercase tracking-wider">
              Step 1: Primary Claim & Patient Information
            </h2>
            <p className="text-xs text-[#687573] mt-0.5">
              Enter the patient identifier, payer name, and disputed billed charges.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-[#202B2A] mb-1">
                Claim Reference ID <span className="text-[#D87568]">*</span>
              </label>
              <input
                type="text"
                value={claimReference}
                onChange={(e) => setClaimReference(e.target.value)}
                className="w-full text-xs font-mono bg-[#FAFAF7] border border-[#E1E7E4] rounded-lg px-3 py-2 text-[#202B2A] focus:outline-none focus:border-[#16856B] focus:bg-white"
                placeholder="e.g. CLM-2026-9011"
                required
              />
              <span className="text-[10px] text-[#687573] mt-0.5 block">Unique internal or insurer tracking identifier</span>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#202B2A] mb-1">
                Patient Identifier / Account # <span className="text-[#D87568]">*</span>
              </label>
              <input
                type="text"
                value={patientReference}
                onChange={(e) => setPatientReference(e.target.value)}
                className="w-full text-xs font-mono bg-[#FAFAF7] border border-[#E1E7E4] rounded-lg px-3 py-2 text-[#202B2A] focus:outline-none focus:border-[#16856B] focus:bg-white"
                placeholder="e.g. PAT-EMERG-441"
                required
              />
              <span className="text-[10px] text-[#687573] mt-0.5 block">De-identified patient or hospital account key</span>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#202B2A] mb-1">
                Insurance Carrier / Payer Name <span className="text-[#D87568]">*</span>
              </label>
              <input
                type="text"
                value={insurerName}
                onChange={(e) => setInsurerName(e.target.value)}
                className="w-full text-xs bg-[#FAFAF7] border border-[#E1E7E4] rounded-lg px-3 py-2 text-[#202B2A] focus:outline-none focus:border-[#16856B] focus:bg-white"
                placeholder="e.g. BlueShield Horizon"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#202B2A] mb-1">
                Total Disputed Billed Amount ($) <span className="text-[#D87568]">*</span>
              </label>
              <input
                type="number"
                step="0.01"
                value={claimAmount}
                onChange={(e) => setClaimAmount(e.target.value)}
                className="w-full text-xs font-mono tabular-nums bg-[#FAFAF7] border border-[#E1E7E4] rounded-lg px-3 py-2 text-[#202B2A] focus:outline-none focus:border-[#16856B] focus:bg-white"
                placeholder="e.g. 8450.00"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#202B2A] mb-1">
                Policy / Member Number
              </label>
              <input
                type="text"
                value={policyNumber}
                onChange={(e) => setPolicyNumber(e.target.value)}
                className="w-full text-xs font-mono bg-[#FAFAF7] border border-[#E1E7E4] rounded-lg px-3 py-2 text-[#202B2A] focus:outline-none focus:border-[#16856B] focus:bg-white"
                placeholder="e.g. BSH-99281-X"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#202B2A] mb-1">
                Primary Date of Service (DOS)
              </label>
              <input
                type="date"
                value={dateOfService}
                onChange={(e) => setDateOfService(e.target.value)}
                className="w-full text-xs bg-[#FAFAF7] border border-[#E1E7E4] rounded-lg px-3 py-2 text-[#202B2A] focus:outline-none focus:border-[#16856B] focus:bg-white"
              />
            </div>
          </div>

          <div className="flex justify-end pt-4 border-t border-[#E1E7E4]">
            <button
              type="button"
              disabled={!isStep1Valid}
              onClick={() => setCurrentStep(2)}
              className="inline-flex items-center gap-1.5 bg-[#123F3A] hover:bg-[#17524B] text-white px-5 py-2 rounded-lg text-xs font-semibold shadow-xs transition-colors disabled:opacity-50"
            >
              <span>Next: Denial Details</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* STEP 2: Denial Details */}
      {currentStep === 2 && (
        <div className="bg-white rounded-xl border border-[#E1E7E4] shadow-xs p-6 space-y-5">
          <div>
            <h2 className="text-sm font-bold text-[#202B2A] uppercase tracking-wider">
              Step 2: Insurer Denial Reason & Classification
            </h2>
            <p className="text-xs text-[#687573] mt-0.5">
              Specify the stated rejection code and adverse determination explanation.
            </p>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-[#202B2A] mb-1">
                Stated Insurer Denial Reason <span className="text-[#D87568]">*</span>
              </label>
              <textarea
                rows={3}
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
                className="w-full text-xs bg-[#FAFAF7] border border-[#E1E7E4] rounded-lg p-3 text-[#202B2A] focus:outline-none focus:border-[#16856B] focus:bg-white leading-relaxed"
                placeholder="Exact language from insurer's EOB notice, e.g. Missing prior authorization for inpatient surgical admission..."
                required
              />
              <span className="text-[10px] text-[#687573] mt-0.5 block">Used by the decision engine to formulate targeted statutory rebuttals.</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-[#202B2A] mb-1">
                  Remittance / Denial Code (CARC/RARC)
                </label>
                <input
                  type="text"
                  value={rejectionCode}
                  onChange={(e) => setRejectionCode(e.target.value)}
                  className="w-full text-xs font-mono bg-[#FAFAF7] border border-[#E1E7E4] rounded-lg px-3 py-2 text-[#202B2A] focus:outline-none focus:border-[#16856B] focus:bg-white"
                  placeholder="e.g. CO-197, CO-50, PR-204"
                />
                <span className="text-[10px] text-[#687573] mt-0.5 block">Standard claim adjustment reason code</span>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#202B2A] mb-1">
                  Review Priority
                </label>
                <select
                  value={reviewPriority}
                  onChange={(e) => setReviewPriority(e.target.value as any)}
                  className="w-full text-xs bg-[#FAFAF7] border border-[#E1E7E4] rounded-lg px-3 py-2 text-[#202B2A] focus:outline-none focus:border-[#16856B] focus:bg-white"
                >
                  <option value="urgent">Urgent (Statutory filing window &lt; 14 days)</option>
                  <option value="high">High Priority</option>
                  <option value="medium">Standard / Medium</option>
                  <option value="low">Low Priority</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#202B2A] mb-1">
                Internal Reviewer / Clinical Notes (Optional)
              </label>
              <textarea
                rows={2}
                value={reviewerNotes}
                onChange={(e) => setReviewerNotes(e.target.value)}
                className="w-full text-xs bg-[#FAFAF7] border border-[#E1E7E4] rounded-lg p-2.5 text-[#202B2A] focus:outline-none focus:border-[#16856B] focus:bg-white"
                placeholder="Initial notes from billing specialist or patient advocate..."
              />
            </div>
          </div>

          <div className="flex justify-between pt-4 border-t border-[#E1E7E4]">
            <button
              type="button"
              onClick={() => setCurrentStep(1)}
              className="inline-flex items-center gap-1 text-xs font-semibold text-[#687573] hover:text-[#202B2A]"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back</span>
            </button>

            <button
              type="button"
              disabled={!isStep2Valid}
              onClick={() => setCurrentStep(3)}
              className="inline-flex items-center gap-1.5 bg-[#123F3A] hover:bg-[#17524B] text-white px-5 py-2 rounded-lg text-xs font-semibold shadow-xs transition-colors disabled:opacity-50"
            >
              <span>Next: Attach Documents</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* STEP 3: Document Upload */}
      {currentStep === 3 && (
        <div className="bg-white rounded-xl border border-[#E1E7E4] shadow-xs p-6 space-y-5">
          <div>
            <h2 className="text-sm font-bold text-[#202B2A] uppercase tracking-wider">
              Step 3: Attach Medical Evidence & Records
            </h2>
            <p className="text-xs text-[#687573] mt-0.5">
              Upload itemized hospital bills, clinical discharge summaries, operative reports, or denial letters for PyMuPDF text and entity extraction.
            </p>
          </div>

          {/* Drag & Drop Zone */}
          <div
            onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
            onDragLeave={() => setIsDragging(false)}
            onDrop={handleDrop}
            className={`border-2 border-dashed rounded-xl p-8 text-center transition-all ${
              isDragging ? 'border-[#16856B] bg-[#E6F4EF]/50' : 'border-[#E1E7E4] hover:border-[#B0E1D4] bg-[#FAFAF7]'
            }`}
          >
            <Upload className="w-8 h-8 text-[#16856B] mx-auto mb-2 opacity-80" />
            <h4 className="text-xs font-bold text-[#202B2A]">
              Drag and drop medical PDFs or clinical files here
            </h4>
            <p className="text-[11px] text-[#687573] mt-1">
              Supports searchable PDF, PNG, JPEG, WEBP &bull; Max 15 MB per file
            </p>

            <div className="mt-4">
              <label className="inline-flex items-center gap-1.5 bg-white border border-[#E1E7E4] hover:bg-[#F1F3F2] text-[#202B2A] px-4 py-2 rounded-lg text-xs font-semibold cursor-pointer shadow-2xs transition-colors">
                <span>Browse Local Files</span>
                <input
                  type="file"
                  multiple
                  accept=".pdf,.png,.jpg,.jpeg,.webp"
                  onChange={(e) => handleAddFiles(e.target.files)}
                  className="hidden"
                />
              </label>
            </div>
          </div>

          {/* Staged Files List */}
          {stagedFiles.length > 0 ? (
            <div className="space-y-2">
              <span className="text-xs font-semibold text-[#202B2A] block">
                Staged Documents ({stagedFiles.length})
              </span>
              <div className="divide-y divide-[#E1E7E4] border border-[#E1E7E4] rounded-xl overflow-hidden bg-white">
                {stagedFiles.map((item, idx) => (
                  <div key={idx} className="p-3 flex items-center justify-between gap-3 text-xs">
                    <div className="flex items-center gap-2 truncate flex-1">
                      <FileText className="w-4 h-4 text-[#16856B] shrink-0" />
                      <span className="font-medium text-[#202B2A] truncate" title={item.file.name}>
                        {item.file.name}
                      </span>
                      <span className="text-[10px] text-[#687573] shrink-0">
                        ({(item.file.size / 1024).toFixed(1)} KB)
                      </span>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <select
                        value={item.type}
                        onChange={(e) => updateFileType(idx, e.target.value)}
                        className="text-[11px] bg-[#FAFAF7] border border-[#E1E7E4] rounded px-2 py-1 text-[#202B2A]"
                      >
                        {docTypes.map((dt) => (
                          <option key={dt.value} value={dt.value}>{dt.label}</option>
                        ))}
                      </select>

                      <button
                        type="button"
                        onClick={() => removeFile(idx)}
                        className="p-1 rounded text-[#8E9C99] hover:text-[#D87568]"
                        title="Remove file"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="p-3 rounded-lg bg-[#E6F4EF]/60 border border-[#B0E1D4] text-xs text-[#123F3A] flex items-center gap-2">
              <Info className="w-4 h-4 text-[#16856B] shrink-0" />
              <span>You can proceed without files now and upload additional documents later from the Document Intelligence workspace.</span>
            </div>
          )}

          <div className="flex justify-between pt-4 border-t border-[#E1E7E4]">
            <button
              type="button"
              onClick={() => setCurrentStep(2)}
              className="inline-flex items-center gap-1 text-xs font-semibold text-[#687573] hover:text-[#202B2A]"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back</span>
            </button>

            <button
              type="button"
              onClick={() => setCurrentStep(4)}
              className="inline-flex items-center gap-1.5 bg-[#123F3A] hover:bg-[#17524B] text-white px-5 py-2 rounded-lg text-xs font-semibold shadow-xs transition-colors"
            >
              <span>Next: Review & Submit</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* STEP 4: Review & Run Analysis */}
      {currentStep === 4 && (
        <div className="bg-white rounded-xl border border-[#E1E7E4] shadow-xs p-6 space-y-6">
          <div>
            <h2 className="text-sm font-bold text-[#202B2A] uppercase tracking-wider">
              Step 4: Review Intake Summary & Trigger Verification
            </h2>
            <p className="text-xs text-[#687573] mt-0.5">
              Confirm case details before saving to registry and launching the document extraction engine.
            </p>
          </div>

          {/* Intake Summary Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-[#FAFAF7] p-4 rounded-xl border border-[#E1E7E4] text-xs">
            <div>
              <span className="text-[10px] uppercase font-bold text-[#687573] block">Case Reference</span>
              <span className="font-bold text-[#123F3A] font-mono text-sm">{claimReference}</span>
            </div>

            <div>
              <span className="text-[10px] uppercase font-bold text-[#687573] block">Patient / Account Ref</span>
              <span className="font-semibold text-[#202B2A] font-mono">{patientReference}</span>
            </div>

            <div>
              <span className="text-[10px] uppercase font-bold text-[#687573] block">Insurer</span>
              <span className="font-semibold text-[#202B2A]">{insurerName}</span>
            </div>

            <div>
              <span className="text-[10px] uppercase font-bold text-[#687573] block">Disputed Billed Amount</span>
              <span className="font-bold text-[#123F3A] font-mono text-sm tabular-nums">
                ${parseFloat(claimAmount || '0').toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </span>
            </div>

            <div className="sm:col-span-2 pt-2 border-t border-[#E1E7E4]">
              <span className="text-[10px] uppercase font-bold text-[#687573] block">Denial Reason</span>
              <p className="text-xs italic text-[#202B2A] mt-0.5">&ldquo;{rejectionReason}&rdquo;</p>
              {rejectionCode && (
                <span className="inline-block mt-1 font-mono text-[10px] bg-[#FCF3F1] text-[#A64336] border border-[#F4CAC5] px-1.5 py-0.2 rounded">
                  CARC: {rejectionCode}
                </span>
              )}
            </div>

            <div className="sm:col-span-2 pt-2 border-t border-[#E1E7E4] flex items-center justify-between text-[11px] text-[#687573]">
              <span>Attached Documents: <strong>{stagedFiles.length} file(s)</strong></span>
              <span>Priority: <strong className="uppercase">{reviewPriority}</strong></span>
            </div>
          </div>

          {/* Submission Status Indicator */}
          {submitting ? (
            <div className="p-4 bg-[#E6F4EF] border border-[#B0E1D4] rounded-xl text-center space-y-2">
              <RefreshCw className="w-5 h-5 text-[#16856B] animate-spin mx-auto" />
              <p className="text-xs font-semibold text-[#123F3A]">{statusMessage}</p>
              <p className="text-[10px] text-[#687573]">Please wait while text extraction and cross-referencing complete...</p>
            </div>
          ) : (
            <div className="flex justify-between pt-4 border-t border-[#E1E7E4]">
              <button
                type="button"
                onClick={() => setCurrentStep(3)}
                className="inline-flex items-center gap-1 text-xs font-semibold text-[#687573] hover:text-[#202B2A]"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Back</span>
              </button>

              <button
                type="button"
                onClick={handleSubmit}
                className="inline-flex items-center gap-1.5 bg-[#123F3A] hover:bg-[#17524B] text-white px-6 py-2.5 rounded-lg text-xs font-bold shadow-xs transition-colors"
              >
                <Sparkles className="w-4 h-4 text-[#16856B]" />
                <span>Complete Intake & Run Verification</span>
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
