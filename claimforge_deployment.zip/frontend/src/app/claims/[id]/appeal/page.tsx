'use client';

import React, { useEffect, useState, useMemo } from 'react';
import Link from 'next/link';
import { useParams, useRouter } from 'next/navigation';
import {
  FileText,
  Download,
  CheckCircle2,
  XCircle,
  Save,
  ArrowLeft,
  Sparkles,
  RefreshCw,
  Scale,
  FileCheck,
  AlertCircle,
  Check,
  Printer,
  AlertTriangle,
  RotateCcw,
  Sliders,
  ShieldCheck,
  FileSignature,
  FileSearch,
  ExternalLink,
  X
} from 'lucide-react';
import { api } from '@/lib/api';
import { Claim, Appeal, Document, Finding, FindingsGrouped } from '@/lib/types';
import { formatCurrency, formatDate } from '@/lib/utils';
import { SeverityBadge } from '@/components/StatusBadge';

export default function AppealEditorPage() {
  const params = useParams();
  const router = useRouter();
  const claimId = params.id as string;

  const [claim, setClaim] = useState<Claim | null>(null);
  const [appeal, setAppeal] = useState<Appeal | null>(null);
  const [documents, setDocuments] = useState<Document[]>([]);
  const [allFindings, setAllFindings] = useState<Finding[]>([]);
  const [selectedFindingIds, setSelectedFindingIds] = useState<string[]>([]);
  const [customInstructions, setCustomInstructions] = useState('');
  const [draftText, setDraftText] = useState('');
  const [appealTitle, setAppealTitle] = useState('');
  const [reviewerNotes, setReviewerNotes] = useState('');
  const [reviewerName, setReviewerName] = useState('Senior Patient Advocate / Clinical Billing Specialist');
  const [tone, setTone] = useState('formal_professional');
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [banner, setBanner] = useState<{ type: 'success' | 'error'; message: string } | null>(null);
  const [showRejectModal, setShowRejectModal] = useState(false);
  const [rejectReason, setRejectReason] = useState('');
  const [activeSidebarTab, setActiveSidebarTab] = useState<'findings' | 'strategy' | 'exhibits'>('findings');

  // Detect unresolved bracketed placeholders in real-time
  const detectedPlaceholders = useMemo(() => {
    if (!draftText) return [];
    const matches = draftText.match(/\[[A-Z0-9_:\s\-]+\]/g);
    if (!matches) return [];
    return Array.from(new Set(matches));
  }, [draftText]);

  const loadData = async () => {
    try {
      const [c, docs, appeals, findingsGrouped] = await Promise.all([
        api.getClaim(claimId),
        api.getClaimDocuments(claimId),
        api.getClaimAppeals(claimId),
        api.getClaimFindings(claimId).catch(() => null),
      ]);
      setClaim(c);
      setDocuments(docs || []);

      // Compile flat list of all findings
      let flattenedFindings: Finding[] = [];
      if (findingsGrouped) {
        flattenedFindings = [
          ...(findingsGrouped.rejection_analysis || []),
          ...(findingsGrouped.cross_document_inconsistencies || []),
          ...(findingsGrouped.missing_evidence || []),
          ...(findingsGrouped.document_integrity_indicators || []),
          ...(findingsGrouped.extracted_facts || []),
          ...(findingsGrouped.recommended_actions || []),
        ];
        setAllFindings(flattenedFindings);
      }

      if (appeals && appeals.length > 0) {
        const latest = appeals[0];
        setAppeal(latest);
        setDraftText(latest.draft_content);
        setAppealTitle(latest.appeal_title);
        setReviewerNotes(latest.reviewer_notes || '');
        if (latest.approved_by) setReviewerName(latest.approved_by);

        if (latest.included_finding_ids && latest.included_finding_ids.length > 0) {
          setSelectedFindingIds(latest.included_finding_ids);
        } else {
          const activeIds = flattenedFindings
            .filter((f) => f.reviewer_status !== 'dismissed')
            .map((f) => f.id);
          setSelectedFindingIds(activeIds);
        }
      } else {
        // Automatically generate first draft with confirmed/active findings
        const activeIds = flattenedFindings
          .filter((f) => f.reviewer_status !== 'dismissed')
          .map((f) => f.id);
        setSelectedFindingIds(activeIds);
        await handleGenerateNewDraft(activeIds, c);
      }
    } catch (err: any) {
      console.error('Failed to load appeal workspace:', err);
      setBanner({
        type: 'error',
        message: `Failed to load appeal workspace: ${err.message || String(err)}`
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (claimId) loadData();
  }, [claimId]);

  const handleToggleFinding = (findingId: string) => {
    setSelectedFindingIds((prev) =>
      prev.includes(findingId) ? prev.filter((id) => id !== findingId) : [...prev, findingId]
    );
  };

  const handleSelectAllFindings = () => {
    const allIds = allFindings.map((f) => f.id);
    setSelectedFindingIds(allIds);
  };

  const handleSelectConfirmedOnly = () => {
    const confirmedIds = allFindings.filter((f) => f.reviewer_status === 'confirmed').map((f) => f.id);
    setSelectedFindingIds(confirmedIds);
  };

  const handleGenerateNewDraft = async (overrideIds?: string[], targetClaim?: Claim | null) => {
    setGenerating(true);
    setBanner(null);
    try {
      const idsToUse = overrideIds !== undefined ? overrideIds : selectedFindingIds;
      const newAppeal = await api.generateAppeal(
        claimId,
        tone,
        customInstructions.trim() ? customInstructions : undefined,
        idsToUse
      );
      setAppeal(newAppeal);
      setDraftText(newAppeal.draft_content);
      setAppealTitle(newAppeal.appeal_title);
      setReviewerNotes(newAppeal.reviewer_notes || '');
      if (newAppeal.included_finding_ids) {
        setSelectedFindingIds(newAppeal.included_finding_ids);
      }
      setBanner({
        type: 'success',
        message: 'New statutory appeal draft synthesized with selected evidentiary findings.'
      });
      setTimeout(() => setBanner(null), 4000);
    } catch (err: any) {
      setBanner({
        type: 'error',
        message: `Draft generation failed: ${err.message || String(err)}`
      });
    } finally {
      setGenerating(false);
    }
  };

  const handleSaveDraft = async () => {
    if (!appeal) return;
    setSaving(true);
    setBanner(null);
    try {
      const updated = await api.updateAppeal(appeal.id, {
        appeal_title: appealTitle,
        draft_content: draftText,
        reviewer_notes: reviewerNotes,
        approved_by: reviewerName,
      });
      setAppeal(updated);
      setSaveSuccess(true);
      setBanner({
        type: 'success',
        message: 'Appeal draft edits and clinical notes saved successfully.'
      });
      setTimeout(() => {
        setSaveSuccess(false);
        setBanner(null);
      }, 3500);
    } catch (err: any) {
      setBanner({
        type: 'error',
        message: `Save failed: ${err.message || String(err)}`
      });
    } finally {
      setSaving(false);
    }
  };

  const handleApproveAppeal = async () => {
    if (!appeal) return;
    if (!reviewerName.trim()) {
      setBanner({
        type: 'error',
        message: 'Please enter the Authorized Reviewer Name & Title before approving.'
      });
      return;
    }
    setSaving(true);
    setBanner(null);
    try {
      const updated = await api.updateAppeal(appeal.id, {
        approval_status: 'approved',
        appeal_title: appealTitle,
        draft_content: draftText,
        reviewer_notes: reviewerNotes,
        approved_by: reviewerName,
      });
      setAppeal(updated);
      if (claim) setClaim({ ...claim, status: 'completed' });
      setSaveSuccess(true);
      setBanner({
        type: 'success',
        message: 'Appeal determination approved & signed! Official ReportLab PDF packet is ready for filing.'
      });
      setTimeout(() => setSaveSuccess(false), 4000);
    } catch (err: any) {
      setBanner({
        type: 'error',
        message: `Approval failed: ${err.message || String(err)}`
      });
    } finally {
      setSaving(false);
    }
  };

  const handleConfirmRejection = async () => {
    if (!appeal) return;
    setSaving(true);
    setBanner(null);
    try {
      const updated = await api.updateAppeal(appeal.id, {
        approval_status: 'rejected',
        reviewer_notes: rejectReason,
        approved_by: reviewerName,
      });
      setReviewerNotes(rejectReason);
      setAppeal(updated);
      if (claim) setClaim({ ...claim, status: 'in_review' });
      setShowRejectModal(false);
      setBanner({
        type: 'success',
        message: 'Appeal returned for revisions with reviewer observation logged.'
      });
      setTimeout(() => setBanner(null), 4000);
    } catch (err: any) {
      setBanner({
        type: 'error',
        message: `Rejection update failed: ${err.message || String(err)}`
      });
    } finally {
      setSaving(false);
    }
  };

  const handleReopenDraft = async () => {
    if (!appeal) return;
    setSaving(true);
    setBanner(null);
    try {
      const updated = await api.updateAppeal(appeal.id, {
        approval_status: 'draft',
      });
      setAppeal(updated);
      if (claim) setClaim({ ...claim, status: 'appeal_generated' });
      setBanner({
        type: 'success',
        message: 'Appeal packet reopened as editable draft.'
      });
      setTimeout(() => setBanner(null), 3000);
    } catch (err: any) {
      setBanner({
        type: 'error',
        message: `Failed to reopen draft: ${err.message || String(err)}`
      });
    } finally {
      setSaving(false);
    }
  };

  const handleOpenPDF = () => {
    if (!appeal) return;
    const url = api.getAppealExportUrl(appeal.id, 'pdf');
    window.open(url, '_blank');
  };

  const handleDownloadPDF = () => {
    if (!appeal) return;
    const url = api.getAppealExportUrl(appeal.id, 'pdf');
    const a = document.createElement('a');
    a.href = url;
    a.download = `ClaimForge_Appeal_${claim?.claim_reference || appeal.id}.pdf`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleDownloadTXT = () => {
    if (!appeal) return;
    const url = api.getAppealExportUrl(appeal.id, 'txt');
    const a = document.createElement('a');
    a.href = url;
    a.download = `ClaimForge_Appeal_${claim?.claim_reference || appeal.id}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  if (loading) {
    return (
      <div className="py-20 text-center text-[#687573] space-y-2">
        <RefreshCw className="w-6 h-6 text-[#16856B] animate-spin mx-auto" />
        <p className="text-xs font-semibold text-[#202B2A]">Loading appeal studio & verified evidence citations...</p>
      </div>
    );
  }

  if (!claim) return null;

  return (
    <div className="space-y-5">
      {/* Feedback Banner */}
      {banner && (
        <div
          className={`p-3.5 rounded-xl border text-xs flex items-center justify-between gap-3 animate-in fade-in duration-150 ${
            banner.type === 'success'
              ? 'bg-[#E6F4EF] text-[#123F3A] border-[#B0E1D4]'
              : 'bg-[#FCF3F1] text-[#A64336] border-[#F4CAC5]'
          }`}
        >
          <div className="flex items-center gap-2">
            {banner.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-[#16856B] shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-[#D87568] shrink-0" />
            )}
            <span className="font-semibold">{banner.message}</span>
          </div>
          <button
            onClick={() => setBanner(null)}
            className="text-inherit opacity-70 hover:opacity-100 p-1"
            aria-label="Dismiss notification"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Top Header & Breadcrumb */}
      <div className="bg-white rounded-xl border border-[#E1E7E4] shadow-xs p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          <Link
            href={`/claims/${claim.id}`}
            className="p-2 rounded-lg border border-[#E1E7E4] text-[#687573] hover:text-[#202B2A] hover:bg-[#F1F3F2] mt-0.5"
            title="Back to Claim Details"
          >
            <ArrowLeft className="w-4 h-4" />
          </Link>
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <h1 className="text-lg sm:text-xl font-bold text-[#202B2A] tracking-tight">
                Appeal Letter Workspace
              </h1>
              {appeal && (
                <span
                  className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider border ${
                    appeal.approval_status === 'approved'
                      ? 'bg-[#E6F4EF] text-[#123F3A] border-[#B0E1D4]'
                      : appeal.approval_status === 'rejected'
                      ? 'bg-[#FCF3F1] text-[#A64336] border-[#F4CAC5]'
                      : 'bg-[#FDF8EC] text-[#8E6B1D] border-[#ECD8A5]'
                  }`}
                >
                  {appeal.approval_status === 'approved' && '✓ Approved & Signed'}
                  {appeal.approval_status === 'rejected' && '✕ Returned / Revisions Needed'}
                  {appeal.approval_status === 'draft' && '• Draft in Progress'}
                </span>
              )}
            </div>
            <p className="text-xs text-[#687573] mt-1 font-mono">
              Case Ref: <strong className="text-[#202B2A]">{claim.claim_reference}</strong> &bull; Insurer:{' '}
              <strong className="text-[#202B2A]">{claim.insurer_name}</strong> &bull; Disputed Amount:{' '}
              <strong className="text-[#123F3A] font-bold tabular-nums">{formatCurrency(claim.claim_amount)}</strong> &bull; DOS:{' '}
              {formatDate(claim.date_of_service)}
            </p>
          </div>
        </div>

        {/* Global Toolbar */}
        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <button
            onClick={handleSaveDraft}
            disabled={saving}
            className="inline-flex items-center gap-1.5 bg-[#F1F3F2] hover:bg-[#E1E7E4] text-[#202B2A] border border-[#E1E7E4] px-3.5 py-2 rounded-lg text-xs font-semibold transition-colors shadow-2xs"
          >
            {saveSuccess ? (
              <>
                <Check className="w-3.5 h-3.5 text-[#16856B]" />
                <span className="text-[#16856B]">Saved</span>
              </>
            ) : (
              <>
                <Save className="w-3.5 h-3.5 text-[#687573]" />
                <span>{saving ? 'Saving...' : 'Save Draft'}</span>
              </>
            )}
          </button>

          <button
            onClick={handleOpenPDF}
            className="inline-flex items-center gap-1.5 bg-white border border-[#E1E7E4] text-[#123F3A] hover:bg-[#F1F3F2] px-3 py-2 rounded-lg text-xs font-semibold shadow-2xs transition-colors"
            title="Preview / Print official PDF in new tab"
          >
            <ExternalLink className="w-3.5 h-3.5 text-[#16856B]" />
            <span>Open PDF</span>
          </button>

          <button
            onClick={handleDownloadTXT}
            className="inline-flex items-center gap-1.5 bg-white border border-[#E1E7E4] text-[#202B2A] hover:bg-[#F1F3F2] px-3 py-2 rounded-lg text-xs font-semibold shadow-2xs transition-colors"
            title="Download Plain Text (.txt)"
          >
            <Download className="w-3.5 h-3.5 text-[#687573]" />
            <span>Text (.txt)</span>
          </button>

          <button
            onClick={handleDownloadPDF}
            className="inline-flex items-center gap-1.5 bg-[#123F3A] hover:bg-[#17524B] text-white font-bold px-4 py-2 rounded-lg text-xs shadow-xs transition-colors"
            title="Download official PDF packet"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Export Official PDF Packet</span>
          </button>
        </div>
      </div>

      {/* Target Denial Highlight Box */}
      <div className="bg-[#FCF3F1] border border-[#F4CAC5] p-3 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs text-[#A64336]">
        <div>
          <span className="font-bold uppercase tracking-wider text-[10px] block">
            Target Insurer Denial Reason (Rebuttal Objective):
          </span>
          <p className="font-medium mt-0.5 italic">
            &ldquo;{claim.rejection_reason}&rdquo;{' '}
            {claim.rejection_code && (
              <span className="font-mono bg-white text-[#A64336] border border-[#F4CAC5] px-1.5 py-0.2 rounded text-[10px] ml-1 font-bold">
                CARC: {claim.rejection_code}
              </span>
            )}
          </p>
        </div>
        <div className="text-[10px] text-[#A64336] bg-white border border-[#F4CAC5] px-2 py-0.5 rounded font-medium shrink-0">
          Grounded in clinical citations
        </div>
      </div>

      {/* Main Dual-Pane Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left Column (5 cols): Findings, Strategy, Sign-Off */}
        <div className="lg:col-span-5 space-y-4">
          {/* Navigation Tabs for Left Sidebar */}
          <div className="flex border-b border-[#E1E7E4] text-xs font-bold gap-1 bg-white px-2 pt-2 rounded-t-xl border-x">
            <button
              onClick={() => setActiveSidebarTab('findings')}
              className={`pb-2.5 px-2.5 border-b-2 transition-colors flex items-center gap-1.5 ${
                activeSidebarTab === 'findings'
                  ? 'border-[#123F3A] text-[#123F3A]'
                  : 'border-transparent text-[#687573] hover:text-[#202B2A]'
              }`}
            >
              <span>Selected Findings</span>
              <span className="bg-[#E6F4EF] text-[#123F3A] border border-[#B0E1D4] px-1.5 py-0.2 rounded-full text-[10px] font-mono">
                {selectedFindingIds.length}/{allFindings.length}
              </span>
            </button>

            <button
              onClick={() => setActiveSidebarTab('strategy')}
              className={`pb-2.5 px-2.5 border-b-2 transition-colors flex items-center gap-1.5 ${
                activeSidebarTab === 'strategy'
                  ? 'border-[#123F3A] text-[#123F3A]'
                  : 'border-transparent text-[#687573] hover:text-[#202B2A]'
              }`}
            >
              <Sliders className="w-3.5 h-3.5" />
              <span>Strategy & Tone</span>
            </button>

            <button
              onClick={() => setActiveSidebarTab('exhibits')}
              className={`pb-2.5 px-2.5 border-b-2 transition-colors flex items-center gap-1.5 ${
                activeSidebarTab === 'exhibits'
                  ? 'border-[#123F3A] text-[#123F3A]'
                  : 'border-transparent text-[#687573] hover:text-[#202B2A]'
              }`}
            >
              <FileCheck className="w-3.5 h-3.5" />
              <span>Exhibits ({documents.length})</span>
            </button>
          </div>

          {/* TAB 1: Selected Findings */}
          {activeSidebarTab === 'findings' && (
            <div className="bg-white p-4 rounded-xl border border-[#E1E7E4] shadow-xs space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xs font-bold uppercase tracking-wider text-[#202B2A]">
                    Reviewer-Selected Findings
                  </h3>
                  <p className="text-[10px] text-[#687573]">
                    Only checked evidentiary findings are synthesized into the appeal.
                  </p>
                </div>
                <div className="flex items-center gap-1 text-[10px]">
                  <button
                    type="button"
                    onClick={handleSelectAllFindings}
                    className="text-[#16856B] hover:underline font-semibold"
                  >
                    All
                  </button>
                  <span className="text-[#8E9C99]">&bull;</span>
                  <button
                    type="button"
                    onClick={handleSelectConfirmedOnly}
                    className="text-[#16856B] hover:underline font-semibold"
                  >
                    Confirmed
                  </button>
                </div>
              </div>

              <div className="max-h-[380px] overflow-y-auto space-y-2 pr-1">
                {allFindings.map((f) => {
                  const isChecked = selectedFindingIds.includes(f.id);
                  return (
                    <div
                      key={f.id}
                      onClick={() => handleToggleFinding(f.id)}
                      className={`p-3 rounded-lg border text-xs cursor-pointer transition-colors ${
                        isChecked
                          ? 'border-[#B0E1D4] bg-[#E6F4EF]/50'
                          : 'border-[#E1E7E4] bg-white opacity-70 hover:opacity-100'
                      }`}
                    >
                      <div className="flex items-start gap-2">
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => {}}
                          className="mt-0.5 rounded text-[#16856B] focus:ring-[#16856B]"
                        />
                        <div className="flex-1 space-y-1">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className="text-[9px] uppercase font-bold text-[#687573] bg-[#F1F3F2] px-1.5 py-0.2 rounded border border-[#E1E7E4]">
                              {f.category.replace(/_/g, ' ')}
                            </span>
                            {f.reviewer_status === 'confirmed' && (
                              <span className="text-[9px] bg-[#E6F4EF] text-[#123F3A] border border-[#B0E1D4] px-1 py-0.2 rounded font-bold">
                                Confirmed
                              </span>
                            )}
                          </div>
                          <h4 className="text-xs font-bold text-[#202B2A] leading-snug">{f.title}</h4>
                          <p className="text-[11px] text-[#687573] line-clamp-2 leading-relaxed">{f.explanation}</p>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              <button
                type="button"
                onClick={() => handleGenerateNewDraft()}
                disabled={generating}
                className="w-full inline-flex items-center justify-center gap-1.5 bg-[#123F3A] hover:bg-[#17524B] text-white px-3 py-2 rounded-lg text-xs font-semibold shadow-xs transition-colors disabled:opacity-50"
              >
                <Sparkles className={`w-3.5 h-3.5 text-[#16856B] ${generating ? 'animate-spin' : ''}`} />
                <span>{generating ? 'Regenerating Draft...' : 'Synthesize Draft with Selected Findings'}</span>
              </button>
            </div>
          )}

          {/* TAB 2: Strategy & Tone */}
          {activeSidebarTab === 'strategy' && (
            <div className="bg-white p-4 rounded-xl border border-[#E1E7E4] shadow-xs space-y-4">
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-[#202B2A]">
                  Appeal Tone & Statutory Framework
                </h3>
                <p className="text-[10px] text-[#687573] mt-0.5">
                  Select the legal framing and emphasis for the generated administrative appeal.
                </p>
              </div>

              <div className="space-y-2">
                {[
                  {
                    id: 'formal_professional',
                    name: 'Formal Professional (Standard Medical Appeal)',
                    desc: 'Balanced, respectful, evidence-first tone citing clinical charts and standard policy guidelines.',
                  },
                  {
                    id: 'assertive_legal',
                    name: 'Assertive Statutory (ERISA § 1133 / EMTALA / ACA)',
                    desc: 'Aggressive citation of federal regulations, statutory appeal deadlines, and bad-faith notice provisions.',
                  },
                  {
                    id: 'clinical_concise',
                    name: 'Clinical Direct (Peer-to-Peer Review Style)',
                    desc: 'Concise medical terminology highlighting physician orders, diagnostic imaging, and necessity guidelines.',
                  },
                ].map((t) => (
                  <label
                    key={t.id}
                    onClick={() => setTone(t.id)}
                    className={`block p-3 rounded-lg border text-xs cursor-pointer transition-colors ${
                      tone === t.id
                        ? 'border-[#B0E1D4] bg-[#E6F4EF]/60 text-[#123F3A]'
                        : 'border-[#E1E7E4] bg-white hover:bg-[#FAFAF7] text-[#687573]'
                    }`}
                  >
                    <div className="flex items-center gap-2 font-bold text-[#202B2A]">
                      <input
                        type="radio"
                        name="tone_select"
                        checked={tone === t.id}
                        onChange={() => setTone(t.id)}
                        className="text-[#16856B]"
                      />
                      <span>{t.name}</span>
                    </div>
                    <p className="text-[11px] text-[#687573] mt-1 pl-5 leading-relaxed">{t.desc}</p>
                  </label>
                ))}
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#202B2A] mb-1">
                  Custom Reviewer Instructions (Optional)
                </label>
                <textarea
                  rows={3}
                  value={customInstructions}
                  onChange={(e) => setCustomInstructions(e.target.value)}
                  placeholder="e.g. Emphasize emergency admission under EMTALA and demand response within 30 days..."
                  className="w-full text-xs border border-[#E1E7E4] rounded-lg p-2.5 bg-[#FAFAF7] text-[#202B2A] focus:outline-none focus:border-[#16856B]"
                />
              </div>

              <button
                type="button"
                onClick={() => handleGenerateNewDraft()}
                disabled={generating}
                className="w-full inline-flex items-center justify-center gap-1.5 bg-[#123F3A] hover:bg-[#17524B] text-white px-3 py-2 rounded-lg text-xs font-semibold shadow-xs transition-colors disabled:opacity-50"
              >
                <Sparkles className="w-3.5 h-3.5 text-[#16856B]" />
                <span>{generating ? 'Regenerating...' : 'Regenerate Draft with Settings'}</span>
              </button>
            </div>
          )}

          {/* TAB 3: Exhibits */}
          {activeSidebarTab === 'exhibits' && (
            <div className="bg-white p-4 rounded-xl border border-[#E1E7E4] shadow-xs space-y-3">
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-[#202B2A]">
                  Itemized Documentary Exhibits ({documents.length})
                </h3>
                <p className="text-[10px] text-[#687573] mt-0.5">
                  These records are formally indexed and referenced in the appeal letter text.
                </p>
              </div>

              <div className="space-y-2">
                {documents.map((doc, idx) => (
                  <div key={doc.id} className="p-2.5 rounded-lg border border-[#E1E7E4] bg-[#FAFAF7] text-xs flex items-center justify-between">
                    <div className="flex items-center gap-2 truncate">
                      <span className="font-bold text-[#123F3A] font-mono text-[11px] bg-white border border-[#E1E7E4] px-1.5 py-0.2 rounded">
                        Exhibit {String.fromCharCode(65 + idx)}
                      </span>
                      <span className="font-medium text-[#202B2A] truncate" title={doc.original_filename}>
                        {doc.original_filename}
                      </span>
                    </div>
                    <span className="text-[10px] text-[#687573] shrink-0 font-medium">
                      {(doc.file_size / 1024).toFixed(1)} KB
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Reviewer Determination & Sign-off Card */}
          <div className="bg-white p-4 rounded-xl border border-[#E1E7E4] shadow-xs space-y-3">
            <div className="flex items-center gap-2">
              <FileSignature className="w-4 h-4 text-[#16856B]" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#202B2A]">
                Reviewer Determination & Sign-Off
              </h3>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-[#202B2A] mb-1">
                Authorized Reviewer Name & Title
              </label>
              <input
                type="text"
                value={reviewerName}
                onChange={(e) => setReviewerName(e.target.value)}
                className="w-full text-xs border border-[#E1E7E4] rounded-lg px-3 py-1.5 bg-[#FAFAF7] text-[#202B2A] focus:outline-none focus:border-[#16856B]"
                placeholder="e.g. Dr. Alan Ross, Senior Clinical Director"
              />
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-[#202B2A] mb-1">
                Clinical Audit Notes
              </label>
              <textarea
                rows={2}
                value={reviewerNotes}
                onChange={(e) => setReviewerNotes(e.target.value)}
                className="w-full text-xs border border-[#E1E7E4] rounded-lg p-2.5 bg-[#FAFAF7] text-[#202B2A] focus:outline-none focus:border-[#16856B]"
                placeholder="Observations, legal grounds confirmation, or approval comments..."
              />
            </div>

            <div className="pt-2 flex flex-col gap-2">
              {appeal?.approval_status !== 'approved' ? (
                <button
                  type="button"
                  onClick={handleApproveAppeal}
                  disabled={saving}
                  className="w-full inline-flex items-center justify-center gap-1.5 bg-[#16856B] hover:bg-[#126B56] text-white px-4 py-2.5 rounded-lg text-xs font-bold shadow-xs transition-colors"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Approve & Sign Appeal Packet</span>
                </button>
              ) : (
                <div className="space-y-2">
                  <div className="p-2.5 rounded-lg bg-[#E6F4EF] border border-[#B0E1D4] text-xs text-[#123F3A] flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-[#16856B] shrink-0" />
                    <span className="font-semibold">Approved by {appeal.approved_by || 'Reviewer'}</span>
                  </div>
                  <button
                    type="button"
                    onClick={handleReopenDraft}
                    className="w-full text-[11px] text-[#687573] hover:text-[#202B2A] hover:underline text-center block"
                  >
                    Reopen draft for edits
                  </button>
                </div>
              )}

              {appeal?.approval_status !== 'rejected' && appeal?.approval_status !== 'approved' && (
                <button
                  type="button"
                  onClick={() => {
                    setRejectReason(reviewerNotes || '');
                    setShowRejectModal(true);
                  }}
                  className="w-full text-xs font-semibold text-[#D87568] hover:bg-[#FCF3F1] border border-[#F4CAC5] px-3 py-1.5 rounded-lg transition-colors"
                >
                  Return / Request Revisions
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Right Column (7 cols): Document Drafting Studio */}
        <div className="lg:col-span-7 space-y-3">
          <div className="bg-white p-5 rounded-xl border border-[#E1E7E4] shadow-xs space-y-3">
            {/* Title Row */}
            <div>
              <label className="block text-[10px] font-bold uppercase tracking-wider text-[#687573] mb-1">
                Formal Letter Header Title
              </label>
              <input
                type="text"
                value={appealTitle}
                onChange={(e) => setAppealTitle(e.target.value)}
                className="w-full text-sm font-bold text-[#202B2A] bg-[#FAFAF7] border border-[#E1E7E4] rounded-lg px-3 py-2 focus:outline-none focus:border-[#16856B] focus:bg-white"
                placeholder="Formal Administrative Appeal..."
              />
            </div>

            {/* Placeholder Warning */}
            {detectedPlaceholders.length > 0 ? (
              <div className="p-3 rounded-lg bg-[#FDF8EC] border border-[#ECD8A5] text-xs text-[#8E6B1D] flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-[#C39B4A] shrink-0 mt-0.5" />
                <div className="flex-1">
                  <strong>Placeholders Detected ({detectedPlaceholders.length}):</strong>
                  <p className="text-[11px] mt-0.5">
                    Fill in or customize the bracketed tokens before filing: {detectedPlaceholders.join(', ')}
                  </p>
                </div>
              </div>
            ) : (
              <div className="p-2.5 rounded-lg bg-[#E6F4EF] border border-[#B0E1D4] text-xs text-[#123F3A] flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#16856B] shrink-0" />
                <span className="font-semibold">All bracketed placeholder tokens are resolved! Ready to print or export.</span>
              </div>
            )}

            {/* Document Text Editor */}
            <div className="relative">
              <textarea
                rows={22}
                value={draftText}
                onChange={(e) => setDraftText(e.target.value)}
                className="w-full text-xs font-mono leading-relaxed p-4 bg-[#FAFAF7] border border-[#E1E7E4] rounded-xl text-[#202B2A] focus:bg-white focus:outline-none focus:border-[#16856B] shadow-inner"
                placeholder="Draft content generating..."
              />
            </div>

            {/* Footer Stats Bar */}
            <div className="flex items-center justify-between text-[11px] text-[#687573] pt-1 border-t border-[#E1E7E4]">
              <span>Word Count: <strong>{draftText ? draftText.split(/\s+/).filter(Boolean).length : 0}</strong> words</span>
              <span>Characters: <strong>{draftText.length}</strong></span>
              <span>ReportLab PDF Ready: <strong>Yes</strong></span>
            </div>
          </div>
        </div>
      </div>

      {/* Return / Revisions In-Page Modal */}
      {showRejectModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-xl max-w-md w-full border border-[#E1E7E4] shadow-xl overflow-hidden p-5 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-[#202B2A]">Return Appeal for Clinical Revisions</h3>
              <button
                type="button"
                onClick={() => setShowRejectModal(false)}
                className="text-[#8E9C99] hover:text-[#202B2A]"
                aria-label="Close modal"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div>
              <label className="block text-xs font-semibold text-[#202B2A] mb-1">
                Clinical Revision Note / Grounds
              </label>
              <textarea
                rows={4}
                value={rejectReason}
                onChange={(e) => setRejectReason(e.target.value)}
                placeholder="Specify missing exhibits, needed diagnostic records, or edits required before final filing approval..."
                className="w-full text-xs border border-[#E1E7E4] rounded-lg p-2.5 bg-[#FAFAF7] text-[#202B2A] focus:outline-none focus:border-[#16856B] leading-relaxed"
              />
            </div>
            <div className="flex justify-end gap-2 pt-2 border-t border-[#E1E7E4]">
              <button
                type="button"
                onClick={() => setShowRejectModal(false)}
                className="px-3.5 py-1.5 rounded-lg border border-[#E1E7E4] text-xs font-semibold text-[#687573] hover:bg-[#F1F3F2]"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmRejection}
                disabled={saving}
                className="px-3.5 py-1.5 rounded-lg bg-[#D87568] hover:bg-[#A64336] text-white text-xs font-semibold"
              >
                {saving ? 'Saving...' : 'Confirm Return for Revisions'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
