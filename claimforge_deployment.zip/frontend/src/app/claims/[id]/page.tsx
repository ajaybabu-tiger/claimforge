'use client';

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import { useParams, useRouter } from 'next/navigation';
import {
  FileText,
  Sparkles,
  ArrowLeft,
  ArrowRight,
  Upload,
  RefreshCw,
  CheckCircle2,
  AlertTriangle,
  Scale,
  Plus,
  ShieldCheck,
  Eye,
  Trash2,
  Layers,
  FileCheck2,
  FolderOpen,
  MessageSquare,
  X,
  AlertCircle
} from 'lucide-react';
import { api } from '@/lib/api';
import { Claim, Document, FindingsGrouped, ReadinessScore } from '@/lib/types';
import { formatCurrency, formatDate } from '@/lib/utils';
import { ClaimStatusBadge, PriorityBadge } from '@/components/StatusBadge';
import ReadinessGauge from '@/components/ReadinessGauge';
import FindingsList from '@/components/FindingsList';
import CrossDocMatrix from '@/components/CrossDocMatrix';
import DocumentViewerModal from '@/components/DocumentViewerModal';

export default function ClaimDetailPage() {
  const params = useParams();
  const router = useRouter();
  const claimId = params.id as string;

  const [claim, setClaim] = useState<Claim | null>(null);
  const [documents, setDocuments] = useState<Document[]>([]);
  const [findingsGrouped, setFindingsGrouped] = useState<FindingsGrouped | null>(null);
  const [readinessScore, setReadinessScore] = useState<ReadinessScore | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [banner, setBanner] = useState<{ type: 'success' | 'error'; message: string } | null>(null);
  const [activeTab, setActiveTab] = useState<'findings' | 'matrix' | 'documents' | 'notes'>('findings');
  const [analyzing, setAnalyzing] = useState(false);
  const [selectedDocForModal, setSelectedDocForModal] = useState<Document | null>(null);

  // Reviewer notes
  const [reviewerNotes, setReviewerNotes] = useState('');
  const [savingNotes, setSavingNotes] = useState(false);
  const [notesSaved, setNotesSaved] = useState(false);

  // Quick document upload
  const [uploadingDoc, setUploadingDoc] = useState(false);
  const [newDocType, setNewDocType] = useState('medical_bill');

  const loadAllData = async () => {
    setError(null);
    try {
      const [c, docs, findings, readiness] = await Promise.all([
        api.getClaim(claimId),
        api.getClaimDocuments(claimId),
        api.getClaimFindings(claimId).catch(() => null),
        api.getClaimReadiness(claimId).catch(() => null),
      ]);
      setClaim(c);
      setReviewerNotes(c.reviewer_notes || '');
      setDocuments(docs || []);
      setFindingsGrouped(findings);
      setReadinessScore(readiness);
    } catch (err: any) {
      console.error('Failed to load claim case:', err);
      setError(err.message || 'Failed to load case file from database.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (claimId) loadAllData();
  }, [claimId]);

  const handleRunAnalysis = async () => {
    setAnalyzing(true);
    setBanner(null);
    try {
      await api.triggerAnalysis(claimId);
      await loadAllData();
      setBanner({
        type: 'success',
        message: 'Verification complete! Cross-document findings and appeal readiness updated.'
      });
      setTimeout(() => setBanner(null), 4000);
    } catch (err: any) {
      setBanner({
        type: 'error',
        message: `Analysis failed: ${err.message || String(err)}`
      });
    } finally {
      setAnalyzing(false);
    }
  };

  const handleSaveNotes = async () => {
    setSavingNotes(true);
    setBanner(null);
    try {
      await api.updateClaim(claimId, { reviewer_notes: reviewerNotes });
      setClaim((prev) => (prev ? { ...prev, reviewer_notes: reviewerNotes } : null));
      setNotesSaved(true);
      setTimeout(() => setNotesSaved(false), 2500);
    } catch (err: any) {
      setBanner({
        type: 'error',
        message: `Failed to save notes: ${err.message || String(err)}`
      });
    } finally {
      setSavingNotes(false);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setUploadingDoc(true);
      setBanner(null);
      try {
        await api.uploadDocument(claimId, file, newDocType);
        await api.triggerAnalysis(claimId);
        await loadAllData();
        setBanner({
          type: 'success',
          message: `Document "${file.name}" uploaded and analyzed successfully!`
        });
        setTimeout(() => setBanner(null), 4000);
      } catch (err: any) {
        setBanner({
          type: 'error',
          message: `Upload failed: ${err.message || String(err)}`
        });
      } finally {
        setUploadingDoc(false);
      }
    }
  };

  const handleDeleteDocument = async (docId: string) => {
    if (!confirm('Are you sure you want to remove this document from the case file?')) return;
    setBanner(null);
    try {
      await api.deleteDocument(docId);
      await api.triggerAnalysis(claimId);
      await loadAllData();
      setBanner({
        type: 'success',
        message: 'Document deleted and analysis recomputed.'
      });
      setTimeout(() => setBanner(null), 3000);
    } catch (err: any) {
      setBanner({
        type: 'error',
        message: `Delete failed: ${err.message || String(err)}`
      });
    }
  };

  if (loading) {
    return (
      <div className="py-20 text-center text-[#687573] space-y-2">
        <RefreshCw className="w-6 h-6 text-[#16856B] animate-spin mx-auto" />
        <p className="text-xs font-semibold text-[#202B2A]">Loading case file & evidentiary records...</p>
      </div>
    );
  }

  if (error || !claim) {
    return (
      <div className="py-16 text-center space-y-4 max-w-md mx-auto">
        <AlertCircle className="w-10 h-10 text-[#D87568] mx-auto" />
        <div>
          <p className="text-sm font-bold text-[#202B2A]">Unable to Open Case File</p>
          <p className="text-xs text-[#687573] mt-1">{error || 'Case file does not exist in registry.'}</p>
        </div>
        <div className="flex justify-center gap-2">
          <button
            onClick={loadAllData}
            className="bg-[#123F3A] hover:bg-[#17524B] text-white text-xs font-semibold px-4 py-2 rounded-lg transition-colors"
          >
            Retry Loading
          </button>
          <Link
            href="/dashboard"
            className="bg-[#F1F3F2] hover:bg-[#E1E7E4] text-[#202B2A] border border-[#E1E7E4] text-xs font-semibold px-4 py-2 rounded-lg transition-colors"
          >
            Return to Dashboard
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Feedback Banner */}
      {banner && (
        <div
          className={`p-3.5 rounded-xl border text-xs flex items-center justify-between gap-3 animate-in fade-in duration-150 ${
            banner.type === 'success'
              ? 'bg-[#E6F4EF] text-[#123F3A] border-[#B0E1D4]'
              : 'bg-[#FCF3F1] text-[#A64336] border-[#F4CAC5]'
          }`}
        >
          <div className="flex items-center gap-2">
            {banner.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-[#16856B] shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-[#D87568] shrink-0" />
            )}
            <span className="font-semibold">{banner.message}</span>
          </div>
          <button
            onClick={() => setBanner(null)}
            className="text-inherit opacity-70 hover:opacity-100 p-1"
            aria-label="Dismiss notification"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Top Header Card */}
      <div className="bg-white rounded-xl border border-[#E1E7E4] shadow-xs p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          <Link
            href="/dashboard"
            className="p-2 rounded-lg border border-[#E1E7E4] text-[#687573] hover:text-[#202B2A] hover:bg-[#F1F3F2] mt-0.5"
            title="Back to Dashboard"
          >
            <ArrowLeft className="w-4 h-4" />
          </Link>
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-lg sm:text-xl font-bold text-[#202B2A] font-mono tracking-tight">
                {claim.claim_reference}
              </span>
              <ClaimStatusBadge status={claim.status} />
              <PriorityBadge priority={claim.review_priority} />
            </div>
            <p className="text-xs text-[#687573] mt-1">
              Insurer: <strong>{claim.insurer_name}</strong> &bull; Patient: <strong>{claim.patient_reference}</strong> &bull; DOS: {formatDate(claim.date_of_service)} &bull; Policy: {claim.policy_number || 'N/A'}
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={handleRunAnalysis}
            disabled={analyzing}
            className="inline-flex items-center gap-1.5 bg-[#F1F3F2] hover:bg-[#E1E7E4] text-[#202B2A] border border-[#E1E7E4] px-3.5 py-2 rounded-lg text-xs font-semibold transition-colors disabled:opacity-50"
            title="Re-run PyMuPDF extraction and rule-based verification"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-[#16856B] ${analyzing ? 'animate-spin' : ''}`} />
            <span>{analyzing ? 'Analyzing...' : 'Re-run Verification'}</span>
          </button>

          <Link
            href={`/claims/${claim.id}/appeal`}
            className="inline-flex items-center gap-1.5 bg-[#123F3A] hover:bg-[#17524B] text-white px-4 py-2 rounded-lg text-xs font-semibold shadow-xs transition-colors"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#16856B]" />
            <span>Appeal Letter Editor</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>
      </div>

      {/* Case Overview Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
        <div className="bg-white p-4 rounded-xl border border-[#E1E7E4] shadow-xs">
          <span className="text-[10px] font-bold text-[#687573] uppercase tracking-wider block">
            Disputed Billed Amount
          </span>
          <div className="text-xl font-bold text-[#123F3A] tabular-nums font-mono mt-1">
            {formatCurrency(claim.claim_amount)}
          </div>
          <span className="text-[10px] text-[#687573]">Subject to statutory appeal</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-[#E1E7E4] shadow-xs">
          <span className="text-[10px] font-bold text-[#687573] uppercase tracking-wider block">
            Remittance Denial Code
          </span>
          <div className="text-xl font-bold text-[#D87568] font-mono mt-1">
            {claim.rejection_code || 'Notice'}
          </div>
          <span className="text-[10px] text-[#687573]">CARC / Determination code</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-[#E1E7E4] shadow-xs sm:col-span-1">
          <span className="text-[10px] font-bold text-[#687573] uppercase tracking-wider block">
            Target Denial Reason
          </span>
          <p className="text-xs font-medium text-[#202B2A] italic mt-1 line-clamp-2" title={claim.rejection_reason}>
            &ldquo;{claim.rejection_reason}&rdquo;
          </p>
        </div>
      </div>

      {/* Appeal Readiness Assessment Widget */}
      <ReadinessGauge scoreData={readinessScore} />

      {/* Detail Navigation Tabs */}
      <div className="space-y-4">
        <div className="flex border-b border-[#E1E7E4] gap-2 text-xs font-semibold bg-white px-2 pt-2 rounded-t-xl border-x">
          <button
            onClick={() => setActiveTab('findings')}
            className={`pb-2.5 px-3 border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'findings'
                ? 'border-[#123F3A] text-[#123F3A] font-bold'
                : 'border-transparent text-[#687573] hover:text-[#202B2A]'
            }`}
          >
            <span>Categorized Findings</span>
            <span className="bg-[#E6F4EF] text-[#123F3A] border border-[#B0E1D4] px-1.5 py-0.2 rounded-full text-[10px] font-mono">
              {findingsGrouped?.total_findings || 0}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('matrix')}
            className={`pb-2.5 px-3 border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'matrix'
                ? 'border-[#123F3A] text-[#123F3A] font-bold'
                : 'border-transparent text-[#687573] hover:text-[#202B2A]'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Cross-Doc Matrix</span>
          </button>

          <button
            onClick={() => setActiveTab('documents')}
            className={`pb-2.5 px-3 border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'documents'
                ? 'border-[#123F3A] text-[#123F3A] font-bold'
                : 'border-transparent text-[#687573] hover:text-[#202B2A]'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Uploaded Records</span>
            <span className="bg-[#F1F3F2] text-[#687573] px-1.5 py-0.2 rounded-full text-[10px]">
              {documents.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('notes')}
            className={`pb-2.5 px-3 border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'notes'
                ? 'border-[#123F3A] text-[#123F3A] font-bold'
                : 'border-transparent text-[#687573] hover:text-[#202B2A]'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>Reviewer Notes</span>
          </button>
        </div>

        {/* Tab 1: Findings */}
        {activeTab === 'findings' && (
          <div className="space-y-4">
            <div className="bg-[#E6F4EF]/70 border border-[#B0E1D4] p-3.5 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-[#16856B] shrink-0" />
                <span className="text-[#123F3A]">
                  Confirm or dismiss findings below. Verified findings are incorporated into the appeal draft.
                </span>
              </div>
              <Link
                href={`/claims/${claim.id}/appeal`}
                className="inline-flex items-center gap-1 bg-[#123F3A] hover:bg-[#17524B] text-white px-3 py-1.5 rounded-lg text-xs font-semibold shrink-0"
              >
                <span>Generate Appeal Draft</span>
                <ArrowRight className="w-3 h-3" />
              </Link>
            </div>

            {findingsGrouped && findingsGrouped.total_findings > 0 ? (
              <FindingsList
                findingsGrouped={findingsGrouped}
                onFindingUpdated={loadAllData}
              />
            ) : (
              <div className="bg-white rounded-xl border border-[#E1E7E4] p-8 text-center text-[#687573] space-y-3">
                <AlertCircle className="w-8 h-8 text-[#C7DFD7] mx-auto opacity-70" />
                <div>
                  <p className="text-xs font-semibold text-[#202B2A]">No Analysis Findings Recorded Yet</p>
                  <p className="text-[11px] text-[#687573] mt-0.5 max-w-sm mx-auto">
                    Run the entity extraction and statutory cross-referencing engine to detect appeal grounds.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={handleRunAnalysis}
                  disabled={analyzing}
                  className="inline-flex items-center gap-1.5 bg-[#123F3A] hover:bg-[#17524B] text-white px-4 py-2 rounded-lg text-xs font-semibold transition-colors disabled:opacity-50"
                >
                  <RefreshCw className={`w-3.5 h-3.5 text-[#16856B] ${analyzing ? 'animate-spin' : ''}`} />
                  <span>{analyzing ? 'Analyzing Medical Evidence...' : 'Run Automated Verification'}</span>
                </button>
              </div>
            )}
          </div>
        )}

        {/* Tab 2: Cross-Document Matrix */}
        {activeTab === 'matrix' && (
          <CrossDocMatrix documents={documents} />
        )}

        {/* Tab 3: Uploaded Documents */}
        {activeTab === 'documents' && (
          <div className="space-y-4">
            {/* Quick Upload Bar */}
            <div className="bg-white p-4 rounded-xl border border-[#E1E7E4] shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h4 className="text-xs font-bold text-[#202B2A] uppercase tracking-wider">
                  Attach Additional Record to Case File
                </h4>
                <p className="text-[11px] text-[#687573]">
                  Attach more clinical notes, imaging reports, or itemized bills to increase evidence completeness.
                </p>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <select
                  value={newDocType}
                  onChange={(e) => setNewDocType(e.target.value)}
                  className="text-xs border border-[#E1E7E4] rounded-lg px-2.5 py-1.5 bg-[#FAFAF7] text-[#202B2A]"
                >
                  <option value="medical_bill">Itemized Medical Bill</option>
                  <option value="discharge_summary">Discharge / Operative Note</option>
                  <option value="diagnostic_report">Diagnostic / MRI Report</option>
                  <option value="denial_letter">Denial Letter / EOB</option>
                  <option value="prescription">Prescription / Pharmacy</option>
                  <option value="pre_auth">Prior Authorization</option>
                  <option value="other">Other Clinical Record</option>
                </select>

                <label className="inline-flex items-center gap-1.5 bg-[#123F3A] hover:bg-[#17524B] text-white px-3.5 py-1.5 rounded-lg text-xs font-semibold cursor-pointer shadow-xs transition-colors">
                  <Upload className="w-3.5 h-3.5" />
                  <span>{uploadingDoc ? 'Uploading...' : 'Upload File'}</span>
                  <input
                    type="file"
                    accept=".pdf,.png,.jpg,.jpeg,.webp"
                    onChange={handleFileUpload}
                    disabled={uploadingDoc}
                    className="hidden"
                  />
                </label>
              </div>
            </div>

            {/* Document Cards Grid / Empty State */}
            {documents.length === 0 ? (
              <div className="bg-white p-8 rounded-xl border border-[#E1E7E4] text-center text-[#687573] space-y-2">
                <FileText className="w-8 h-8 text-[#C7DFD7] mx-auto opacity-70" />
                <p className="text-xs font-semibold text-[#202B2A]">No Evidence Documents Attached</p>
                <p className="text-[11px] text-[#687573] max-w-sm mx-auto">
                  Attach hospital bills, clinical discharge summaries, or denial letters using the upload bar above.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              {documents.map((doc) => (
                <div
                  key={doc.id}
                  className="bg-white p-4 rounded-xl border border-[#E1E7E4] shadow-xs flex items-start justify-between gap-3"
                >
                  <div className="space-y-1.5 truncate flex-1">
                    <div className="flex items-center gap-2 truncate">
                      <FileText className="w-4 h-4 text-[#16856B] shrink-0" />
                      <h4 className="text-xs font-bold text-[#202B2A] truncate" title={doc.original_filename}>
                        {doc.original_filename}
                      </h4>
                    </div>

                    <p className="text-[11px] text-[#687573]">
                      Type: <strong>{doc.document_type.replace(/_/g, ' ')}</strong> &bull; {doc.page_count} page(s) &bull; {(doc.file_size / 1024).toFixed(1)} KB
                    </p>

                    <div className="flex items-center gap-2">
                      <span className="text-[10px] bg-[#E6F4EF] text-[#123F3A] border border-[#B0E1D4] px-1.5 py-0.2 rounded font-semibold uppercase">
                        {doc.processing_status}
                      </span>
                      {doc.extracted_text && (
                        <span className="text-[10px] text-[#687573]">
                          {doc.extracted_text.split(/\s+/).length} words extracted
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      onClick={() => setSelectedDocForModal(doc)}
                      className="p-1.5 rounded-lg border border-[#E1E7E4] text-[#687573] hover:text-[#202B2A] hover:bg-[#F1F3F2]"
                      title="Inspect Extracted Text & Entities"
                    >
                      <Eye className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => handleDeleteDocument(doc.id)}
                      className="p-1.5 rounded-lg border border-[#E1E7E4] text-[#8E9C99] hover:text-[#D87568] hover:bg-[#F1F3F2]"
                      title="Delete Document"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
            )}
          </div>
        )}

        {/* Tab 4: Reviewer Notes */}
        {activeTab === 'notes' && (
          <div className="bg-white p-5 rounded-xl border border-[#E1E7E4] shadow-xs space-y-3">
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-[#202B2A]">
                Internal Case Reviewer Notes
              </h4>
              <p className="text-[11px] text-[#687573] mt-0.5">
                Record clinical determinations, attorney or patient conference observations, and appeal strategy rationales.
              </p>
            </div>

            <textarea
              rows={6}
              value={reviewerNotes}
              onChange={(e) => setReviewerNotes(e.target.value)}
              className="w-full text-xs border border-[#E1E7E4] rounded-lg p-3 bg-[#FAFAF7] focus:bg-white focus:outline-none focus:border-[#16856B] text-[#202B2A] leading-relaxed"
              placeholder="Enter internal review notes, clinical impressions, or supervisor instructions..."
            />

            <div className="flex items-center gap-2">
              <button
                onClick={handleSaveNotes}
                disabled={savingNotes}
                className="bg-[#123F3A] hover:bg-[#17524B] text-white text-xs font-semibold px-4 py-2 rounded-lg transition-colors"
              >
                {savingNotes ? 'Saving...' : 'Save Case Notes'}
              </button>
              {notesSaved && (
                <span className="text-xs font-semibold text-[#16856B] flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Notes saved successfully!</span>
                </span>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Modal for viewing extracted document text */}
      <DocumentViewerModal
        document={selectedDocForModal}
        onClose={() => setSelectedDocForModal(null)}
      />
    </div>
  );
}
