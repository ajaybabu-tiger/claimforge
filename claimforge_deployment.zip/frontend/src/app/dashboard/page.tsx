'use client';

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import {
  PlusCircle,
  Search,
  FileText,
  Sparkles,
  ArrowRight,
  RefreshCw,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Layers,
  ArrowUpRight,
  AlertCircle,
  FileCheck2,
  Scale,
  X
} from 'lucide-react';
import { api } from '@/lib/api';
import { Claim, DashboardStats } from '@/lib/types';
import { formatCurrency, formatDate, getReadinessColor } from '@/lib/utils';
import { ClaimStatusBadge, PriorityBadge } from '@/components/StatusBadge';

export default function DashboardPage() {
  const [claims, setClaims] = useState<Claim[]>([]);
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [seeding, setSeeding] = useState(false);
  const [banner, setBanner] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const loadData = async () => {
    setLoading(true);
    setError(null);
    try {
      const [claimsData, statsData] = await Promise.all([
        api.getClaims(statusFilter === 'all' ? undefined : statusFilter, search || undefined),
        api.getDashboardStats().catch(() => null)
      ]);
      setClaims(claimsData || []);
      setStats(statsData);
    } catch (err: any) {
      console.error('Failed to load dashboard data:', err);
      setError(err.message || 'Failed to connect to backend database.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [statusFilter]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    loadData();
  };

  const handleClearSearch = () => {
    setSearch('');
    api.getClaims(statusFilter === 'all' ? undefined : statusFilter, undefined)
      .then((data) => setClaims(data || []))
      .catch((err) => setError(err.message || 'Search reset failed'));
  };

  const handleSeedData = async () => {
    setSeeding(true);
    setBanner(null);
    try {
      await api.seedDemoData();
      await loadData();
      setBanner({
        type: 'success',
        message: 'Successfully seeded 4 synthetic demo cases with extracted documents & findings!'
      });
      setTimeout(() => setBanner(null), 5000);
    } catch (err: any) {
      setBanner({
        type: 'error',
        message: `Seeding failed: ${err.message || String(err)}`
      });
    } finally {
      setSeeding(false);
    }
  };

  const statusTabs = [
    { id: 'all', label: 'All Cases' },
    { id: 'draft', label: 'Draft' },
    { id: 'documents_uploaded', label: 'Docs Ingested' },
    { id: 'analyzed', label: 'Analyzed' },
    { id: 'appeal_generated', label: 'Appeal Ready' },
    { id: 'completed', label: 'Approved & Completed' },
  ];

  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 rounded-xl border border-[#E1E7E4] shadow-xs">
        <div>
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-md bg-[#E6F4EF] text-[#123F3A] border border-[#B0E1D4] text-[11px] font-semibold mb-2">
            <ShieldCheckIcon className="w-3.5 h-3.5 text-[#16856B]" />
            <span>Healthcare Claim Verification & Rebuttal Workspace</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-[#202B2A]">
            Claims Overview & Verification
          </h1>
          <p className="text-xs text-[#687573] mt-1 max-w-2xl leading-relaxed">
            Track incoming denial determinations, verify evidence completeness across medical records, and prepare statutory appeal packets.
          </p>
        </div>

        <div className="flex items-center gap-2.5 shrink-0">
          <button
            onClick={handleSeedData}
            disabled={seeding}
            className="flex items-center gap-1.5 bg-[#F1F3F2] hover:bg-[#E1E7E4] text-[#202B2A] border border-[#E1E7E4] px-3.5 py-2 rounded-lg text-xs font-semibold transition-colors disabled:opacity-50"
            title="Populate 4 synthetic demo cases"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-[#16856B] ${seeding ? 'animate-spin' : ''}`} />
            <span>{seeding ? 'Seeding Scenarios...' : 'Seed Demo Cases'}</span>
          </button>

          <Link
            href="/claims/new"
            className="flex items-center gap-1.5 bg-[#123F3A] hover:bg-[#17524B] text-white px-4 py-2 rounded-lg text-xs font-semibold shadow-xs transition-colors"
          >
            <PlusCircle className="w-3.5 h-3.5" />
            <span>New Claim Intake</span>
          </Link>
        </div>
      </div>

      {/* Feedback Banner */}
      {banner && (
        <div
          className={`p-3.5 rounded-xl border text-xs flex items-center justify-between gap-3 animate-in fade-in duration-150 ${
            banner.type === 'success'
              ? 'bg-[#E6F4EF] text-[#123F3A] border-[#B0E1D4]'
              : 'bg-[#FCF3F1] text-[#A64336] border-[#F4CAC5]'
          }`}
        >
          <div className="flex items-center gap-2">
            {banner.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-[#16856B] shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-[#D87568] shrink-0" />
            )}
            <span className="font-semibold">{banner.message}</span>
          </div>
          <button
            onClick={() => setBanner(null)}
            className="text-inherit opacity-70 hover:opacity-100 p-1"
            aria-label="Dismiss banner"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3.5">
        {/* KPI 1: Total Claims */}
        <div className="bg-white p-4 rounded-xl border border-[#E1E7E4] shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-[#687573] text-[11px] font-semibold uppercase tracking-wider">
            <span>Total Claims</span>
            <FileText className="w-4 h-4 text-[#16856B]" />
          </div>
          <div className="mt-2">
            <div className="text-2xl font-bold text-[#202B2A] tabular-nums">
              {stats ? stats.total_claims : claims.length}
            </div>
            <span className="text-[11px] text-[#687573] font-medium">In case registry</span>
          </div>
        </div>

        {/* KPI 2: Awaiting Review */}
        <div className="bg-white p-4 rounded-xl border border-[#E1E7E4] shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-[#687573] text-[11px] font-semibold uppercase tracking-wider">
            <span>Awaiting Review</span>
            <Clock className="w-4 h-4 text-[#C39B4A]" />
          </div>
          <div className="mt-2">
            <div className="text-2xl font-bold text-[#202B2A] tabular-nums">
              {stats
                ? stats.awaiting_review
                : claims.filter((c) => c.status === 'draft' || c.status === 'in_review').length}
            </div>
            <span className="text-[11px] text-[#C39B4A] font-medium">Pending intake review</span>
          </div>
        </div>

        {/* KPI 3: Missing Evidence */}
        <div className="bg-white p-4 rounded-xl border border-[#E1E7E4] shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-[#687573] text-[11px] font-semibold uppercase tracking-wider">
            <span>Evidence Gaps</span>
            <AlertCircle className="w-4 h-4 text-[#D87568]" />
          </div>
          <div className="mt-2">
            <div className="text-2xl font-bold text-[#202B2A] tabular-nums">
              {stats
                ? stats.missing_evidence
                : claims.filter((c) => (c.documents_count !== undefined && c.documents_count < 2) || c.status === 'draft').length}
            </div>
            <span className="text-[11px] text-[#D87568] font-medium">Missing primary bill or EOB</span>
          </div>
        </div>

        {/* KPI 4: Completed Reviews */}
        <div className="bg-white p-4 rounded-xl border border-[#E1E7E4] shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-[#687573] text-[11px] font-semibold uppercase tracking-wider">
            <span>Completed</span>
            <CheckCircle2 className="w-4 h-4 text-[#16856B]" />
          </div>
          <div className="mt-2">
            <div className="text-2xl font-bold text-[#202B2A] tabular-nums">
              {stats ? stats.completed_reviews : claims.filter((c) => c.status === 'completed').length}
            </div>
            <span className="text-[11px] text-[#16856B] font-medium">Reviewer approved</span>
          </div>
        </div>

        {/* KPI 5: Total Disputed Value */}
        <div className="bg-white p-4 rounded-xl border border-[#E1E7E4] shadow-xs flex flex-col justify-between col-span-2 lg:col-span-1">
          <div className="flex items-center justify-between text-[#687573] text-[11px] font-semibold uppercase tracking-wider">
            <span>Disputed Value</span>
            <Scale className="w-4 h-4 text-[#123F3A]" />
          </div>
          <div className="mt-2">
            <div className="text-xl font-bold text-[#123F3A] tabular-nums">
              {stats
                ? formatCurrency(stats.total_disputed_amount)
                : formatCurrency(claims.reduce((acc, c) => acc + (c.claim_amount || 0), 0))}
            </div>
            <span className="text-[11px] text-[#16856B] font-medium">
              Avg Readiness:{' '}
              {stats && stats.avg_readiness_score > 0
                ? `${Math.round(stats.avg_readiness_score)}%`
                : (() => {
                    const scored = claims.filter((c) => c.latest_readiness_score !== null && c.latest_readiness_score !== undefined);
                    return scored.length > 0
                      ? `${Math.round(scored.reduce((acc, c) => acc + c.latest_readiness_score!, 0) / scored.length)}%`
                      : 'N/A';
                  })()}
            </span>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-xl border border-[#E1E7E4] p-3 shadow-xs flex flex-col md:flex-row items-center justify-between gap-3">
        {/* Status Filter Tabs */}
        <div className="flex items-center gap-1 overflow-x-auto w-full md:w-auto pb-1 md:pb-0">
          {statusTabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setStatusFilter(tab.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                statusFilter === tab.id
                  ? 'bg-[#123F3A] text-white shadow-2xs'
                  : 'text-[#687573] hover:text-[#202B2A] hover:bg-[#F1F3F2]'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Search Input */}
        <form onSubmit={handleSearchSubmit} className="flex items-center gap-2 w-full md:w-80">
          <div className="relative flex-1">
            <Search className="w-3.5 h-3.5 text-[#687573] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search reference, patient, insurer..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full text-xs bg-[#FAFAF7] border border-[#E1E7E4] rounded-lg pl-8 pr-8 py-1.5 focus:outline-none focus:border-[#16856B] focus:bg-white text-[#202B2A]"
            />
            {search && (
              <button
                type="button"
                onClick={handleClearSearch}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#8E9C99] hover:text-[#202B2A]"
                title="Clear search"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
          <button
            type="submit"
            className="bg-[#F1F3F2] hover:bg-[#E1E7E4] text-[#202B2A] text-xs font-semibold px-3 py-1.5 rounded-lg border border-[#E1E7E4] transition-colors"
          >
            Filter
          </button>
        </form>
      </div>

      {/* Claims Table Container */}
      <div className="bg-white rounded-xl border border-[#E1E7E4] shadow-xs overflow-hidden">
        {loading ? (
          <div className="p-12 text-center text-[#687573] space-y-2">
            <RefreshCw className="w-5 h-5 text-[#16856B] animate-spin mx-auto" />
            <p className="text-xs font-medium">Loading claims from registry...</p>
          </div>
        ) : error ? (
          <div className="p-10 text-center space-y-3 bg-[#FCF3F1]/40">
            <AlertCircle className="w-8 h-8 text-[#D87568] mx-auto" />
            <div>
              <p className="text-sm font-bold text-[#A64336]">Registry Connection Issue</p>
              <p className="text-xs text-[#687573] max-w-md mx-auto mt-1">{error}</p>
            </div>
            <button
              onClick={loadData}
              className="inline-flex items-center gap-1.5 bg-[#123F3A] hover:bg-[#17524B] text-white text-xs font-semibold px-4 py-2 rounded-lg transition-colors"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Retry Loading Registry</span>
            </button>
          </div>
        ) : claims.length === 0 ? (
          <div className="p-12 text-center text-[#687573] space-y-3">
            <FileText className="w-9 h-9 text-[#C7DFD7] mx-auto" />
            <div>
              <p className="text-sm font-semibold text-[#202B2A]">No insurance claims found</p>
              <p className="text-xs text-[#687573] max-w-sm mx-auto mt-0.5">
                Create a new claim with medical records or load the 4 pre-configured synthetic hackathon scenarios.
              </p>
            </div>
            <div className="pt-2 flex justify-center gap-2">
              <button
                onClick={handleSeedData}
                disabled={seeding}
                className="bg-[#F1F3F2] hover:bg-[#E1E7E4] text-[#202B2A] border border-[#E1E7E4] text-xs font-semibold px-3.5 py-1.5 rounded-lg transition-colors"
              >
                {seeding ? 'Seeding Scenarios...' : 'Seed 4 Synthetic Scenarios'}
              </button>
              <Link
                href="/claims/new"
                className="bg-[#123F3A] hover:bg-[#17524B] text-white text-xs font-semibold px-3.5 py-1.5 rounded-lg transition-colors"
              >
                New Intake
              </Link>
            </div>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs min-w-[960px]">
              <thead className="bg-[#FAFAF7] text-[#687573] font-semibold border-b border-[#E1E7E4]">
                <tr>
                  <th className="py-3 px-4 whitespace-nowrap">Claim Ref</th>
                  <th className="py-3 px-4 whitespace-nowrap">Patient Reference</th>
                  <th className="py-3 px-4 whitespace-nowrap">Insurer</th>
                  <th className="py-3 px-4 whitespace-nowrap">Disputed Amount</th>
                  <th className="py-3 px-4 whitespace-nowrap">Date of Service</th>
                  <th className="py-3 px-4 whitespace-nowrap">Status</th>
                  <th className="py-3 px-4 whitespace-nowrap">Priority</th>
                  <th className="py-3 px-4 whitespace-nowrap">Appeal Readiness</th>
                  <th className="py-3 px-4 text-right whitespace-nowrap">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E1E7E4]">
                {claims.map((claim) => {
                  const score = claim.latest_readiness_score;
                  const readinessStyle = score !== null && score !== undefined ? getReadinessColor(score) : null;

                  return (
                    <tr key={claim.id} className="hover:bg-[#FAFAF7]/70 transition-colors">
                      <td className="py-3 px-4 font-bold text-[#123F3A]">
                        <Link href={`/claims/${claim.id}`} className="hover:underline flex items-center gap-1.5 font-mono">
                          <FileText className="w-3.5 h-3.5 text-[#16856B] shrink-0" />
                          <span>{claim.claim_reference}</span>
                        </Link>
                      </td>
                      <td className="py-3 px-4 font-medium text-[#202B2A]">{claim.patient_reference}</td>
                      <td className="py-3 px-4 text-[#202B2A]">{claim.insurer_name}</td>
                      <td className="py-3 px-4 font-bold text-[#202B2A] tabular-nums">
                        {formatCurrency(claim.claim_amount)}
                      </td>
                      <td className="py-3 px-4 text-[#687573] tabular-nums">{formatDate(claim.date_of_service)}</td>
                      <td className="py-3 px-4">
                        <ClaimStatusBadge status={claim.status} />
                      </td>
                      <td className="py-3 px-4">
                        <PriorityBadge priority={claim.review_priority} />
                      </td>
                      <td className="py-3 px-4">
                        {readinessStyle ? (
                          <div className="flex items-center gap-1.5">
                            <span className="font-bold text-[#202B2A] tabular-nums">{Math.round(score!)}%</span>
                            <span className={`text-[10px] px-2 py-0.2 rounded font-semibold border ${readinessStyle.badge}`}>
                              {readinessStyle.level}
                            </span>
                          </div>
                        ) : (
                          <span className="text-[#8E9C99] italic">Pending Analysis</span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <Link
                            href={`/claims/${claim.id}`}
                            className="bg-[#F1F3F2] hover:bg-[#E1E7E4] text-[#202B2A] border border-[#E1E7E4] font-semibold px-2.5 py-1 rounded text-xs transition-colors"
                          >
                            Review
                          </Link>
                          <Link
                            href={`/claims/${claim.id}/appeal`}
                            className="bg-[#E6F4EF] hover:bg-[#D7F0E9] text-[#123F3A] border border-[#B0E1D4] font-semibold px-2.5 py-1 rounded text-xs transition-colors flex items-center gap-1"
                          >
                            <span>Appeal</span>
                            <ArrowUpRight className="w-3 h-3 text-[#16856B]" />
                          </Link>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

function ShieldCheckIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
      <path d="m9 12 2 2 4-4" />
    </svg>
  );
}
