import type { Metadata } from 'next';
import './globals.css';
import AppShell from '@/components/AppShell';

export const metadata: Metadata = {
  title: 'ClaimForge | Turn Claim Denials into Evidence-Backed Appeals',
  description: 'AI-assisted healthcare insurance claim verification and appeal preparation platform for the VISTERA 2026 National Hackathon.',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="bg-[#FAFAF7] text-[#202B2A] antialiased min-h-screen">
        <AppShell>
          {children}
        </AppShell>
      </body>
    </html>
  );
}
