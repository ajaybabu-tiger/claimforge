'use client';

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import {
  Sparkles,
  RefreshCw,
  FileCheck2,
  FileWarning,
  ShieldCheck,
  ArrowRight,
  ExternalLink,
  Scale,
  CheckCircle2,
  ArrowUpRight,
  Info,
  X,
  AlertCircle
} from 'lucide-react';
import { api } from '@/lib/api';
import { Claim } from '@/lib/types';
import { formatCurrency, getReadinessColor } from '@/lib/utils';

export default function DemoPage() {
  const router = useRouter();
  const [claims, setClaims] = useState<Claim[]>([]);
  const [seeding, setSeeding] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [banner, setBanner] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const loadData = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await api.getClaims();
      setClaims(data || []);
    } catch (err: any) {
      console.error('Failed to load demo cases:', err);
      setError(err.message || 'Failed to connect to backend.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleSeedAll = async () => {
    setSeeding(true);
    setBanner(null);
    try {
      await api.seedDemoData();
      await loadData();
      setBanner({
        type: 'success',
        message: 'Successfully seeded 4 synthetic clinical test cases with extracted documents and statutory findings!'
      });
      setTimeout(() => setBanner(null), 5000);
    } catch (err: any) {
      setBanner({
        type: 'error',
        message: `Seeding failed: ${err.message || String(err)}`
      });
    } finally {
      setSeeding(false);
    }
  };

  const scenarios = [
    {
      ref: 'CLM-2026-9011',
      title: 'Emergency Appendectomy Prior-Auth Dispute',
      insurer: 'BlueShield Horizon',
      patient: 'Alexander Wright (PAT-EMERG-441)',
      amount: 8450.0,
      code: 'CO-197',
      denial: 'Missing prior authorization for acute inpatient surgical admission.',
      discovery: 'Cross-referencing ER discharge records proves acute emergency admission. Prior authorization requirement is prohibited under federal EMTALA (42 U.S.C. § 1395dd) and ACA § 2719A.',
      score: 93.8,
      level: 'High Readiness',
    },
    {
      ref: 'CLM-2026-7823',
      title: 'Cardiac MRI Medical Necessity Rebuttal',
      insurer: 'Aetna Premier Health',
      patient: 'Eleanor Vance (PAT-CARDIO-102)',
      amount: 3200.0,
      code: 'CO-50',
      denial: 'Denied as not medically necessary / investigational diagnostic imaging.',
      discovery: 'Diagnostic MRI with contrast for dilated cardiomyopathy is supported by ACC/AHA Class I clinical guidelines. Engine flags missing UB-04 billing ledger as a gap to address.',
      score: 74.0,
      level: 'Moderate Readiness',
    },
    {
      ref: 'CLM-2026-3118',
      title: 'Emergency Out-of-Network Balance Billing',
      insurer: 'Cigna Global Care',
      patient: 'David Chen (PAT-ORTHO-802)',
      amount: 5600.0,
      code: 'PR-204',
      denial: 'Out-of-network physician balance billing not covered under in-network plan tier.',
      discovery: 'Patient had no choice of on-call orthopedic surgeon during emergent trauma admission at an in-network hospital. Fully protected under federal No Surprises Act balance billing rules.',
      score: 94.0,
      level: 'High Readiness',
    },
    {
      ref: 'CLM-2026-4409',
      title: 'Altered Invoice & Document Integrity Flag',
      insurer: 'United Healthcare',
      patient: 'Jonathan Reed (PAT-TRAUMA-991)',
      amount: 14800.0,
      code: 'CO-16',
      denial: 'Billed amount exceeds allowable schedule and invoice contains unverified line items.',
      discovery: 'Mathematical discrepancy detected: Sum of itemized line items ($11,200.00) differs by $3,600.00 from modified stated total ($14,800.00). High font diversity flagged for reviewer inspection.',
      score: 42.0,
      level: 'Low Readiness',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl border border-[#E1E7E4] shadow-xs p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-md bg-[#E6F4EF] text-[#123F3A] border border-[#B0E1D4] text-[11px] font-semibold mb-2">
            <Sparkles className="w-3.5 h-3.5 text-[#16856B]" />
            <span>Interactive Hackathon Demo Launcher</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-[#202B2A]">
            Synthetic Scenario Fixtures
          </h1>
          <p className="text-xs text-[#687573] mt-1 max-w-2xl leading-relaxed">
            Explore ClaimForge using 4 realistic, pre-configured synthetic clinical cases without uploading real patient PHI or configuring external paid APIs.
          </p>
        </div>

        <button
          onClick={handleSeedAll}
          disabled={seeding}
          className="inline-flex items-center gap-2 bg-[#123F3A] hover:bg-[#17524B] text-white font-semibold px-4 py-2.5 rounded-lg text-xs shadow-xs transition-colors shrink-0 disabled:opacity-50"
        >
          <RefreshCw className={`w-3.5 h-3.5 text-[#16856B] ${seeding ? 'animate-spin' : ''}`} />
          <span>{seeding ? 'Seeding Fixtures...' : 'Reset & Re-Seed 4 Scenarios'}</span>
        </button>
      </div>

      {/* Feedback Banner */}
      {banner && (
        <div
          className={`p-3.5 rounded-xl border text-xs flex items-center justify-between gap-3 animate-in fade-in duration-150 ${
            banner.type === 'success'
              ? 'bg-[#E6F4EF] text-[#123F3A] border-[#B0E1D4]'
              : 'bg-[#FCF3F1] text-[#A64336] border-[#F4CAC5]'
          }`}
        >
          <div className="flex items-center gap-2">
            {banner.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-[#16856B] shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-[#D87568] shrink-0" />
            )}
            <span className="font-semibold">{banner.message}</span>
          </div>
          <button
            onClick={() => setBanner(null)}
            className="text-inherit opacity-70 hover:opacity-100 p-1"
            aria-label="Dismiss banner"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Error state */}
      {error && !loading && (
        <div className="p-4 bg-[#FCF3F1] border border-[#F4CAC5] rounded-xl text-xs text-[#A64336] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-[#D87568] shrink-0" />
            <span>{error}</span>
          </div>
          <button
            onClick={loadData}
            className="bg-[#123F3A] text-white text-xs font-semibold px-3 py-1.5 rounded-lg"
          >
            Retry
          </button>
        </div>
      )}

      {/* Scenarios Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {scenarios.map((sc, idx) => {
          const matchedClaim = claims.find((c) => c.claim_reference === sc.ref);
          const { badge } = getReadinessColor(sc.score);

          return (
            <div
              key={sc.ref}
              className="bg-white rounded-xl border border-[#E1E7E4] shadow-xs hover:border-[#B0E1D4] transition-all flex flex-col justify-between overflow-hidden"
            >
              <div className="p-5 space-y-3.5">
                {/* Header */}
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-[#123F3A] bg-[#E6F4EF] border border-[#B0E1D4] px-2 py-0.5 rounded">
                      Scenario #{idx + 1}
                    </span>
                    <h3 className="text-sm sm:text-base font-bold text-[#202B2A] mt-1.5 leading-snug">
                      {sc.title}
                    </h3>
                    <p className="text-[11px] text-[#687573] font-mono mt-0.5">
                      Ref: <strong className="text-[#202B2A]">{sc.ref}</strong> &bull; {sc.patient}
                    </p>
                  </div>

                  <div className="text-right shrink-0">
                    <span className="text-sm font-bold text-[#123F3A] tabular-nums font-mono">
                      {formatCurrency(sc.amount)}
                    </span>
                    <span className={`block text-[10px] font-semibold px-2 py-0.2 rounded border mt-1 ${badge}`}>
                      {Math.round(sc.score)}% Readiness
                    </span>
                  </div>
                </div>

                {/* Denial Info Box */}
                <div className="p-3 rounded-lg bg-[#FAFAF7] border border-[#E1E7E4] text-xs space-y-1">
                  <div className="flex items-center gap-1.5 text-[#687573] font-semibold text-[11px]">
                    <span>Insurer: {sc.insurer}</span>
                    <span>&bull;</span>
                    <span className="text-[#A64336] font-mono font-bold">Denial: {sc.code}</span>
                  </div>
                  <p className="text-[#202B2A] italic text-xs leading-relaxed">
                    &ldquo;{sc.denial}&rdquo;
                  </p>
                </div>

                {/* Statutory Discovery Rebuttal */}
                <div className="space-y-1 text-xs">
                  <span className="font-bold text-[#123F3A] uppercase tracking-wider text-[10px] flex items-center gap-1">
                    <Scale className="w-3.5 h-3.5 text-[#16856B]" />
                    <span>Engine Discovery & Statutory Rebuttal:</span>
                  </span>
                  <p className="text-[#687573] leading-relaxed bg-[#E6F4EF]/50 border border-[#B0E1D4] p-3 rounded-lg text-[11px]">
                    {sc.discovery}
                  </p>
                </div>
              </div>

              {/* Card Footer */}
              <div className="p-3.5 bg-[#FAFAF7] border-t border-[#E1E7E4] flex flex-wrap items-center justify-between gap-2 text-xs">
                <span className="text-[11px] text-[#687573]">
                  {matchedClaim ? 'Persisted in database' : 'Ready to seed'}
                </span>

                {matchedClaim ? (
                  <div className="flex items-center gap-1.5">
                    <Link
                      href={`/claims/${matchedClaim.id}`}
                      className="inline-flex items-center gap-1 bg-[#F1F3F2] hover:bg-[#E1E7E4] text-[#202B2A] border border-[#E1E7E4] text-xs font-semibold px-2.5 py-1.5 rounded-lg transition-colors"
                    >
                      <FileCheck2 className="w-3.5 h-3.5 text-[#16856B]" />
                      <span>Case File</span>
                    </Link>
                    <Link
                      href={`/claims/${matchedClaim.id}/appeal`}
                      className="inline-flex items-center gap-1 bg-[#123F3A] hover:bg-[#17524B] text-white text-xs font-semibold px-3 py-1.5 rounded-lg transition-colors shadow-2xs"
                    >
                      <span>Appeal Studio</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </Link>
                  </div>
                ) : (
                  <button
                    onClick={handleSeedAll}
                    disabled={seeding}
                    className="inline-flex items-center gap-1 bg-[#123F3A] hover:bg-[#17524B] text-white text-xs font-semibold px-3.5 py-1.5 rounded-lg transition-colors shadow-2xs"
                  >
                    <span>Seed & Load</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
