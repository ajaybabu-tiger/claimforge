'use client';

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import {
  ShieldCheck,
  FileCheck2,
  FileWarning,
  Sparkles,
  ArrowRight,
  CheckCircle2,
  AlertTriangle,
  Scale,
  FileText,
  Search,
  Lock,
  Layers,
  ChevronRight,
  Activity,
  FileSearch,
  Check
} from 'lucide-react';
import { api } from '@/lib/api';
import { DashboardStats } from '@/lib/types';
import { formatCurrency } from '@/lib/utils';

export default function LandingPage() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.getDashboardStats()
      .then((data) => {
        setStats(data);
        setLoading(false);
      })
      .catch(() => {
        setStats(null);
        setLoading(false);
      });
  }, []);

  return (
    <div className="flex flex-col min-h-full bg-[#FAFAF7]">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-[#123F3A] text-white pt-20 pb-24 px-4 sm:px-6 lg:px-8">
        {/* Subtle grid pattern background */}
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#16856B_1px,transparent_1px)] [background-size:24px_24px]" />

        <div className="relative max-w-5xl mx-auto text-center space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 border border-white/15 text-[#E6F4EF] text-xs font-semibold uppercase tracking-wider backdrop-blur-xs">
            <Sparkles className="w-3.5 h-3.5 text-[#16856B]" />
            <span>VISTERA 2026 National Hackathon Project</span>
          </div>

          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight leading-tight max-w-4xl mx-auto">
            Turn Medical Claim Denials into{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#16856B] via-[#99f6e4] to-[#E6F4EF]">
              Evidence-Backed Appeals
            </span>
          </h1>

          <p className="text-base sm:text-lg text-[#E6F4EF]/90 max-w-2xl mx-auto font-normal leading-relaxed">
            Every year, billions of dollars in legitimate healthcare claims are denied for documentation gaps and confusing remittance codes. ClaimForge empowers reviewers to verify evidence across clinical documents, uncover rebuttals, and assemble audit-ready appeal packets.
          </p>

          {/* Action CTAs */}
          <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3">
            <Link
              href="/dashboard"
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-[#16856B] hover:bg-[#126B56] text-white font-bold px-6 py-3 rounded-lg shadow-sm transition-all hover:scale-[1.01]"
            >
              <span>Open Claims Dashboard</span>
              <ArrowRight className="w-4 h-4" />
            </Link>

            <Link
              href="/demo"
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-white/10 hover:bg-white/15 text-white font-semibold px-6 py-3 rounded-lg border border-white/20 backdrop-blur-xs transition-colors"
            >
              <Sparkles className="w-4 h-4 text-[#16856B]" />
              <span>Explore 4 Demo Scenarios</span>
            </Link>
          </div>

          {/* Responsible AI Disclaimer Badge */}
          <div className="pt-4">
            <div className="inline-flex items-center gap-2 bg-white/5 border border-white/10 px-3.5 py-1.5 rounded-lg text-xs text-[#E6F4EF]/80">
              <Scale className="w-3.5 h-3.5 text-[#16856B] shrink-0" />
              <span>
                <strong>Human Decision Support:</strong> Assists clinical advocates and reviewers. Never fabricates facts or accuses parties of fraud.
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Live Metrics Ticker */}
      <section className="relative -mt-8 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 w-full z-10">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 bg-white rounded-xl border border-[#E1E7E4] shadow-sm p-4">
          <div className="p-3 text-center border-r border-[#E1E7E4] last:border-0">
            <p className="text-[11px] font-semibold uppercase tracking-wider text-[#687573]">Total Case Files</p>
            <p className="text-2xl font-bold text-[#202B2A] mt-1 tabular-nums">
              {stats ? stats.total_claims : loading ? '...' : '0'}
            </p>
            <p className="text-[10px] text-[#16856B] mt-0.5">Persisted in local database</p>
          </div>

          <div className="p-3 text-center border-r border-[#E1E7E4] last:border-0">
            <p className="text-[11px] font-semibold uppercase tracking-wider text-[#687573]">Disputed Value</p>
            <p className="text-2xl font-bold text-[#123F3A] mt-1 tabular-nums font-mono">
              {stats ? formatCurrency(stats.total_disputed_amount) : loading ? '...' : '$0.00'}
            </p>
            <p className="text-[10px] text-[#687573] mt-0.5">Total claims audited</p>
          </div>

          <div className="p-3 text-center border-r border-[#E1E7E4] last:border-0">
            <p className="text-[11px] font-semibold uppercase tracking-wider text-[#687573]">Avg Readiness</p>
            <p className="text-2xl font-bold text-[#16856B] mt-1 tabular-nums">
              {stats && stats.avg_readiness_score > 0 ? `${Math.round(stats.avg_readiness_score)}%` : loading ? '...' : 'N/A'}
            </p>
            <p className="text-[10px] text-[#16856B] mt-0.5">Evidence completeness</p>
          </div>

          <div className="p-3 text-center">
            <p className="text-[11px] font-semibold uppercase tracking-wider text-[#687573]">Completed Reviews</p>
            <p className="text-2xl font-bold text-[#202B2A] mt-1 tabular-nums">
              {stats ? stats.completed_reviews : loading ? '...' : '0'}
            </p>
            <p className="text-[10px] text-[#123F3A] mt-0.5">Approved & ready to file</p>
          </div>
        </div>
      </section>

      {/* The Reimbursement Challenge */}
      <section className="py-16 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-[11px] font-bold uppercase tracking-wider text-[#16856B] block mb-1">
            The Healthcare Reimbursement Challenge
          </span>
          <h2 className="text-2xl sm:text-3xl font-bold text-[#202B2A]">
            Why Legitimate Insurance Claims Fail
          </h2>
          <p className="text-xs text-[#687573] mt-2 leading-relaxed">
            Insurers deploy automated adjudication algorithms that reject claims at the slightest documentary gap. Without clinical cross-referencing, patients and hospitals struggle to decipher denial codes.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white p-5 rounded-xl border border-[#E1E7E4] shadow-xs">
            <div className="w-10 h-10 rounded-lg bg-[#FCF3F1] text-[#D87568] flex items-center justify-center mb-3">
              <FileWarning className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-bold text-[#202B2A] mb-1">Cryptic Remittance Denial Codes</h3>
            <p className="text-xs text-[#687573] leading-relaxed">
              Standard CARC codes like CO-197 (No Prior Auth) or CO-50 (Not Medically Necessary) often overlook statutory emergency exemptions under EMTALA or ACC/AHA clinical guidelines.
            </p>
          </div>

          <div className="bg-white p-5 rounded-xl border border-[#E1E7E4] shadow-xs">
            <div className="w-10 h-10 rounded-lg bg-[#FDF8EC] text-[#C39B4A] flex items-center justify-center mb-3">
              <Layers className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-bold text-[#202B2A] mb-1">Cross-Document Discrepancies</h3>
            <p className="text-xs text-[#687573] leading-relaxed">
              A 1-day variance between an admission ledger and operative note, or an unrounded decimal in a hospital billing statement, stalls an appeal indefinitely in payer queues.
            </p>
          </div>

          <div className="bg-white p-5 rounded-xl border border-[#E1E7E4] shadow-xs">
            <div className="w-10 h-10 rounded-lg bg-[#E6F4EF] text-[#16856B] flex items-center justify-center mb-3">
              <FileCheck2 className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-bold text-[#202B2A] mb-1">Scattered Supporting Evidence</h3>
            <p className="text-xs text-[#687573] leading-relaxed">
              Diagnostic imaging, physician progress notes, and itemized ledgers live in separate silos. Compiling a cohesive evidence packet manually takes clinical advocates hours per case.
            </p>
          </div>
        </div>
      </section>

      {/* 4-Step Verification Pipeline */}
      <section className="bg-[#F1F3F2]/50 border-y border-[#E1E7E4] py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <span className="text-[11px] font-bold uppercase tracking-wider text-[#16856B] block mb-1">
              Automated Decision Pipeline
            </span>
            <h2 className="text-2xl sm:text-3xl font-bold text-[#202B2A]">
              How ClaimForge Builds Winning Appeals
            </h2>
            <p className="text-xs text-[#687573] mt-2 leading-relaxed">
              A systematic 4-step pipeline that transforms raw medical records into an evidence-backed administrative appeal.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-white p-5 rounded-xl border border-[#E1E7E4] shadow-xs">
              <div className="w-8 h-8 rounded-lg bg-[#123F3A] text-white font-bold flex items-center justify-center text-xs mb-3">
                1
              </div>
              <h4 className="text-xs font-bold text-[#202B2A] uppercase tracking-wider mb-1">Document Ingestion</h4>
              <p className="text-xs text-[#687573] leading-relaxed">
                Upload itemized bills, discharge summaries, imaging reports, and formal denial letters. Local PyMuPDF extractor indexes text and tables.
              </p>
            </div>

            <div className="bg-white p-5 rounded-xl border border-[#E1E7E4] shadow-xs">
              <div className="w-8 h-8 rounded-lg bg-[#123F3A] text-white font-bold flex items-center justify-center text-xs mb-3">
                2
              </div>
              <h4 className="text-xs font-bold text-[#202B2A] uppercase tracking-wider mb-1">Clinical Entity Matching</h4>
              <p className="text-xs text-[#687573] leading-relaxed">
                Extracts standardized ICD-10 and CPT codes, compares dates and amounts across records, and scans for arithmetic mismatches.
              </p>
            </div>

            <div className="bg-white p-5 rounded-xl border border-[#E1E7E4] shadow-xs">
              <div className="w-8 h-8 rounded-lg bg-[#123F3A] text-white font-bold flex items-center justify-center text-xs mb-3">
                3
              </div>
              <h4 className="text-xs font-bold text-[#202B2A] uppercase tracking-wider mb-1">Readiness Scoring</h4>
              <p className="text-xs text-[#687573] leading-relaxed">
                Computes transparent 0–100 Appeal Readiness score broken down by Evidence Completeness, Consistency, Rebuttal Strength, and Integrity.
              </p>
            </div>

            <div className="bg-white p-5 rounded-xl border border-[#E1E7E4] shadow-xs">
              <div className="w-8 h-8 rounded-lg bg-[#123F3A] text-white font-bold flex items-center justify-center text-xs mb-3">
                4
              </div>
              <h4 className="text-xs font-bold text-[#202B2A] uppercase tracking-wider mb-1">Reviewer Sign-off & PDF</h4>
              <p className="text-xs text-[#687573] leading-relaxed">
                Reviewer edits the generated draft, confirms findings, selects preferred statutory tone, and exports an audit-ready PDF packet.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Demo Callout Banner */}
      <section className="py-14 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="bg-[#123F3A] text-white p-8 rounded-2xl shadow-sm flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="text-left space-y-1.5 max-w-xl">
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#E6F4EF] bg-white/10 border border-white/20 px-2 py-0.5 rounded">
              Ready for Judges
            </span>
            <h3 className="text-xl sm:text-2xl font-bold">Explore 4 Synthetic Healthcare Scenarios</h3>
            <p className="text-xs text-[#E6F4EF]/80 leading-relaxed">
              Test emergency prior-auth exemptions under EMTALA, cardiac MRI necessity, out-of-network balance billing under the No Surprises Act, and altered invoice integrity checks.
            </p>
          </div>

          <Link
            href="/demo"
            className="shrink-0 bg-[#16856B] hover:bg-[#126B56] text-white font-bold px-5 py-2.5 rounded-lg text-xs transition-colors shadow-2xs"
          >
            Launch Interactive Demo
          </Link>
        </div>
      </section>
    </div>
  );
}
