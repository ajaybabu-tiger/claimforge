'use client';

import React from 'react';
import { ReadinessScore } from '@/lib/types';
import { getReadinessColor } from '@/lib/utils';
import { Sparkles, ShieldCheck, Info, CheckCircle2, AlertTriangle } from 'lucide-react';

interface ReadinessGaugeProps {
  scoreData?: ReadinessScore | null;
  onRefresh?: () => void;
}

export default function ReadinessGauge({ scoreData }: ReadinessGaugeProps) {
  if (!scoreData) {
    return (
      <div className="bg-white rounded-xl border border-[#E1E7E4] p-6 text-center text-[#687573] shadow-xs">
        <Sparkles className="w-6 h-6 text-[#16856B] mx-auto mb-2 opacity-60" />
        <p className="text-xs font-semibold text-[#202B2A]">Readiness Assessment Pending</p>
        <p className="text-[11px] text-[#687573] mt-0.5">Click &ldquo;Re-run Verification&rdquo; to analyze uploaded medical records.</p>
      </div>
    );
  }

  const score = scoreData.readiness_score;
  const { color, bg, badge, level } = getReadinessColor(score);

  return (
    <div className="bg-white rounded-xl border border-[#E1E7E4] shadow-xs overflow-hidden">
      {/* Header Banner */}
      <div className="p-5 border-b border-[#E1E7E4] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-[#FAFAF7]">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#123F3A] bg-[#E6F4EF] border border-[#B0E1D4] px-2 py-0.2 rounded">
              Objective Decision Metric
            </span>
            <span className="text-[10px] text-[#687573] font-mono bg-white border border-[#E1E7E4] px-1.5 py-0.2 rounded">
              Engine: {scoreData.analysis_mode.toUpperCase()}
            </span>
          </div>
          <h3 className="text-sm sm:text-base font-bold text-[#202B2A]">
            Appeal Readiness Score
          </h3>
          <p className="text-xs text-[#687573] mt-0.5">
            Transparent scoring evaluated against Evidence Completeness, Consistency, Statutory Grounds, and Integrity.
          </p>
        </div>

        {/* Large Score Callout */}
        <div className="flex items-center gap-3 bg-white border border-[#E1E7E4] rounded-xl px-4 py-2.5 shadow-2xs shrink-0">
          <div className="text-right">
            <div className="text-2xl sm:text-3xl font-extrabold text-[#202B2A] tabular-nums leading-none">
              {Math.round(score)}<span className="text-sm font-normal text-[#8E9C99]">/100</span>
            </div>
            <span className={`inline-block mt-1 text-[10px] font-semibold px-2 py-0.2 rounded border ${badge}`}>
              {level}
            </span>
          </div>

          <div className="w-10 h-10 rounded-full border-2 border-[#E1E7E4] flex items-center justify-center relative shrink-0">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white font-bold text-xs ${bg}`}>
              {Math.round(score)}%
            </div>
          </div>
        </div>
      </div>

      {/* Executive Summary Callout */}
      <div className="px-5 py-2.5 bg-[#E6F4EF]/70 border-b border-[#B0E1D4] text-xs text-[#123F3A] flex items-start gap-2">
        <Sparkles className="w-4 h-4 text-[#16856B] shrink-0 mt-0.5" />
        <span className="leading-relaxed">
          <strong>Executive Assessment:</strong> {scoreData.summary}
        </span>
      </div>

      {/* 4 Component Scoring Bars */}
      <div className="p-5 grid grid-cols-1 md:grid-cols-2 gap-3.5">
        {scoreData.components.map((comp) => {
          const compColor = comp.score >= 80 ? 'bg-[#16856B]' : comp.score >= 50 ? 'bg-[#C39B4A]' : 'bg-[#D87568]';

          return (
            <div key={comp.name} className="p-3.5 rounded-lg border border-[#E1E7E4] bg-[#FAFAF7]">
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-xs font-bold text-[#202B2A]">{comp.name}</span>
                <span className="text-xs font-semibold text-[#202B2A] tabular-nums">
                  {comp.score}/100 <span className="text-[10px] text-[#687573] font-normal">({comp.weight}% wt)</span>
                </span>
              </div>

              {/* Progress bar */}
              <div className="w-full h-1.5 bg-[#E1E7E4] rounded-full overflow-hidden mb-1.5">
                <div
                  className={`h-full rounded-full transition-all duration-300 ${compColor}`}
                  style={{ width: `${Math.max(comp.score, 6)}%` }}
                />
              </div>

              <div className="flex items-center justify-between text-[11px] text-[#687573]">
                <span className="truncate max-w-[200px]" title={comp.details}>{comp.details}</span>
                <span className="font-semibold text-[#123F3A] shrink-0 ml-2">{comp.impact}</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
