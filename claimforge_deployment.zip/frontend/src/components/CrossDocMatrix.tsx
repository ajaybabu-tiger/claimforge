'use client';

import React from 'react';
import { Document } from '@/lib/types';
import { FileText, Layers, CheckCircle2, AlertTriangle } from 'lucide-react';

interface CrossDocMatrixProps {
  documents: Document[];
}

export default function CrossDocMatrix({ documents }: CrossDocMatrixProps) {
  if (!documents || documents.length === 0) {
    return (
      <div className="bg-white rounded-xl border border-[#E1E7E4] p-8 text-center text-[#687573] shadow-xs">
        <FileText className="w-8 h-8 text-[#C7DFD7] mx-auto mb-2 opacity-60" />
        <p className="text-xs font-semibold text-[#202B2A]">No Documents Available</p>
        <p className="text-[11px] text-[#687573] mt-0.5">Upload at least two clinical files to compute the side-by-side consistency matrix.</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl border border-[#E1E7E4] shadow-xs overflow-hidden">
      <div className="p-4 border-b border-[#E1E7E4] bg-[#FAFAF7] flex items-center justify-between">
        <div>
          <h4 className="text-xs font-bold uppercase tracking-wider text-[#202B2A] flex items-center gap-2">
            <Layers className="w-4 h-4 text-[#16856B]" />
            <span>Cross-Document Entity Comparison Matrix</span>
            <span className="text-[10px] font-normal text-[#687573] bg-white border border-[#E1E7E4] px-1.5 py-0.2 rounded font-mono">
              {documents.length} File{documents.length > 1 ? 's' : ''} Analyzed
            </span>
          </h4>
          <p className="text-[11px] text-[#687573] mt-0.5">
            Side-by-side alignment of dates of service, billed charges, diagnostic codes (ICD-10), and procedural codes (CPT).
          </p>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs min-w-[850px]">
          <thead className="bg-[#FAFAF7] text-[#687573] font-semibold border-b border-[#E1E7E4]">
            <tr>
              <th className="py-2.5 px-3.5 w-44 whitespace-nowrap">Document File</th>
              <th className="py-2.5 px-3.5 w-28 whitespace-nowrap">Type</th>
              <th className="py-2.5 px-3.5 whitespace-nowrap">Dates Extracted</th>
              <th className="py-2.5 px-3.5 whitespace-nowrap">Amounts</th>
              <th className="py-2.5 px-3.5 whitespace-nowrap">Diagnoses (ICD-10)</th>
              <th className="py-2.5 px-3.5 whitespace-nowrap">Procedures (CPT)</th>
              <th className="py-2.5 px-3.5 whitespace-nowrap">Provider / Facility</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#E1E7E4]">
            {documents.map((doc) => {
              const meta = doc.extracted_metadata || {};
              const dates = meta.dates || [];
              const amounts = meta.amounts || [];
              const icds = meta.diagnosis_codes || [];
              const cpts = meta.procedure_codes || [];
              const providers = meta.provider_names || [];

              return (
                <tr key={doc.id} className="hover:bg-[#FAFAF7]/60 transition-colors">
                  <td className="py-2.5 px-3.5 font-semibold text-[#202B2A]">
                    <div className="flex items-center gap-1.5">
                      <FileText className="w-3.5 h-3.5 text-[#16856B] shrink-0" />
                      <span className="truncate max-w-[160px]" title={doc.original_filename}>
                        {doc.original_filename}
                      </span>
                    </div>
                  </td>

                  <td className="py-2.5 px-3.5">
                    <span className="bg-[#F1F3F2] text-[#202B2A] border border-[#E1E7E4] px-1.5 py-0.2 rounded text-[10px] font-semibold uppercase tracking-wider">
                      {doc.document_type.replace(/_/g, ' ')}
                    </span>
                  </td>

                  <td className="py-2.5 px-3.5">
                    {dates.length > 0 ? (
                      <div className="flex flex-wrap gap-1">
                        {dates.slice(0, 3).map((d: string, i: number) => (
                          <span key={i} className="bg-[#E6F4EF] text-[#123F3A] border border-[#B0E1D4] px-1.5 py-0.2 rounded font-mono text-[10px] tabular-nums">
                            {d}
                          </span>
                        ))}
                      </div>
                    ) : (
                      <span className="text-[#8E9C99] italic text-[11px]">&mdash;</span>
                    )}
                  </td>

                  <td className="py-2.5 px-3.5 font-bold text-[#123F3A] tabular-nums">
                    {amounts.length > 0 ? (
                      <div className="flex flex-wrap gap-1">
                        {amounts.slice(0, 3).map((a: number, i: number) => (
                          <span key={i} className="bg-[#FAFAF7] border border-[#E1E7E4] text-[#202B2A] px-1.5 py-0.2 rounded font-mono text-[10px]">
                            ${a.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                          </span>
                        ))}
                      </div>
                    ) : (
                      <span className="text-[#8E9C99] italic text-[11px]">&mdash;</span>
                    )}
                  </td>

                  <td className="py-2.5 px-3.5">
                    {icds.length > 0 ? (
                      <div className="flex flex-wrap gap-1">
                        {icds.slice(0, 3).map((icd: string, i: number) => (
                          <span key={i} className="bg-[#F1F3F2] text-[#202B2A] border border-[#E1E7E4] px-1.5 py-0.2 rounded font-mono text-[10px]">
                            {icd}
                          </span>
                        ))}
                      </div>
                    ) : (
                      <span className="text-[#8E9C99] italic text-[11px]">&mdash;</span>
                    )}
                  </td>

                  <td className="py-2.5 px-3.5">
                    {cpts.length > 0 ? (
                      <div className="flex flex-wrap gap-1">
                        {cpts.slice(0, 3).map((cpt: string, i: number) => (
                          <span key={i} className="bg-[#FDF8EC] text-[#8E6B1D] border border-[#ECD8A5] px-1.5 py-0.2 rounded font-mono text-[10px]">
                            {cpt}
                          </span>
                        ))}
                      </div>
                    ) : (
                      <span className="text-[#8E9C99] italic text-[11px]">&mdash;</span>
                    )}
                  </td>

                  <td className="py-2.5 px-3.5 text-[#687573] text-[11px]">
                    {providers.length > 0 ? (
                      providers.slice(0, 2).join(', ')
                    ) : (
                      <span className="text-[#8E9C99] italic">&mdash;</span>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
