'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import {
  LayoutDashboard,
  FileSpreadsheet,
  PlusCircle,
  FileText,
  Sparkles,
  ChevronLeft,
  ChevronRight,
  Menu,
  X,
  ShieldCheck,
  Scale,
  ExternalLink,
  Layers,
  ArrowRight,
  RefreshCw,
  FolderOpen
} from 'lucide-react';
import { api } from '@/lib/api';

import Footer from '@/components/Footer';

interface AppShellProps {
  children: React.ReactNode;
}

export default function AppShell({ children }: AppShellProps) {
  const pathname = usePathname();
  const router = useRouter();
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [backendHealthy, setBackendHealthy] = useState<boolean | null>(null);
  const [latestClaimId, setLatestClaimId] = useState<string | null>(null);

  // Close mobile drawer on route change
  useEffect(() => {
    setMobileOpen(false);
  }, [pathname]);

  // Check backend health and get latest claim for contextual navigation
  useEffect(() => {
    api.getHealth()
      .then(() => setBackendHealthy(true))
      .catch(() => setBackendHealthy(false));

    api.getClaims()
      .then((claims) => {
        if (claims && claims.length > 0) {
          setLatestClaimId(claims[0].id);
        }
      })
      .catch(() => {});
  }, [pathname]);

  // If on the public landing page (/), render the specialized top-nav layout
  const isLandingPage = pathname === '/';

  // Extract claim ID if currently inside /claims/[id]
  const claimIdMatch = pathname.match(/^\/claims\/([^\/]+)/);
  const currentClaimId = claimIdMatch && claimIdMatch[1] !== 'new' ? claimIdMatch[1] : latestClaimId;

  // Compute breadcrumb / page title
  const getPageInfo = () => {
    if (pathname === '/dashboard') return { title: 'Dashboard', subtitle: 'Claims Management & Verification Registry' };
    if (pathname === '/claims/new') return { title: 'New Claim Intake', subtitle: 'Ingest Claim & Extract Medical Evidence' };
    if (pathname === '/demo') return { title: 'Demo Fixtures', subtitle: '4 Synthetic Pre-Verified Scenarios' };
    if (pathname.includes('/appeal')) return { title: 'Appeal Studio', subtitle: 'Evidence-Backed Appeal Draft & PDF Export' };
    if (pathname.startsWith('/claims/')) return { title: 'Document Intelligence', subtitle: 'Cross-Document Extraction & Consistency Matrix' };
    return { title: 'ClaimForge', subtitle: 'Turn Claim Denials into Evidence-Backed Appeals' };
  };

  const pageInfo = getPageInfo();

  const navItems = [
    {
      label: 'Dashboard',
      href: '/dashboard',
      icon: LayoutDashboard,
      active: pathname === '/dashboard',
    },
    {
      label: 'New Claim Intake',
      href: '/claims/new',
      icon: PlusCircle,
      active: pathname === '/claims/new',
    },
    {
      label: 'Document Intelligence',
      href: currentClaimId ? `/claims/${currentClaimId}` : '/dashboard',
      icon: FileText,
      active: pathname.startsWith('/claims/') && !pathname.endsWith('/appeal') && pathname !== '/claims/new',
      badge: currentClaimId ? 'Active Case' : undefined,
    },
    {
      label: 'Appeal Workspace',
      href: currentClaimId ? `/claims/${currentClaimId}/appeal` : '/dashboard',
      icon: Scale,
      active: pathname.endsWith('/appeal'),
      badge: currentClaimId ? 'Filing Studio' : undefined,
    },
    {
      label: 'Demo Scenarios',
      href: '/demo',
      icon: Sparkles,
      active: pathname === '/demo',
      badge: '4 Fixtures',
    },
  ];

  if (isLandingPage) {
    return (
      <div className="min-h-screen flex flex-col bg-[#FAFAF7]">
        {/* Landing Top Header */}
        <header className="sticky top-0 z-40 bg-[#FAFAF7]/95 backdrop-blur-md border-b border-[#E1E7E4]">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
            <Link href="/" className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-lg bg-[#123F3A] flex items-center justify-center text-white shadow-xs">
                <ShieldCheck className="w-5 h-5 text-[#16856B]" />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="text-base font-bold tracking-tight text-[#202B2A]">ClaimForge</span>
                  <span className="text-[10px] font-semibold uppercase tracking-wider bg-[#E6F4EF] text-[#123F3A] border border-[#B0E1D4] px-1.5 py-0.2 rounded">
                    SaaS Platform
                  </span>
                </div>
                <p className="text-[10px] text-[#687573] font-medium hidden sm:block">Turn Denials into Evidence-Backed Appeals</p>
              </div>
            </Link>

            <nav className="hidden md:flex items-center gap-1">
              <Link
                href="/dashboard"
                className="px-3 py-1.5 rounded-lg text-xs font-medium text-[#202B2A] hover:bg-[#F1F3F2] transition-colors"
              >
                Dashboard
              </Link>
              <Link
                href="/demo"
                className="px-3 py-1.5 rounded-lg text-xs font-medium text-[#202B2A] hover:bg-[#F1F3F2] transition-colors"
              >
                Demo Scenarios
              </Link>
              <Link
                href="/claims/new"
                className="px-3 py-1.5 rounded-lg text-xs font-medium text-[#202B2A] hover:bg-[#F1F3F2] transition-colors"
              >
                New Intake
              </Link>
            </nav>

            <div className="flex items-center gap-2.5">
              <div className="hidden sm:flex items-center gap-1.5 text-[11px] text-[#687573] bg-[#F1F3F2] border border-[#E1E7E4] px-2.5 py-1 rounded-full">
                <span className={`w-1.5 h-1.5 rounded-full ${backendHealthy ? 'bg-[#16856B]' : 'bg-[#D87568]'}`} />
                <span>{backendHealthy ? 'FastAPI Active' : 'Connecting...'}</span>
              </div>

              <Link
                href="/dashboard"
                className="inline-flex items-center gap-1.5 bg-[#123F3A] hover:bg-[#17524B] text-white px-3.5 py-1.5 rounded-lg text-xs font-semibold shadow-xs transition-colors"
              >
                <span>Launch App</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            </div>
          </div>
        </header>

        <main className="flex-1">{children}</main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex bg-[#FAFAF7] text-[#202B2A]">
      {/* Mobile Drawer Backdrop */}
      {mobileOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/30 backdrop-blur-xs md:hidden"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Sidebar (Desktop & Mobile Drawer) */}
      <aside
        className={`fixed top-0 bottom-0 left-0 z-50 bg-[#FAFAF7] border-r border-[#E1E7E4] flex flex-col justify-between transition-all duration-200 md:static ${
          mobileOpen ? 'translate-x-0 w-64' : '-translate-x-full md:translate-x-0'
        } ${collapsed ? 'md:w-20' : 'md:w-64'}`}
      >
        {/* Top: Logo & Collapse Button */}
        <div>
          <div className="h-16 border-b border-[#E1E7E4] px-4 flex items-center justify-between">
            <Link href="/dashboard" className="flex items-center gap-2.5 overflow-hidden">
              <div className="w-9 h-9 rounded-lg bg-[#123F3A] flex items-center justify-center text-white shrink-0 shadow-xs">
                <ShieldCheck className="w-5 h-5 text-[#16856B]" />
              </div>
              {!collapsed && (
                <div className="truncate">
                  <span className="text-sm font-bold tracking-tight text-[#202B2A] block leading-tight">
                    ClaimForge
                  </span>
                  <span className="text-[10px] text-[#687573] font-medium tracking-wide">
                    Evidence Decision Engine
                  </span>
                </div>
              )}
            </Link>

            {/* Mobile close */}
            <button
              onClick={() => setMobileOpen(false)}
              className="md:hidden p-1.5 rounded-md text-[#687573] hover:text-[#202B2A] hover:bg-[#F1F3F2]"
              aria-label="Close navigation drawer"
            >
              <X className="w-4 h-4" />
            </button>

            {/* Desktop collapse toggle */}
            <button
              onClick={() => setCollapsed(!collapsed)}
              className="hidden md:flex p-1.5 rounded-md text-[#687573] hover:text-[#202B2A] hover:bg-[#F1F3F2]"
              title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
              aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
            >
              {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
            </button>
          </div>

          {/* Quick Case Jump Card (when collapsed is false) */}
          {!collapsed && currentClaimId && (
            <div className="p-3 border-b border-[#E1E7E4] bg-[#F1F3F2]/60">
              <span className="text-[10px] font-semibold uppercase tracking-wider text-[#687573] block mb-1">
                Active Case File
              </span>
              <Link
                href={`/claims/${currentClaimId}`}
                className="flex items-center justify-between gap-2 p-2 rounded-lg bg-white border border-[#E1E7E4] hover:border-[#B0E1D4] text-xs font-semibold text-[#123F3A] transition-colors"
              >
                <div className="flex items-center gap-1.5 truncate">
                  <FolderOpen className="w-3.5 h-3.5 text-[#16856B] shrink-0" />
                  <span className="truncate font-mono">Case File</span>
                </div>
                <span className="text-[10px] bg-[#E6F4EF] text-[#123F3A] px-1.5 py-0.2 rounded font-mono shrink-0">
                  Open
                </span>
              </Link>
            </div>
          )}

          {/* Navigation Links */}
          <nav className="p-3 space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <Link
                  key={item.label}
                  href={item.href}
                  className={`flex items-center gap-3 px-3 py-2 rounded-lg text-xs font-semibold transition-colors ${
                    item.active
                      ? 'bg-[#E6F4EF] text-[#123F3A] border border-[#B0E1D4] shadow-xs'
                      : 'text-[#687573] hover:text-[#202B2A] hover:bg-[#F1F3F2]'
                  } ${collapsed ? 'justify-center px-2' : ''}`}
                  title={collapsed ? item.label : undefined}
                >
                  <Icon
                    className={`w-4 h-4 shrink-0 ${item.active ? 'text-[#16856B]' : 'text-[#687573]'}`}
                  />
                  {!collapsed && (
                    <div className="flex-1 flex items-center justify-between truncate">
                      <span className="truncate">{item.label}</span>
                      {item.badge && (
                        <span
                          className={`text-[10px] font-medium px-1.5 py-0.2 rounded border ${
                            item.active
                              ? 'bg-white text-[#123F3A] border-[#B0E1D4]'
                              : 'bg-[#F1F3F2] text-[#687573] border-[#E1E7E4]'
                          }`}
                        >
                          {item.badge}
                        </span>
                      )}
                    </div>
                  )}
                </Link>
              );
            })}
          </nav>
        </div>

        {/* Bottom: Connection status & disclaimer */}
        <div className="p-3 border-t border-[#E1E7E4] bg-[#FAFAF7] space-y-2">
          {!collapsed ? (
            <>
              <div className="flex items-center justify-between text-[11px] text-[#687573] bg-[#F1F3F2] border border-[#E1E7E4] px-2.5 py-1.5 rounded-lg">
                <span className="flex items-center gap-1.5">
                  <span className={`w-2 h-2 rounded-full ${backendHealthy ? 'bg-[#16856B]' : 'bg-[#D87568]'}`} />
                  <span className="font-medium text-[#202B2A]">
                    {backendHealthy ? 'Backend Active' : 'Connecting API'}
                  </span>
                </span>
                <span className="text-[10px] text-[#687573] font-mono">FastAPI</span>
              </div>

              <div className="text-[10px] text-[#687573] leading-tight px-1 flex items-start gap-1.5">
                <Scale className="w-3.5 h-3.5 text-[#16856B] shrink-0 mt-0.5" />
                <span>Human decision-support tool. Never fabricates evidence.</span>
              </div>
            </>
          ) : (
            <div className="flex justify-center" title="Backend Status">
              <span className={`w-2.5 h-2.5 rounded-full ${backendHealthy ? 'bg-[#16856B]' : 'bg-[#D87568]'}`} />
            </div>
          )}
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Main Header */}
        <header className="sticky top-0 z-30 bg-[#FAFAF7]/95 backdrop-blur-md border-b border-[#E1E7E4] h-16 px-4 sm:px-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setMobileOpen(true)}
              className="md:hidden p-2 rounded-lg text-[#687573] hover:text-[#202B2A] hover:bg-[#F1F3F2]"
              aria-label="Open navigation menu"
            >
              <Menu className="w-5 h-5" />
            </button>

            <div>
              <h1 className="text-sm sm:text-base font-bold text-[#202B2A] tracking-tight">
                {pageInfo.title}
              </h1>
              <p className="text-[11px] text-[#687573] hidden sm:block">
                {pageInfo.subtitle}
              </p>
            </div>
          </div>

          {/* Header Actions */}
          <div className="flex items-center gap-2.5">
            <Link
              href="/demo"
              className="hidden sm:inline-flex items-center gap-1.5 text-xs font-semibold text-[#123F3A] bg-[#E6F4EF] hover:bg-[#D7F0E9] border border-[#B0E1D4] px-3 py-1.5 rounded-lg transition-colors shadow-2xs"
            >
              <Sparkles className="w-3.5 h-3.5 text-[#16856B]" />
              <span>Demo Fixtures</span>
            </Link>

            <Link
              href="/claims/new"
              className="inline-flex items-center gap-1.5 bg-[#123F3A] hover:bg-[#17524B] text-white px-3.5 py-1.5 rounded-lg text-xs font-semibold shadow-xs transition-colors"
            >
              <PlusCircle className="w-3.5 h-3.5" />
              <span>New Claim</span>
            </Link>
          </div>
        </header>

        {/* Content Body */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
          {children}
        </main>
        <Footer />
      </div>
    </div>
  );
}
