import React from 'react';
import { getStatusBadge, getPriorityBadge, getSeverityBadge } from '@/lib/utils';
import { CheckCircle2, AlertTriangle, AlertCircle, Info, ShieldCheck, Clock } from 'lucide-react';

export function ClaimStatusBadge({ status }: { status: string }) {
  const { label, bg, dot } = getStatusBadge(status);
  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-md text-xs font-semibold border ${bg}`}>
      <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${dot}`} />
      <span>{label}</span>
    </span>
  );
}

export function PriorityBadge({ priority }: { priority: string }) {
  const { label, bg, dot } = getPriorityBadge(priority);
  return (
    <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md text-[11px] font-semibold border ${bg}`}>
      <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${dot}`} />
      <span>{label}</span>
    </span>
  );
}

export function SeverityBadge({ severity }: { severity: string }) {
  const { label, bg, dot } = getSeverityBadge(severity);
  return (
    <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md text-[11px] font-medium border ${bg}`}>
      <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${dot}`} />
      <span>{label}</span>
    </span>
  );
}
