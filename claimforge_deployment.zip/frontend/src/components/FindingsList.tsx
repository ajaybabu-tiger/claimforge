'use client';

import React, { useState } from 'react';
import { Finding, FindingsGrouped } from '@/lib/types';
import { SeverityBadge } from './StatusBadge';
import {
  Check,
  X,
  MessageSquare,
  AlertCircle,
  FileSearch,
  ShieldAlert,
  CheckCircle,
  ArrowRight,
  Eye,
  Scale,
  Sparkles,
  Layers,
  FileText
} from 'lucide-react';
import { api } from '@/lib/api';

interface FindingsListProps {
  findingsGrouped: FindingsGrouped;
  onFindingUpdated?: () => void;
  onInspectDocument?: (docId: string) => void;
}

export default function FindingsList({
  findingsGrouped,
  onFindingUpdated,
  onInspectDocument,
}: FindingsListProps) {
  const [activeTab, setActiveTab] = useState<string>('all');
  const [updatingId, setUpdatingId] = useState<string | null>(null);
  const [commentInput, setCommentInput] = useState<{ [id: string]: string }>({});
  const [showCommentBox, setShowCommentBox] = useState<{ [id: string]: boolean }>({});
  const [selectedFindingForDrawer, setSelectedFindingForDrawer] = useState<Finding | null>(null);

  const allFindings = [
    ...(findingsGrouped.rejection_analysis || []),
    ...(findingsGrouped.cross_document_inconsistencies || []),
    ...(findingsGrouped.missing_evidence || []),
    ...(findingsGrouped.document_integrity_indicators || []),
    ...(findingsGrouped.extracted_facts || []),
    ...(findingsGrouped.recommended_actions || []),
  ];

  const handleStatusChange = async (
    findingId: string,
    status: 'unreviewed' | 'confirmed' | 'dismissed',
    comment?: string
  ) => {
    setUpdatingId(findingId);
    try {
      await api.updateFinding(findingId, status, comment);
      if (onFindingUpdated) onFindingUpdated();
    } catch (err) {
      alert(`Failed to update finding status: ${err}`);
    } finally {
      setUpdatingId(null);
    }
  };

  const getFilteredFindings = (): Finding[] => {
    switch (activeTab) {
      case 'rejection':
        return findingsGrouped.rejection_analysis || [];
      case 'inconsistencies':
        return findingsGrouped.cross_document_inconsistencies || [];
      case 'missing':
        return findingsGrouped.missing_evidence || [];
      case 'integrity':
        return findingsGrouped.document_integrity_indicators || [];
      case 'facts':
        return findingsGrouped.extracted_facts || [];
      case 'actions':
        return findingsGrouped.recommended_actions || [];
      case 'all':
      default:
        return allFindings;
    }
  };

  const filtered = getFilteredFindings();

  const tabs = [
    { id: 'all', label: 'All Findings', count: allFindings.length },
    { id: 'rejection', label: 'Rejection Rebuttals', count: findingsGrouped.rejection_analysis?.length || 0 },
    { id: 'inconsistencies', label: 'Cross-Doc Inconsistencies', count: findingsGrouped.cross_document_inconsistencies?.length || 0 },
    { id: 'missing', label: 'Evidence Gaps', count: findingsGrouped.missing_evidence?.length || 0 },
    { id: 'integrity', label: 'Document Integrity', count: findingsGrouped.document_integrity_indicators?.length || 0 },
    { id: 'facts', label: 'Extracted Facts', count: findingsGrouped.extracted_facts?.length || 0 },
    { id: 'actions', label: 'Action Items', count: findingsGrouped.recommended_actions?.length || 0 },
  ];

  return (
    <div className="bg-white rounded-xl border border-[#E1E7E4] shadow-xs overflow-hidden">
      {/* Category Tabs */}
      <div className="border-b border-[#E1E7E4] bg-[#FAFAF7] p-2 overflow-x-auto flex gap-1">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
              activeTab === tab.id
                ? 'bg-white text-[#123F3A] border border-[#E1E7E4] shadow-2xs'
                : 'text-[#687573] hover:text-[#202B2A] hover:bg-[#F1F3F2]'
            }`}
          >
            <span>{tab.label}</span>
            <span
              className={`px-1.5 py-0.2 rounded-full text-[10px] ${
                activeTab === tab.id
                  ? 'bg-[#E6F4EF] text-[#123F3A] border border-[#B0E1D4]'
                  : 'bg-[#F1F3F2] text-[#687573]'
              }`}
            >
              {tab.count}
            </span>
          </button>
        ))}
      </div>

      {/* Findings List */}
      <div className="divide-y divide-[#E1E7E4]">
        {filtered.length === 0 ? (
          <div className="p-8 text-center text-[#687573] space-y-1">
            <CheckCircle className="w-6 h-6 text-[#16856B] mx-auto mb-1 opacity-70" />
            <p className="text-xs font-semibold text-[#202B2A]">No findings in this category</p>
            <p className="text-[11px] text-[#687573]">All checks for this category passed without anomalies.</p>
          </div>
        ) : (
          filtered.map((f) => {
            const isConfirmed = f.reviewer_status === 'confirmed';
            const isDismissed = f.reviewer_status === 'dismissed';

            return (
              <div
                key={f.id}
                className={`p-4 transition-colors hover:bg-[#FAFAF7]/60 ${
                  isDismissed ? 'opacity-60 bg-[#F1F3F2]/40' : ''
                }`}
              >
                <div className="flex flex-col md:flex-row md:items-start justify-between gap-3">
                  <div className="space-y-1.5 flex-1">
                    {/* Badge Row */}
                    <div className="flex flex-wrap items-center gap-2">
                      <SeverityBadge severity={f.severity} />

                      <span className="text-[10px] font-semibold uppercase tracking-wider text-[#687573] bg-[#F1F3F2] px-2 py-0.5 rounded border border-[#E1E7E4]">
                        {f.category.replace(/_/g, ' ')}
                      </span>

                      {f.confidence !== undefined && f.confidence > 0 && (
                        <span className="text-[10px] text-[#123F3A] bg-[#E6F4EF] border border-[#B0E1D4] px-1.5 py-0.2 rounded font-mono">
                          {Math.round(f.confidence * 100)}% confidence
                        </span>
                      )}

                      {f.reviewer_status !== 'unreviewed' && (
                        <span
                          className={`text-[10px] font-bold px-2 py-0.2 rounded-full border ${
                            isConfirmed
                              ? 'bg-[#E6F4EF] text-[#123F3A] border-[#B0E1D4]'
                              : 'bg-[#F1F3F2] text-[#687573] border-[#E1E7E4]'
                          }`}
                        >
                          Reviewer: {f.reviewer_status.toUpperCase()}
                        </span>
                      )}
                    </div>

                    {/* Title & Explanation */}
                    <h4 className="text-xs sm:text-sm font-bold text-[#202B2A] leading-snug">
                      {f.title}
                    </h4>
                    <p className="text-xs text-[#687573] leading-relaxed">
                      {f.explanation}
                    </p>

                    {/* Evidence Citation */}
                    {f.evidence_reference && (
                      <div className="text-[11px] text-[#123F3A] bg-[#FAFAF7] border border-[#E1E7E4] px-2.5 py-1 rounded inline-flex items-center gap-1.5 font-mono">
                        <FileSearch className="w-3.5 h-3.5 text-[#16856B]" />
                        <span>Evidence Citation: {f.evidence_reference}</span>
                      </div>
                    )}

                    {/* Reviewer Note Display */}
                    {f.reviewer_comment && (
                      <div className="text-xs text-[#123F3A] bg-[#E6F4EF] border border-[#B0E1D4] p-2.5 rounded-lg mt-2 flex items-start gap-2">
                        <MessageSquare className="w-3.5 h-3.5 text-[#16856B] shrink-0 mt-0.5" />
                        <div>
                          <strong>Reviewer Note:</strong> {f.reviewer_comment}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Reviewer Action Controls */}
                  <div className="flex items-center gap-1.5 shrink-0 pt-0.5">
                    <button
                      onClick={() => handleStatusChange(f.id, isConfirmed ? 'unreviewed' : 'confirmed')}
                      disabled={updatingId === f.id}
                      className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold border transition-colors ${
                        isConfirmed
                          ? 'bg-[#16856B] text-white border-[#16856B]'
                          : 'bg-white text-[#16856B] border-[#B0E1D4] hover:bg-[#E6F4EF]'
                      }`}
                      title={isConfirmed ? 'Click to unconfirm' : 'Confirm this finding'}
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>{isConfirmed ? 'Confirmed' : 'Confirm'}</span>
                    </button>

                    <button
                      onClick={() => handleStatusChange(f.id, isDismissed ? 'unreviewed' : 'dismissed')}
                      disabled={updatingId === f.id}
                      className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold border transition-colors ${
                        isDismissed
                          ? 'bg-[#687573] text-white border-[#687573]'
                          : 'bg-white text-[#687573] border-[#E1E7E4] hover:bg-[#F1F3F2]'
                      }`}
                      title={isDismissed ? 'Click to restore' : 'Dismiss this finding'}
                    >
                      <X className="w-3.5 h-3.5" />
                      <span>{isDismissed ? 'Dismissed' : 'Dismiss'}</span>
                    </button>

                    <button
                      onClick={() =>
                        setShowCommentBox((prev) => ({ ...prev, [f.id]: !prev[f.id] }))
                      }
                      className="p-1.5 rounded-lg text-[#687573] hover:text-[#202B2A] hover:bg-[#F1F3F2] border border-[#E1E7E4]"
                      title="Add Reviewer Note"
                    >
                      <MessageSquare className="w-3.5 h-3.5" />
                    </button>

                    <button
                      onClick={() => setSelectedFindingForDrawer(f)}
                      className="p-1.5 rounded-lg text-[#687573] hover:text-[#202B2A] hover:bg-[#F1F3F2] border border-[#E1E7E4]"
                      title="Inspect Details"
                    >
                      <Eye className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Inline Comment Box */}
                {showCommentBox[f.id] && (
                  <div className="mt-3 pt-3 border-t border-[#E1E7E4] flex gap-2">
                    <input
                      type="text"
                      placeholder="Add clinical observation or legal rationale..."
                      value={commentInput[f.id] || ''}
                      onChange={(e) => setCommentInput({ ...commentInput, [f.id]: e.target.value })}
                      className="flex-1 text-xs border border-[#E1E7E4] rounded-lg px-3 py-1.5 focus:outline-none focus:border-[#16856B] bg-[#FAFAF7] text-[#202B2A]"
                    />
                    <button
                      onClick={() => {
                        handleStatusChange(f.id, isConfirmed ? 'confirmed' : 'unreviewed', commentInput[f.id]);
                        setShowCommentBox({ ...showCommentBox, [f.id]: false });
                      }}
                      className="bg-[#123F3A] hover:bg-[#17524B] text-white text-xs font-semibold px-3 py-1.5 rounded-lg"
                    >
                      Save Note
                    </button>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Finding Inspection Modal / Drawer */}
      {selectedFindingForDrawer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-xl max-w-lg w-full border border-[#E1E7E4] shadow-xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="p-4 border-b border-[#E1E7E4] bg-[#FAFAF7] flex items-center justify-between">
              <div className="flex items-center gap-2">
                <SeverityBadge severity={selectedFindingForDrawer.severity} />
                <span className="text-xs font-bold text-[#202B2A]">Finding Inspection</span>
              </div>
              <button
                onClick={() => setSelectedFindingForDrawer(null)}
                className="p-1 rounded text-[#8E9C99] hover:text-[#202B2A]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 space-y-4 text-xs">
              <div>
                <span className="text-[10px] uppercase font-bold text-[#687573] block">Title</span>
                <h4 className="text-sm font-bold text-[#202B2A] mt-0.5">{selectedFindingForDrawer.title}</h4>
              </div>

              <div>
                <span className="text-[10px] uppercase font-bold text-[#687573] block">Category & Confidence</span>
                <p className="text-[#202B2A] mt-0.5">
                  Category: <strong className="capitalize">{selectedFindingForDrawer.category.replace(/_/g, ' ')}</strong> &bull; Confidence:{' '}
                  <strong>{Math.round(selectedFindingForDrawer.confidence * 100)}%</strong>
                </p>
              </div>

              <div>
                <span className="text-[10px] uppercase font-bold text-[#687573] block">Detailed Explanation</span>
                <p className="text-[#687573] leading-relaxed mt-0.5 bg-[#FAFAF7] p-3 rounded-lg border border-[#E1E7E4]">
                  {selectedFindingForDrawer.explanation}
                </p>
              </div>

              {selectedFindingForDrawer.evidence_reference && (
                <div>
                  <span className="text-[10px] uppercase font-bold text-[#687573] block">Evidence Citation Passage</span>
                  <pre className="text-[11px] font-mono bg-[#FAFAF7] p-2.5 rounded border border-[#E1E7E4] text-[#123F3A] mt-0.5 whitespace-pre-wrap">
                    {selectedFindingForDrawer.evidence_reference}
                  </pre>
                </div>
              )}

              {selectedFindingForDrawer.reviewer_comment && (
                <div>
                  <span className="text-[10px] uppercase font-bold text-[#687573] block">Reviewer Notes</span>
                  <p className="text-[#123F3A] bg-[#E6F4EF] border border-[#B0E1D4] p-2.5 rounded-lg mt-0.5 font-medium">
                    {selectedFindingForDrawer.reviewer_comment}
                  </p>
                </div>
              )}
            </div>

            <div className="p-3 border-t border-[#E1E7E4] bg-[#FAFAF7] flex justify-end">
              <button
                onClick={() => setSelectedFindingForDrawer(null)}
                className="bg-[#123F3A] text-white text-xs font-semibold px-4 py-1.5 rounded-lg hover:bg-[#17524B]"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
