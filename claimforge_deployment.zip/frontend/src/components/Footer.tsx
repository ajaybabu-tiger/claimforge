import React from 'react';
import { ShieldCheck, Info } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="mt-auto border-t border-[#E1E7E4] bg-white py-6 text-[#687573] text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-[#16856B]" />
            <span className="font-semibold text-[#202B2A]">ClaimForge</span>
            <span className="text-[#8E9C99]">&bull;</span>
            <span className="text-[11px]">VISTERA 2026 National Hackathon Project</span>
          </div>

          <div className="flex items-center gap-2 text-[#687573] bg-[#FAFAF7] border border-[#E1E7E4] px-3 py-1.5 rounded-lg text-[11px] max-w-xl text-center md:text-left">
            <Info className="w-3.5 h-3.5 text-[#16856B] shrink-0" />
            <span>
              <strong>Decision-Support Notice:</strong> Assists human clinical and billing reviewers in identifying evidence gaps and assembling statutory appeals.
            </span>
          </div>

          <div className="text-[#687573] text-[11px]">
            <span>FastAPI &bull; SQLite &bull; Next.js 14</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
