'use client';

import React, { useState } from 'react';
import { Document } from '@/lib/types';
import { X, Copy, Check, FileText, Code2, AlignLeft } from 'lucide-react';

interface DocumentViewerModalProps {
  document: Document | null;
  onClose: () => void;
}

export default function DocumentViewerModal({ document, onClose }: DocumentViewerModalProps) {
  const [activeView, setActiveView] = useState<'text' | 'metadata'>('text');
  const [copied, setCopied] = useState(false);

  if (!document) return null;

  const handleCopy = () => {
    if (document.extracted_text) {
      navigator.clipboard.writeText(document.extracted_text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-xs p-4">
      <div className="bg-white rounded-xl max-w-3xl w-full max-h-[85vh] flex flex-col shadow-2xl border border-[#E1E7E4] overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="p-4 border-b border-[#E1E7E4] flex items-center justify-between bg-[#FAFAF7]">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 rounded-lg bg-[#E6F4EF] text-[#123F3A]">
              <FileText className="w-4 h-4 text-[#16856B]" />
            </div>
            <div>
              <h3 className="text-xs sm:text-sm font-bold text-[#202B2A] truncate max-w-md">
                {document.original_filename}
              </h3>
              <p className="text-[10px] text-[#687573]">
                Type: <strong>{document.document_type.replace(/_/g, ' ')}</strong> &bull; {document.page_count} page(s) &bull; {(document.file_size / 1024).toFixed(1)} KB
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className="inline-flex items-center gap-1 text-[11px] font-semibold text-[#202B2A] bg-white border border-[#E1E7E4] hover:bg-[#F1F3F2] px-2.5 py-1.5 rounded-lg shadow-2xs transition-colors"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-[#16856B]" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Copy Text'}</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-[#687573] hover:text-[#202B2A] rounded-lg hover:bg-[#F1F3F2]"
              aria-label="Close document viewer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* View Toggle */}
        <div className="px-4 py-2 border-b border-[#E1E7E4] bg-[#FAFAF7] flex gap-2">
          <button
            onClick={() => setActiveView('text')}
            className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-md text-xs font-semibold transition-colors ${
              activeView === 'text'
                ? 'bg-[#123F3A] text-white shadow-2xs'
                : 'text-[#687573] hover:bg-[#F1F3F2] hover:text-[#202B2A]'
            }`}
          >
            <AlignLeft className="w-3.5 h-3.5" />
            <span>Extracted Text (PyMuPDF)</span>
          </button>

          <button
            onClick={() => setActiveView('metadata')}
            className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-md text-xs font-semibold transition-colors ${
              activeView === 'metadata'
                ? 'bg-[#123F3A] text-white shadow-2xs'
                : 'text-[#687573] hover:bg-[#F1F3F2] hover:text-[#202B2A]'
            }`}
          >
            <Code2 className="w-3.5 h-3.5" />
            <span>Structured Entities (JSON)</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="p-4 overflow-y-auto flex-1 bg-[#FAFAF7]/40">
          {activeView === 'text' ? (
            document.extracted_text ? (
              <pre className="text-xs text-[#202B2A] whitespace-pre-wrap font-mono leading-relaxed bg-white border border-[#E1E7E4] rounded-lg p-4 shadow-2xs">
                {document.extracted_text}
              </pre>
            ) : (
              <div className="text-center py-12 text-[#8E9C99] text-xs italic">
                No text extracted or OCR pending.
              </div>
            )
          ) : (
            <pre className="text-xs bg-[#123F3A] text-[#FAFAF7] p-4 rounded-lg font-mono overflow-x-auto">
              {JSON.stringify(document.extracted_metadata || {}, null, 2)}
            </pre>
          )}
        </div>
      </div>
    </div>
  );
}
