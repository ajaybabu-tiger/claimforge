export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2,
  }).format(amount);
}

export function formatDate(dateStr?: string | null): string {
  if (!dateStr) return 'N/A';
  try {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return dateStr;
    return d.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  } catch {
    return dateStr;
  }
}

export function formatDateTime(dateStr?: string | null): string {
  if (!dateStr) return 'N/A';
  try {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return dateStr;
    return d.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return dateStr;
  }
}

export function getStatusBadge(status: string) {
  switch (status) {
    case 'draft':
      return { label: 'Draft Intake', bg: 'bg-surface-muted text-ink-secondary border-surface-border', dot: 'bg-ink-muted' };
    case 'documents_uploaded':
      return { label: 'Docs Uploaded', bg: 'bg-mint-light text-primary-800 border-primary-200', dot: 'bg-primary-600' };
    case 'processing':
      return { label: 'Processing', bg: 'bg-gold-subtle text-gold-text border-gold-border animate-pulse', dot: 'bg-gold' };
    case 'analyzed':
      return { label: 'Analysis Ready', bg: 'bg-mint text-forest-900 border-primary-200', dot: 'bg-primary-600' };
    case 'in_review':
      return { label: 'In Review', bg: 'bg-forest-50 text-forest-900 border-forest-200', dot: 'bg-forest-800' };
    case 'appeal_generated':
      return { label: 'Appeal Ready', bg: 'bg-primary-50 text-primary-800 border-primary-200', dot: 'bg-primary-600' };
    case 'completed':
      return { label: 'Approved & Completed', bg: 'bg-mint text-primary-900 border-primary-300', dot: 'bg-primary-700' };
    default:
      return { label: status, bg: 'bg-surface-muted text-ink-secondary border-surface-border', dot: 'bg-ink-muted' };
  }
}

export function getPriorityBadge(priority: string) {
  switch (priority) {
    case 'urgent':
      return { label: 'Urgent', bg: 'bg-coral-subtle text-coral-text border-coral-border', dot: 'bg-coral' };
    case 'high':
      return { label: 'High Priority', bg: 'bg-gold-subtle text-gold-text border-gold-border', dot: 'bg-gold' };
    case 'medium':
      return { label: 'Medium', bg: 'bg-mint-light text-primary-800 border-primary-200', dot: 'bg-primary-600' };
    case 'low':
      return { label: 'Standard', bg: 'bg-surface-muted text-ink-secondary border-surface-border', dot: 'bg-ink-muted' };
    default:
      return { label: priority, bg: 'bg-surface-muted text-ink-secondary border-surface-border', dot: 'bg-ink-muted' };
  }
}

export function getSeverityBadge(severity: string) {
  switch (severity) {
    case 'critical':
      return { label: 'Critical Gap', bg: 'bg-coral-subtle text-coral-text border-coral-border', dot: 'bg-coral' };
    case 'high':
      return { label: 'High Attention', bg: 'bg-coral-subtle text-coral-text border-coral-border', dot: 'bg-coral' };
    case 'medium':
      return { label: 'Discrepancy', bg: 'bg-gold-subtle text-gold-text border-gold-border', dot: 'bg-gold' };
    case 'low':
      return { label: 'Advisory', bg: 'bg-surface-muted text-ink-secondary border-surface-border', dot: 'bg-ink-muted' };
    case 'info':
    default:
      return { label: 'Verified Evidence', bg: 'bg-mint text-primary-800 border-primary-200', dot: 'bg-primary-600' };
  }
}

export function getReadinessColor(score: number): {
  color: string;
  bg: string;
  badge: string;
  level: string;
} {
  if (score >= 80) {
    return {
      color: 'text-primary-800',
      bg: 'bg-primary-600',
      badge: 'bg-mint text-primary-900 border-primary-200',
      level: 'High Readiness',
    };
  } else if (score >= 60) {
    return {
      color: 'text-forest-800',
      bg: 'bg-forest-800',
      badge: 'bg-forest-50 text-forest-900 border-forest-200',
      level: 'Moderate Readiness',
    };
  } else if (score >= 40) {
    return {
      color: 'text-gold-text',
      bg: 'bg-gold',
      badge: 'bg-gold-subtle text-gold-text border-gold-border',
      level: 'Low Readiness',
    };
  } else {
    return {
      color: 'text-coral-text',
      bg: 'bg-coral',
      badge: 'bg-coral-subtle text-coral-text border-coral-border',
      level: 'Critical Deficiencies',
    };
  }
}
