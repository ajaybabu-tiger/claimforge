export interface Claim {
  id: string;
  claim_reference: string;
  patient_reference: string;
  insurer_name: string;
  claim_amount: number;
  rejection_reason: string;
  rejection_code?: string | null;
  policy_number?: string | null;
  date_of_service?: string | null;
  status: 'draft' | 'documents_uploaded' | 'processing' | 'analyzed' | 'in_review' | 'appeal_generated' | 'completed' | 'archived';
  review_priority: 'low' | 'medium' | 'high' | 'urgent';
  reviewer_notes?: string | null;
  created_at: string;
  updated_at: string;
  documents_count?: number;
  findings_count?: number;
  latest_readiness_score?: number | null;
  latest_appeal_id?: string | null;
}

export interface ClaimCreate {
  claim_reference: string;
  patient_reference: string;
  insurer_name: string;
  claim_amount: number;
  rejection_reason: string;
  rejection_code?: string;
  policy_number?: string;
  date_of_service?: string;
  review_priority?: 'low' | 'medium' | 'high' | 'urgent';
  reviewer_notes?: string;
}

export interface Document {
  id: string;
  claim_id: string;
  original_filename: string;
  document_type: 'medical_bill' | 'diagnostic_report' | 'prescription' | 'discharge_summary' | 'denial_letter' | 'pre_auth' | 'other';
  storage_path: string;
  mime_type: string;
  file_size: number;
  page_count: number;
  processing_status: 'pending' | 'extracting' | 'processed' | 'failed';
  extracted_text?: string | null;
  extracted_metadata?: Record<string, any> | null;
  error_message?: string | null;
  created_at: string;
  updated_at: string;
}

export interface Finding {
  id: string;
  claim_id: string;
  category: 'extracted_fact' | 'missing_evidence' | 'cross_document_inconsistency' | 'document_integrity' | 'rejection_analysis' | 'recommended_action';
  severity: 'info' | 'low' | 'medium' | 'high' | 'critical';
  title: string;
  explanation: string;
  supporting_document_ids?: string[];
  evidence_reference?: string | null;
  confidence: number;
  reviewer_status: 'unreviewed' | 'confirmed' | 'dismissed' | 'edited';
  reviewer_comment?: string | null;
  created_at: string;
  updated_at: string;
}

export interface FindingsGrouped {
  claim_id: string;
  total_findings: number;
  extracted_facts: Finding[];
  missing_evidence: Finding[];
  cross_document_inconsistencies: Finding[];
  document_integrity_indicators: Finding[];
  rejection_analysis: Finding[];
  recommended_actions: Finding[];
}

export interface ScoreComponent {
  name: string;
  weight: number;
  score: number;
  status: 'good' | 'warning' | 'critical';
  details: string;
  impact: string;
}

export interface ReadinessScore {
  claim_id: string;
  readiness_score: number;
  readiness_level: string;
  analysis_mode: string;
  summary: string;
  components: ScoreComponent[];
  positive_factors: string[];
  negative_factors: string[];
  recommended_improvements: string[];
  calculated_at: string;
}

export interface Appeal {
  id: string;
  claim_id: string;
  appeal_title: string;
  draft_content: string;
  structured_sections?: Record<string, any> | null;
  included_finding_ids?: string[] | null;
  approval_status: 'draft' | 'pending_approval' | 'approved' | 'rejected';
  reviewer_notes?: string | null;
  approved_by?: string | null;
  approved_at?: string | null;
  created_at: string;
  updated_at: string;
}

export interface DashboardStats {
  total_claims: number;
  awaiting_review: number;
  missing_evidence: number;
  completed_reviews: number;
  total_disputed_amount: number;
  avg_readiness_score: number;
}
