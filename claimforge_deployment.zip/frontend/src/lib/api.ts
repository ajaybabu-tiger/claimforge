import {
  Claim,
  ClaimCreate,
  Document,
  FindingsGrouped,
  Finding,
  ReadinessScore,
  Appeal,
  DashboardStats
} from './types';

const API_BASE =
  process.env.NEXT_PUBLIC_API_URL ||
  (typeof window !== 'undefined' ? '/api' : 'http://127.0.0.1:8000/api');
const API_ROOT = API_BASE.replace(/\/api\/?$/, '');

async function handleResponse<T>(res: Response): Promise<T> {
  if (!res.ok) {
    let errorDetail = 'API request failed';
    try {
      const err = await res.json();
      errorDetail = err.detail || JSON.stringify(err);
    } catch {
      errorDetail = `HTTP ${res.status}: ${res.statusText}`;
    }
    throw new Error(errorDetail);
  }
  return res.json();
}

export const api = {
  // Health
  getHealth: async () => {
    const res = await fetch(`${API_ROOT}/health`);
    return handleResponse<{ status: string; service: string; ai_active_mode: string }>(res);
  },

  // Dashboard
  getDashboardStats: async (): Promise<DashboardStats> => {
    const res = await fetch(`${API_BASE}/dashboard/stats`, { cache: 'no-store' });
    return handleResponse<DashboardStats>(res);
  },

  // Claims
  getClaims: async (status?: string, search?: string): Promise<Claim[]> => {
    const params = new URLSearchParams();
    if (status && status !== 'all') params.append('status', status);
    if (search) params.append('search', search);
    const url = `${API_BASE}/claims${params.toString() ? `?${params.toString()}` : ''}`;
    const res = await fetch(url, { cache: 'no-store' });
    return handleResponse<Claim[]>(res);
  },

  getClaim: async (id: string): Promise<Claim> => {
    const res = await fetch(`${API_BASE}/claims/${id}`, { cache: 'no-store' });
    return handleResponse<Claim>(res);
  },

  createClaim: async (data: ClaimCreate): Promise<Claim> => {
    const res = await fetch(`${API_BASE}/claims`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    return handleResponse<Claim>(res);
  },

  updateClaim: async (id: string, data: Partial<Claim>): Promise<Claim> => {
    const res = await fetch(`${API_BASE}/claims/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    return handleResponse<Claim>(res);
  },

  deleteClaim: async (id: string): Promise<void> => {
    const res = await fetch(`${API_BASE}/claims/${id}`, { method: 'DELETE' });
    if (!res.ok) throw new Error('Failed to delete claim');
  },

  // Documents
  getClaimDocuments: async (claimId: string): Promise<Document[]> => {
    const res = await fetch(`${API_BASE}/claims/${claimId}/documents`, { cache: 'no-store' });
    return handleResponse<Document[]>(res);
  },

  uploadDocument: async (claimId: string, file: File, documentType: string = 'other'): Promise<Document> => {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('document_type', documentType);
    const res = await fetch(`${API_BASE}/claims/${claimId}/documents`, {
      method: 'POST',
      body: formData,
    });
    return handleResponse<Document>(res);
  },

  getDocumentText: async (docId: string): Promise<{ extracted_text: string; extracted_metadata: any }> => {
    const res = await fetch(`${API_BASE}/documents/${docId}/text`, { cache: 'no-store' });
    return handleResponse<any>(res);
  },

  deleteDocument: async (docId: string): Promise<void> => {
    const res = await fetch(`${API_BASE}/documents/${docId}`, { method: 'DELETE' });
    if (!res.ok) throw new Error('Failed to delete document');
  },

  // Analysis & Findings
  triggerAnalysis: async (claimId: string): Promise<any> => {
    const res = await fetch(`${API_BASE}/claims/${claimId}/analyze`, { method: 'POST' });
    return handleResponse<any>(res);
  },

  getClaimFindings: async (claimId: string): Promise<FindingsGrouped> => {
    const res = await fetch(`${API_BASE}/claims/${claimId}/findings`, { cache: 'no-store' });
    return handleResponse<FindingsGrouped>(res);
  },

  updateFinding: async (
    findingId: string,
    reviewerStatus: 'unreviewed' | 'confirmed' | 'dismissed' | 'edited',
    comment?: string
  ): Promise<Finding> => {
    const res = await fetch(`${API_BASE}/findings/${findingId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ reviewer_status: reviewerStatus, reviewer_comment: comment }),
    });
    return handleResponse<Finding>(res);
  },

  // Readiness Score
  getClaimReadiness: async (claimId: string): Promise<ReadinessScore> => {
    const res = await fetch(`${API_BASE}/claims/${claimId}/readiness`, { cache: 'no-store' });
    return handleResponse<ReadinessScore>(res);
  },

  // Appeals
  generateAppeal: async (
    claimId: string,
    tone: string = 'formal_professional',
    customInstructions?: string,
    selectedFindingIds?: string[]
  ): Promise<Appeal> => {
    const res = await fetch(`${API_BASE}/claims/${claimId}/appeals`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        tone,
        custom_instructions: customInstructions,
        selected_finding_ids: selectedFindingIds,
      }),
    });
    return handleResponse<Appeal>(res);
  },

  getClaimAppeals: async (claimId: string): Promise<Appeal[]> => {
    const res = await fetch(`${API_BASE}/claims/${claimId}/appeals`, { cache: 'no-store' });
    return handleResponse<Appeal[]>(res);
  },

  getAppeal: async (appealId: string): Promise<Appeal> => {
    const res = await fetch(`${API_BASE}/appeals/${appealId}`, { cache: 'no-store' });
    return handleResponse<Appeal>(res);
  },

  updateAppeal: async (appealId: string, data: Partial<Appeal>): Promise<Appeal> => {
    const res = await fetch(`${API_BASE}/appeals/${appealId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    return handleResponse<Appeal>(res);
  },

  getAppealExportUrl: (appealId: string, format: 'pdf' | 'txt' = 'pdf'): string => {
    return `${API_BASE}/appeals/${appealId}/export?format=${format}`;
  },

  // Demo
  getDemoScenarios: async (): Promise<{ scenarios: any[] }> => {
    const res = await fetch(`${API_BASE}/demo/cases`, { cache: 'no-store' });
    return handleResponse<{ scenarios: any[] }>(res);
  },

  seedDemoData: async (): Promise<{ status: string; message: string; seeded_claim_ids: string[] }> => {
    const res = await fetch(`${API_BASE}/demo/seed`, { method: 'POST' });
    return handleResponse<{ status: string; message: string; seeded_claim_ids: string[] }>(res);
  },
};
