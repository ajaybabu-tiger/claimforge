import io
import pytest
from app.services.demo_seeder import DemoSeeder

@pytest.mark.asyncio
async def test_health_check(client):
    response = await client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"
    assert data["service"] == "ClaimForge API"

@pytest.mark.asyncio
async def test_claim_lifecycle(client):
    # 1. Create claim
    payload = {
        "claim_reference": "CLM-TEST-1001",
        "patient_reference": "PAT-TEST-01",
        "insurer_name": "Anthem BlueCross",
        "claim_amount": 4500.0,
        "rejection_reason": "Missing prior authorization for surgery.",
        "rejection_code": "CO-197",
        "policy_number": "POL-9921",
        "date_of_service": "2026-01-10",
        "review_priority": "high"
    }
    create_res = await client.post("/api/claims", json=payload)
    assert create_res.status_code == 201
    claim_data = create_res.json()
    claim_id = claim_data["id"]
    assert claim_data["claim_reference"] == "CLM-TEST-1001"
    assert claim_data["status"] == "draft"

    # 2. Get claim
    get_res = await client.get(f"/api/claims/{claim_id}")
    assert get_res.status_code == 200
    assert get_res.json()["claim_amount"] == 4500.0

    # 3. Update claim
    patch_res = await client.patch(f"/api/claims/{claim_id}", json={"reviewer_notes": "Reviewed initial intake"})
    assert patch_res.status_code == 200
    assert patch_res.json()["reviewer_notes"] == "Reviewed initial intake"

    # 4. List claims
    list_res = await client.get("/api/claims")
    assert list_res.status_code == 200
    assert len(list_res.json()) >= 1

@pytest.mark.asyncio
async def test_document_upload_and_extraction(client, tmp_path):
    # Create claim first
    payload = {
        "claim_reference": "CLM-TEST-DOCS",
        "patient_reference": "PAT-DOCS-02",
        "insurer_name": "United Healthcare",
        "claim_amount": 2500.0,
        "rejection_reason": "Not medically necessary.",
        "rejection_code": "CO-50"
    }
    claim_res = await client.post("/api/claims", json=payload)
    claim_id = claim_res.json()["id"]

    # Generate a sample PDF file
    pdf_path = str(tmp_path / "sample_test_bill.pdf")
    DemoSeeder.create_sample_pdf(
        pdf_path,
        "CLINICAL BILLING LEDGER",
        [
            "Patient: Jane Doe | Member ID: UHC-12345",
            "Date of Service: 2026-02-15",
            "Diagnosis: ICD-10 M54.5 (Low back pain)",
            "Procedure: CPT 99214 Level 4 Office Visit",
            "Total Charges: $2,500.00"
        ]
    )

    with open(pdf_path, "rb") as f:
        file_bytes = f.read()

    # Upload document
    upload_res = await client.post(
        f"/api/claims/{claim_id}/documents",
        files={"file": ("sample_test_bill.pdf", file_bytes, "application/pdf")},
        data={"document_type": "medical_bill"}
    )
    assert upload_res.status_code == 201
    doc_data = upload_res.json()
    doc_id = doc_data["id"]
    assert doc_data["processing_status"] == "processed"
    assert "M54.5" in (doc_data["extracted_text"] or "")

    # Retrieve document text
    text_res = await client.get(f"/api/documents/{doc_id}/text")
    assert text_res.status_code == 200
    assert "M54.5" in text_res.json()["extracted_text"]

@pytest.mark.asyncio
async def test_end_to_end_analysis_readiness_and_appeal_export(client, tmp_path):
    # 1. Create claim
    claim_res = await client.post("/api/claims", json={
        "claim_reference": "CLM-E2E-99",
        "patient_reference": "PAT-EMERG-99",
        "insurer_name": "BlueCross Horizon",
        "claim_amount": 8450.0,
        "rejection_reason": "Missing prior authorization for surgery.",
        "rejection_code": "CO-197",
        "date_of_service": "2026-01-14"
    })
    claim_id = claim_res.json()["id"]

    # 2. Upload sample emergency discharge summary
    pdf_path = str(tmp_path / "er_discharge.pdf")
    DemoSeeder.create_sample_pdf(
        pdf_path,
        "EMERGENCY DISCHARGE RECORD",
        [
            "Patient Name: Alexander Wright",
            "Admission Date: 2026-01-14",
            "Emergency Admission under EMTALA. Acute Appendicitis requiring immediate surgery.",
            "Diagnosis: ICD-10 K35.80 (Acute appendicitis). CPT 44970 Laparoscopic Appendectomy.",
            "Total Billed: $8,450.00"
        ]
    )

    with open(pdf_path, "rb") as f:
        file_bytes = f.read()

    await client.post(
        f"/api/claims/{claim_id}/documents",
        files={"file": ("er_discharge.pdf", file_bytes, "application/pdf")},
        data={"document_type": "discharge_summary"}
    )

    # 3. Trigger Analysis
    analyze_res = await client.post(f"/api/claims/{claim_id}/analyze")
    assert analyze_res.status_code == 200
    analysis_data = analyze_res.json()
    assert analysis_data["findings_generated"] > 0
    assert "readiness_score" in analysis_data

    # 4. Fetch Findings
    findings_res = await client.get(f"/api/claims/{claim_id}/findings")
    assert findings_res.status_code == 200
    findings_data = findings_res.json()
    assert len(findings_data["extracted_facts"]) >= 1 or len(findings_data["rejection_analysis"]) >= 1

    # 5. Fetch Readiness breakdown
    readiness_res = await client.get(f"/api/claims/{claim_id}/readiness")
    assert readiness_res.status_code == 200
    readiness_data = readiness_res.json()
    assert len(readiness_data["components"]) == 4
    assert readiness_data["readiness_score"] >= 0.0

    # 6. Generate Appeal Draft
    appeal_res = await client.post(f"/api/claims/{claim_id}/appeals", json={"tone": "formal_professional"})
    assert appeal_res.status_code == 201
    appeal_data = appeal_res.json()
    appeal_id = appeal_data["id"]
    assert "CLM-E2E-99" in appeal_data["draft_content"]
    assert appeal_data["approval_status"] == "draft"

    # 7. Edit and Approve Appeal Draft
    patch_app_res = await client.patch(f"/api/appeals/{appeal_id}", json={
        "approval_status": "approved",
        "reviewer_notes": "Approved by senior billing reviewer.",
        "approved_by": "Senior Reviewer Sarah Jenkins"
    })
    assert patch_app_res.status_code == 200
    assert patch_app_res.json()["approval_status"] == "approved"

    # 8. Export PDF
    export_pdf_res = await client.get(f"/api/appeals/{appeal_id}/export?format=pdf")
    assert export_pdf_res.status_code == 200
    assert export_pdf_res.headers["content-type"] == "application/pdf"
    assert len(export_pdf_res.content) > 500

    # 9. Export TXT
    export_txt_res = await client.get(f"/api/appeals/{appeal_id}/export?format=txt")
    assert export_txt_res.status_code == 200
    assert "CLM-E2E-99" in export_txt_res.text

@pytest.mark.asyncio
async def test_demo_seeder_endpoint(client):
    seed_res = await client.post("/api/demo/seed")
    assert seed_res.status_code == 201
    assert len(seed_res.json()["seeded_claim_ids"]) == 4

    # Verify dashboard stats
    stats_res = await client.get("/api/dashboard/stats")
    assert stats_res.status_code == 200
    stats = stats_res.json()
    assert stats["total_claims"] >= 4
    assert stats["total_disputed_amount"] > 0
