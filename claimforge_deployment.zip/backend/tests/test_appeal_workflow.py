import pytest
from app.services.demo_seeder import DemoSeeder

@pytest.mark.asyncio
async def test_appeal_generation_with_selected_findings(client, tmp_path):
    # 1. Create claim
    claim_res = await client.post("/api/claims", json={
        "claim_reference": "CLM-APPEAL-WF-001",
        "patient_reference": "PAT-SEL-01",
        "insurer_name": "Aetna Health",
        "claim_amount": 7200.0,
        "rejection_reason": "Missing prior authorization for surgical procedure.",
        "rejection_code": "CO-197",
        "policy_number": "AET-99124",
        "date_of_service": "2026-03-01"
    })
    assert claim_res.status_code == 201
    claim_id = claim_res.json()["id"]

    # 2. Upload clinical discharge summary
    pdf_path = str(tmp_path / "clinical_summary.pdf")
    DemoSeeder.create_sample_pdf(
        pdf_path,
        "SURGICAL OPERATIVE SUMMARY",
        [
            "Patient: Jane Doe | Member ID: AET-99124",
            "Emergency Admission under EMTALA regulations (42 U.S.C. § 1395dd). Acute surgical urgency.",
            "Pre-operative Diagnosis: Acute Appendicitis (ICD-10 K35.80).",
            "Procedure Performed: Laparoscopic Appendectomy (CPT 44970).",
            "Attending Surgeon: Dr. Catherine Hall, MD",
            "Total Charges: $7,200.00"
        ]
    )

    with open(pdf_path, "rb") as f:
        file_bytes = f.read()

    doc_res = await client.post(
        f"/api/claims/{claim_id}/documents",
        files={"file": ("clinical_summary.pdf", file_bytes, "application/pdf")},
        data={"document_type": "discharge_summary"}
    )
    assert doc_res.status_code == 201

    # 3. Analyze claim to generate findings
    analyze_res = await client.post(f"/api/claims/{claim_id}/analyze")
    assert analyze_res.status_code == 200

    # 4. Fetch findings and select specific finding IDs
    findings_res = await client.get(f"/api/claims/{claim_id}/findings")
    assert findings_res.status_code == 200
    all_findings_grouped = findings_res.json()
    
    extracted_facts = all_findings_grouped.get("extracted_facts", [])
    rejection_findings = all_findings_grouped.get("rejection_analysis", [])
    assert len(extracted_facts) > 0
    assert len(rejection_findings) > 0

    selected_fact = extracted_facts[0]
    selected_rejection = rejection_findings[0]
    selected_ids = [selected_fact["id"], selected_rejection["id"]]

    # 5. Generate appeal passing ONLY selected_finding_ids
    appeal_res = await client.post(
        f"/api/claims/{claim_id}/appeals",
        json={
            "tone": "assertive_legal",
            "selected_finding_ids": selected_ids,
            "custom_instructions": "Highlight emergency transfer from ER to operating suite."
        }
    )
    assert appeal_res.status_code == 201
    appeal_data = appeal_res.json()

    # Verify real persisted claim data is reflected
    assert "CLM-APPEAL-WF-001" in appeal_data["draft_content"]
    assert "Aetna Health" in appeal_data["draft_content"]
    assert "AET-99124" in appeal_data["draft_content"]
    assert "$7,200.00" in appeal_data["draft_content"]
    assert "CO-197" in appeal_data["draft_content"]
    assert "Highlight emergency transfer from ER to operating suite." in appeal_data["draft_content"]

    # Verify selected findings are included
    assert selected_rejection["title"] in appeal_data["draft_content"]
    assert appeal_data["included_finding_ids"] == selected_ids

@pytest.mark.asyncio
async def test_appeal_factual_grounding_no_invented_clauses(client, tmp_path):
    """
    Ensure that a non-emergency claim (e.g. diagnostic MRI denied for medical necessity CO-50)
    does NOT fabricate EMTALA emergency claims, and instead cites ERISA and clinical criteria.
    """
    claim_res = await client.post("/api/claims", json={
        "claim_reference": "CLM-MED-NEC-002",
        "patient_reference": "PAT-NONEMERG-02",
        "insurer_name": "United Healthcare",
        "claim_amount": 3100.0,
        "rejection_reason": "Service not medically necessary based on clinical coverage criteria.",
        "rejection_code": "CO-50",
        "policy_number": "UHC-99442",
        "date_of_service": "2026-02-10"
    })
    claim_id = claim_res.json()["id"]

    pdf_path = str(tmp_path / "mri_report.pdf")
    DemoSeeder.create_sample_pdf(
        pdf_path,
        "DIAGNOSTIC RADIOLOGY REPORT",
        [
            "Patient: Robert Johnson | Member ID: UHC-99442",
            "Referring Physician: Dr. Marcus Vance, MD",
            "Procedure: CPT 72148 MRI Lumbar Spine without Contrast",
            "Indication: Chronic lumbar radiculopathy unresponsive to conservative therapy.",
            "Diagnosis: ICD-10 M54.5 (Low back pain) and M51.26 (Intervertebral disc displacement).",
            "Findings: Severe L4-L5 disc herniation with nerve root impingement.",
            "Total Charges: $3,100.00"
        ]
    )

    with open(pdf_path, "rb") as f:
        file_bytes = f.read()

    await client.post(
        f"/api/claims/{claim_id}/documents",
        files={"file": ("mri_report.pdf", file_bytes, "application/pdf")},
        data={"document_type": "diagnostic_report"}
    )
    await client.post(f"/api/claims/{claim_id}/analyze")

    # Generate appeal
    appeal_res = await client.post(
        f"/api/claims/{claim_id}/appeals",
        json={"tone": "clinical_concise"}
    )
    assert appeal_res.status_code == 201
    draft = appeal_res.json()["draft_content"]

    # Assert EMTALA is NOT cited (not an emergency claim)
    assert "EMTALA" not in draft
    assert "42 U.S.C. § 1395dd" not in draft

    # Assert Medical Necessity & ERISA statutory disclosure ARE cited
    assert "29 U.S.C. § 1133" in draft
    assert "29 C.F.R. § 2560.503-1" in draft
    assert "M54.5" in draft or "72148" in draft
    assert "Dr. Marcus Vance" in draft or "Lumbar" in draft

@pytest.mark.asyncio
async def test_appeal_save_edit_approval_and_rejection_cycle(client):
    # 1. Create claim
    claim_res = await client.post("/api/claims", json={
        "claim_reference": "CLM-CYCLE-003",
        "patient_reference": "PAT-CYCLE-03",
        "insurer_name": "Cigna Healthcare",
        "claim_amount": 1850.0,
        "rejection_reason": "Claim submission exceeds timely filing limit.",
        "rejection_code": "CO-29"
    })
    claim_id = claim_res.json()["id"]

    # 2. Generate initial draft
    appeal_res = await client.post(f"/api/claims/{claim_id}/appeals")
    assert appeal_res.status_code == 201
    appeal = appeal_res.json()
    appeal_id = appeal["id"]
    assert appeal["approval_status"] == "draft"

    # 3. Edit and Save Draft
    custom_draft = appeal["draft_content"] + "\n\n**Reviewer Added Evidence:** EDI batch tracking confirmation #8829182."
    save_res = await client.patch(
        f"/api/appeals/{appeal_id}",
        json={
            "appeal_title": "Customized Timely Filing Rebuttal for Cigna",
            "draft_content": custom_draft,
            "reviewer_notes": "Added EDI confirmation number from clearinghouse."
        }
    )
    assert save_res.status_code == 200
    saved = save_res.json()
    assert saved["appeal_title"] == "Customized Timely Filing Rebuttal for Cigna"
    assert "EDI batch tracking confirmation #8829182" in saved["draft_content"]
    assert saved["reviewer_notes"] == "Added EDI confirmation number from clearinghouse."

    # 4. Reviewer Rejection Flow
    reject_res = await client.patch(
        f"/api/appeals/{appeal_id}",
        json={
            "approval_status": "rejected",
            "reviewer_notes": "Returned for revision: Missing clearinghouse acceptance timestamp."
        }
    )
    assert reject_res.status_code == 200
    rejected = reject_res.json()
    assert rejected["approval_status"] == "rejected"
    assert rejected["approved_at"] is None

    # Check parent claim status updated to in_review
    claim_check = await client.get(f"/api/claims/{claim_id}")
    assert claim_check.json()["status"] == "in_review"

    # 5. Reviewer Approval Flow
    approve_res = await client.patch(
        f"/api/appeals/{appeal_id}",
        json={
            "approval_status": "approved",
            "approved_by": "Senior Billing Auditor Marcus Vance, CPC",
            "reviewer_notes": "Accepted timestamp verified. Approved for official filing."
        }
    )
    assert approve_res.status_code == 200
    approved = approve_res.json()
    assert approved["approval_status"] == "approved"
    assert approved["approved_by"] == "Senior Billing Auditor Marcus Vance, CPC"
    assert approved["approved_at"] is not None

    # Check parent claim status updated to completed
    claim_check2 = await client.get(f"/api/claims/{claim_id}")
    assert claim_check2.json()["status"] == "completed"

@pytest.mark.asyncio
async def test_pdf_export_with_special_characters_and_formatting(client):
    # 1. Create claim
    claim_res = await client.post("/api/claims", json={
        "claim_reference": "CLM-PDF-TEST-004",
        "patient_reference": "PAT-SPEC-04",
        "insurer_name": "Humana Insurance & Co.",
        "claim_amount": 4200.0,
        "rejection_reason": "Out of network provider & balance billing dispute.",
        "rejection_code": "PR-204"
    })
    claim_id = claim_res.json()["id"]

    # 2. Generate appeal
    appeal_res = await client.post(f"/api/claims/{claim_id}/appeals")
    appeal_id = appeal_res.json()["id"]

    # 3. Add special characters that commonly break XML parsers: &, <, >, quotes, code, bold
    special_text = (
        "### 1. SUMMARY OF SPECIAL CHARACTERS & STATUTORY REBUTTAL\n"
        "Testing Section A & Section B with `<clinical_tag>` and `CPT 99214`.\n"
        "Value < $5,000.00 & Value > $1,000.00.\n"
        "**Bold Statement with & ampersand and quotes \"like this\"**\n"
        "- Bullet point with *italicized text* & statutory reference § 1133."
    )
    await client.patch(
        f"/api/appeals/{appeal_id}",
        json={
            "draft_content": special_text,
            "approval_status": "approved",
            "approved_by": "Reviewer & Audit Specialist",
            "reviewer_notes": "Tested & verified with <XML> safe symbols."
        }
    )

    # 4. Export PDF
    pdf_res = await client.get(f"/api/appeals/{appeal_id}/export?format=pdf")
    assert pdf_res.status_code == 200
    assert pdf_res.headers["content-type"] == "application/pdf"
    assert pdf_res.content.startswith(b"%PDF-")
    assert len(pdf_res.content) > 1000

    # 5. Export TXT
    txt_res = await client.get(f"/api/appeals/{appeal_id}/export?format=txt")
    assert txt_res.status_code == 200
    assert "text/plain" in txt_res.headers["content-type"]
    assert "Section A & Section B" in txt_res.text
