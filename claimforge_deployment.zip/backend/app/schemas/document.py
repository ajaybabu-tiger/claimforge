from typing import Optional, Dict, Any, List
from datetime import datetime
from pydantic import BaseModel, Field, ConfigDict

class ExtractedEntities(BaseModel):
    dates: List[str] = []
    amounts: List[float] = []
    total_amount: Optional[float] = None
    patient_names: List[str] = []
    provider_names: List[str] = []
    diagnosis_codes: List[str] = []
    procedure_codes: List[str] = []
    pre_auth_numbers: List[str] = []
    policy_numbers: List[str] = []
    denial_codes: List[str] = []
    document_type_inferred: Optional[str] = None
    integrity_flags: List[str] = []

class DocumentResponse(BaseModel):
    id: str
    claim_id: str
    original_filename: str
    document_type: str
    storage_path: str
    mime_type: str
    file_size: int
    page_count: int
    processing_status: str
    extracted_text: Optional[str] = None
    extracted_metadata: Optional[Dict[str, Any]] = None
    error_message: Optional[str] = None
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True)

class DocumentTextResponse(BaseModel):
    id: str
    claim_id: str
    original_filename: str
    page_count: int
    extracted_text: Optional[str] = None
    extracted_metadata: Optional[Dict[str, Any]] = None
