from typing import Optional, List
from datetime import datetime
from pydantic import BaseModel, Field, ConfigDict

class FindingBase(BaseModel):
    category: str = Field(..., description="missing_evidence, cross_document_inconsistency, document_integrity, rejection_analysis, extracted_fact, recommended_action")
    severity: str = Field("info", description="info, low, medium, high, critical")
    title: str
    explanation: str
    supporting_document_ids: Optional[List[str]] = []
    evidence_reference: Optional[str] = None
    confidence: Optional[float] = 1.0
    reviewer_status: Optional[str] = "unreviewed" # unreviewed, confirmed, dismissed, edited
    reviewer_comment: Optional[str] = None

class FindingCreate(FindingBase):
    claim_id: str

class FindingUpdate(BaseModel):
    reviewer_status: Optional[str] = None
    reviewer_comment: Optional[str] = None
    title: Optional[str] = None
    explanation: Optional[str] = None
    severity: Optional[str] = None

class FindingResponse(FindingBase):
    id: str
    claim_id: str
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True)

class FindingsGroupedResponse(BaseModel):
    claim_id: str
    total_findings: int
    extracted_facts: List[FindingResponse] = []
    missing_evidence: List[FindingResponse] = []
    cross_document_inconsistencies: List[FindingResponse] = []
    document_integrity_indicators: List[FindingResponse] = []
    rejection_analysis: List[FindingResponse] = []
    recommended_actions: List[FindingResponse] = []
