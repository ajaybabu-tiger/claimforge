from typing import Optional, List
from datetime import datetime
from pydantic import BaseModel, Field, ConfigDict

class ClaimBase(BaseModel):
    claim_reference: str = Field(..., description="Unique claim or case ID, e.g. CLM-2026-8891")
    patient_reference: str = Field(..., description="Pseudonymous patient identifier or name, e.g. PAT-9041")
    insurer_name: str = Field(..., description="Name of the health insurance provider")
    claim_amount: float = Field(..., gt=0, description="Total billed or disputed amount in USD")
    rejection_reason: str = Field(..., description="Exact or summarized rejection reason provided by insurer")
    rejection_code: Optional[str] = Field(None, description="Denial code if available, e.g. CO-16, N-56, CO-197")
    policy_number: Optional[str] = Field(None, description="Insurance policy or member group number")
    date_of_service: Optional[str] = Field(None, description="Date or date range of medical care (YYYY-MM-DD)")
    review_priority: Optional[str] = Field("medium", description="Priority level: low, medium, high, urgent")
    reviewer_notes: Optional[str] = Field(None, description="Internal reviewer notes")

class ClaimCreate(ClaimBase):
    pass

class ClaimUpdate(BaseModel):
    claim_reference: Optional[str] = None
    patient_reference: Optional[str] = None
    insurer_name: Optional[str] = None
    claim_amount: Optional[float] = None
    rejection_reason: Optional[str] = None
    rejection_code: Optional[str] = None
    policy_number: Optional[str] = None
    date_of_service: Optional[str] = None
    status: Optional[str] = None
    review_priority: Optional[str] = None
    reviewer_notes: Optional[str] = None

class ClaimResponse(ClaimBase):
    id: str
    status: str
    created_at: datetime
    updated_at: datetime
    documents_count: Optional[int] = 0
    findings_count: Optional[int] = 0
    latest_readiness_score: Optional[float] = None
    latest_appeal_id: Optional[str] = None

    model_config = ConfigDict(from_attributes=True)

class DashboardStats(BaseModel):
    total_claims: int
    awaiting_review: int
    missing_evidence: int
    completed_reviews: int
    total_disputed_amount: float
    avg_readiness_score: float
