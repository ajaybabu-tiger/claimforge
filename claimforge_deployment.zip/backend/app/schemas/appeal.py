from typing import Optional, Dict, Any, List
from datetime import datetime
from pydantic import BaseModel, Field, ConfigDict

class AppealSection(BaseModel):
    title: str
    content: str
    verified_facts: List[str] = []
    assumptions_or_gaps: List[str] = []

class AppealCreate(BaseModel):
    selected_finding_ids: Optional[List[str]] = None
    custom_instructions: Optional[str] = None
    tone: Optional[str] = "formal_professional" # formal_professional, assertive_legal, clinical_concise

class AppealUpdate(BaseModel):
    appeal_title: Optional[str] = None
    draft_content: Optional[str] = None
    structured_sections: Optional[Dict[str, Any]] = None
    approval_status: Optional[str] = None # draft, pending_approval, approved, rejected
    reviewer_notes: Optional[str] = None
    approved_by: Optional[str] = None

class AppealResponse(BaseModel):
    id: str
    claim_id: str
    appeal_title: str
    draft_content: str
    structured_sections: Optional[Dict[str, Any]] = None
    included_finding_ids: Optional[List[str]] = None
    approval_status: str
    reviewer_notes: Optional[str] = None
    approved_by: Optional[str] = None
    approved_at: Optional[datetime] = None
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True)
