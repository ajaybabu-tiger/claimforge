from typing import Optional, Dict, Any, List
from datetime import datetime
from pydantic import BaseModel, Field

class ScoreComponent(BaseModel):
    name: str
    weight: float
    score: float # 0 to 100
    status: str # "good", "warning", "critical"
    details: str
    impact: str # "+25 pts", "-15 pts"

class ReadinessScoreResponse(BaseModel):
    claim_id: str
    readiness_score: float # 0 to 100
    readiness_level: str # "High Readiness", "Moderate Readiness", "Low Readiness", "Critical Deficiencies"
    analysis_mode: str # "rule_based" or "ai_assisted"
    summary: str
    components: List[ScoreComponent]
    positive_factors: List[str]
    negative_factors: List[str]
    recommended_improvements: List[str]
    calculated_at: datetime
