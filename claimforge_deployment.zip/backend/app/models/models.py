import uuid
from datetime import datetime, timezone
from sqlalchemy import Column, String, Float, Integer, Text, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from app.core.database import Base

def generate_uuid() -> str:
    return str(uuid.uuid4())

def get_utc_now() -> datetime:
    return datetime.now(timezone.utc)

class Claim(Base):
    __tablename__ = "claims"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    claim_reference = Column(String(100), unique=True, nullable=False, index=True)
    patient_reference = Column(String(100), nullable=False)
    insurer_name = Column(String(150), nullable=False)
    claim_amount = Column(Float, nullable=False)
    rejection_reason = Column(Text, nullable=False)
    rejection_code = Column(String(50), nullable=True)
    policy_number = Column(String(100), nullable=True)
    date_of_service = Column(String(50), nullable=True)
    status = Column(String(50), nullable=False, default="draft", index=True)
    review_priority = Column(String(20), nullable=False, default="medium")
    reviewer_notes = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), default=get_utc_now, index=True)
    updated_at = Column(DateTime(timezone=True), default=get_utc_now, onupdate=get_utc_now)

    # Relationships
    documents = relationship("Document", back_populates="claim", cascade="all, delete-orphan", lazy="selectin")
    findings = relationship("Finding", back_populates="claim", cascade="all, delete-orphan", lazy="selectin")
    appeals = relationship("Appeal", back_populates="claim", cascade="all, delete-orphan", lazy="selectin")
    analysis_runs = relationship("AnalysisRun", back_populates="claim", cascade="all, delete-orphan", lazy="selectin")

class Document(Base):
    __tablename__ = "documents"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    claim_id = Column(String(36), ForeignKey("claims.id", ondelete="CASCADE"), nullable=False, index=True)
    original_filename = Column(String(255), nullable=False)
    document_type = Column(String(50), nullable=False, default="other")
    storage_path = Column(String(500), nullable=False)
    mime_type = Column(String(100), nullable=False)
    file_size = Column(Integer, nullable=False)
    page_count = Column(Integer, default=1)
    processing_status = Column(String(50), nullable=False, default="pending")
    extracted_text = Column(Text, nullable=True)
    extracted_metadata = Column(Text, nullable=True) # JSON string
    error_message = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), default=get_utc_now)
    updated_at = Column(DateTime(timezone=True), default=get_utc_now, onupdate=get_utc_now)

    # Relationships
    claim = relationship("Claim", back_populates="documents")

class Finding(Base):
    __tablename__ = "findings"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    claim_id = Column(String(36), ForeignKey("claims.id", ondelete="CASCADE"), nullable=False, index=True)
    category = Column(String(50), nullable=False, index=True) # missing_evidence, cross_document_inconsistency, document_integrity, rejection_analysis, extracted_fact, recommended_action
    severity = Column(String(20), nullable=False, default="info", index=True) # info, low, medium, high, critical
    title = Column(String(255), nullable=False)
    explanation = Column(Text, nullable=False)
    supporting_document_ids = Column(Text, nullable=True) # JSON string array
    evidence_reference = Column(Text, nullable=True) # citations, line/field markers
    confidence = Column(Float, default=1.0)
    reviewer_status = Column(String(30), nullable=False, default="unreviewed") # unreviewed, confirmed, dismissed, edited
    reviewer_comment = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), default=get_utc_now)
    updated_at = Column(DateTime(timezone=True), default=get_utc_now, onupdate=get_utc_now)

    # Relationships
    claim = relationship("Claim", back_populates="findings")

class Appeal(Base):
    __tablename__ = "appeals"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    claim_id = Column(String(36), ForeignKey("claims.id", ondelete="CASCADE"), nullable=False, index=True)
    appeal_title = Column(String(255), nullable=False)
    draft_content = Column(Text, nullable=False)
    structured_sections = Column(Text, nullable=True) # JSON string
    included_finding_ids = Column(Text, nullable=True) # JSON string array
    approval_status = Column(String(30), nullable=False, default="draft") # draft, pending_approval, approved, rejected
    reviewer_notes = Column(Text, nullable=True)
    approved_by = Column(String(100), nullable=True)
    approved_at = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), default=get_utc_now)
    updated_at = Column(DateTime(timezone=True), default=get_utc_now, onupdate=get_utc_now)

    # Relationships
    claim = relationship("Claim", back_populates="appeals")

class AnalysisRun(Base):
    __tablename__ = "analysis_runs"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    claim_id = Column(String(36), ForeignKey("claims.id", ondelete="CASCADE"), nullable=False, index=True)
    processing_status = Column(String(50), nullable=False, default="completed")
    analysis_mode = Column(String(50), nullable=False, default="rule_based")
    readiness_score = Column(Float, nullable=False, default=0.0)
    score_breakdown = Column(Text, nullable=True) # JSON string
    error_message = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), default=get_utc_now)

    # Relationships
    claim = relationship("Claim", back_populates="analysis_runs")
