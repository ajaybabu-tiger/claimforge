import json
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.database import get_db
from app.repositories.claim_repo import ClaimRepository
from app.schemas.claim import ClaimCreate, ClaimUpdate, ClaimResponse, DashboardStats
from app.models.models import AnalysisRun, Appeal

router = APIRouter(prefix="/claims", tags=["Claims"])

def _format_claim_response(claim) -> ClaimResponse:
    latest_score = None
    if claim.analysis_runs:
        latest_score = claim.analysis_runs[-1].readiness_score
    
    latest_appeal = None
    if claim.appeals:
        latest_appeal = claim.appeals[-1].id

    return ClaimResponse(
        id=claim.id,
        claim_reference=claim.claim_reference,
        patient_reference=claim.patient_reference,
        insurer_name=claim.insurer_name,
        claim_amount=claim.claim_amount,
        rejection_reason=claim.rejection_reason,
        rejection_code=claim.rejection_code,
        policy_number=claim.policy_number,
        date_of_service=claim.date_of_service,
        status=claim.status,
        review_priority=claim.review_priority,
        reviewer_notes=claim.reviewer_notes,
        created_at=claim.created_at,
        updated_at=claim.updated_at,
        documents_count=len(claim.documents) if claim.documents else 0,
        findings_count=len(claim.findings) if claim.findings else 0,
        latest_readiness_score=latest_score,
        latest_appeal_id=latest_appeal
    )

@router.get("", response_model=List[ClaimResponse])
async def list_claims(
    status: Optional[str] = Query(None, description="Filter by claim status"),
    search: Optional[str] = Query(None, description="Search term for claim ref, patient, insurer"),
    limit: int = Query(100, ge=1, le=500),
    offset: int = Query(0, ge=0),
    db: AsyncSession = Depends(get_db)
):
    repo = ClaimRepository(db)
    claims = await repo.get_all(status=status, search=search, limit=limit, offset=offset)
    return [_format_claim_response(c) for c in claims]

@router.post("", response_model=ClaimResponse, status_code=status.HTTP_201_CREATED)
async def create_claim(claim_in: ClaimCreate, db: AsyncSession = Depends(get_db)):
    repo = ClaimRepository(db)
    existing = await repo.get_by_reference(claim_in.claim_reference)
    if existing:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Claim with reference '{claim_in.claim_reference}' already exists."
        )
    claim = await repo.create(claim_in)
    return _format_claim_response(claim)

@router.get("/{claim_id}", response_model=ClaimResponse)
async def get_claim(claim_id: str, db: AsyncSession = Depends(get_db)):
    repo = ClaimRepository(db)
    claim = await repo.get_by_id(claim_id)
    if not claim:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Claim not found")
    return _format_claim_response(claim)

@router.patch("/{claim_id}", response_model=ClaimResponse)
async def update_claim(claim_id: str, claim_update: ClaimUpdate, db: AsyncSession = Depends(get_db)):
    repo = ClaimRepository(db)
    claim = await repo.update(claim_id, claim_update)
    if not claim:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Claim not found")
    return _format_claim_response(claim)

@router.delete("/{claim_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_claim(claim_id: str, db: AsyncSession = Depends(get_db)):
    repo = ClaimRepository(db)
    success = await repo.delete(claim_id)
    if not success:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Claim not found")
    return None
