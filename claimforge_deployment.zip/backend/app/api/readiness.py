from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.database import get_db
from app.repositories.claim_repo import ClaimRepository
from app.repositories.document_repo import DocumentRepository
from app.repositories.finding_repo import FindingRepository
from app.services.readiness_service import ReadinessService
from app.schemas.readiness import ReadinessScoreResponse

router = APIRouter(tags=["Readiness"])

@router.get("/claims/{claim_id}/readiness", response_model=ReadinessScoreResponse)
async def get_claim_readiness(claim_id: str, db: AsyncSession = Depends(get_db)):
    claim_repo = ClaimRepository(db)
    claim = await claim_repo.get_by_id(claim_id)
    if not claim:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Claim not found")

    doc_repo = DocumentRepository(db)
    docs = await doc_repo.get_by_claim_id(claim_id)

    finding_repo = FindingRepository(db)
    findings = await finding_repo.get_by_claim_id(claim_id)

    score_res = ReadinessService.calculate_score(claim, docs, findings)
    return score_res
