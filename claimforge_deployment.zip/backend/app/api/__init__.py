from fastapi import APIRouter
from app.api.health import router as health_router
from app.api.claims import router as claims_router
from app.api.documents import router as documents_router
from app.api.analysis import router as analysis_router
from app.api.findings import router as findings_router
from app.api.readiness import router as readiness_router
from app.api.appeals import router as appeals_router
from app.api.demo import router as demo_router

api_router = APIRouter()

api_router.include_router(health_router)
api_router.include_router(claims_router)
api_router.include_router(documents_router)
api_router.include_router(analysis_router)
api_router.include_router(findings_router)
api_router.include_router(readiness_router)
api_router.include_router(appeals_router)
api_router.include_router(demo_router)

__all__ = ["api_router"]
