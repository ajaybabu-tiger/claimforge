from fastapi import APIRouter, Depends, status
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.database import get_db
from app.services.demo_seeder import DemoSeeder
from app.repositories.claim_repo import ClaimRepository
from app.schemas.claim import DashboardStats

router = APIRouter(tags=["Demo & Dashboard"])

@router.get("/dashboard/stats", response_model=DashboardStats)
async def get_dashboard_metrics(db: AsyncSession = Depends(get_db)):
    repo = ClaimRepository(db)
    return await repo.get_dashboard_stats()

@router.get("/demo/cases")
async def get_demo_scenarios():
    return {
        "scenarios": [
            {
                "id": "scenario-1",
                "title": "Emergency Appendectomy Prior-Auth Dispute",
                "claim_reference": "CLM-2026-9011",
                "patient_name": "Alexander Wright (PAT-EMERG-441)",
                "insurer": "BlueShield Horizon",
                "amount": 8450.00,
                "denial_code": "CO-197",
                "denial_reason": "Missing prior authorization for acute inpatient surgical admission.",
                "readiness_score": 91.0,
                "readiness_level": "High Readiness",
                "description": "Patient admitted through ED for acute appendicitis. Denial overturned under EMTALA emergency exception regulations."
            },
            {
                "id": "scenario-2",
                "title": "Cardiac MRI Medical Necessity Rebuttal",
                "claim_reference": "CLM-2026-7823",
                "patient_name": "Eleanor Vance (PAT-CARDIO-102)",
                "insurer": "Aetna Premier Health",
                "amount": 3200.00,
                "denial_code": "CO-50",
                "denial_reason": "Denied as not medically necessary / investigational diagnostic imaging.",
                "readiness_score": 74.0,
                "readiness_level": "Moderate Readiness",
                "description": "Diagnostic MRI with contrast for dilated cardiomyopathy. Substantiated with ACC/AHA Class I clinical guidelines."
            },
            {
                "id": "scenario-3",
                "title": "Emergency Out-of-Network Balance Billing",
                "claim_reference": "CLM-2026-3118",
                "patient_name": "David Chen (PAT-ORTHO-802)",
                "insurer": "Cigna Global Care",
                "amount": 5600.00,
                "denial_code": "PR-204",
                "denial_reason": "Out-of-network physician balance billing not covered under in-network plan tier.",
                "readiness_score": 94.0,
                "readiness_level": "High Readiness",
                "description": "On-call trauma orthopedic surgeon balance billing at an in-network facility. Fully protected under federal No Surprises Act."
            },
            {
                "id": "scenario-4",
                "title": "Altered Invoice & Document Integrity Flag",
                "claim_reference": "CLM-2026-4409",
                "patient_name": "Jonathan Reed (PAT-TRAUMA-991)",
                "insurer": "United Healthcare",
                "amount": 14800.00,
                "denial_code": "CO-16",
                "denial_reason": "Billed amount exceeds allowable schedule and invoice contains unverified line items.",
                "readiness_score": 42.0,
                "readiness_level": "Low Readiness",
                "description": "Cross-document check flagged $3,600 arithmetic mismatch between line-items ($11,200) and stated total ($14,800), with font anomalies."
            }
        ]
    }

@router.post("/demo/seed", status_code=status.HTTP_201_CREATED)
async def seed_demo_data(db: AsyncSession = Depends(get_db)):
    """
    Seeds the 4 complete synthetic scenarios into the local database with real document files and analysis results.
    """
    seeded_ids = await DemoSeeder.seed_all(db)
    return {
        "status": "success",
        "message": f"Successfully seeded {len(seeded_ids)} synthetic demo cases with extracted documents and analysis findings.",
        "seeded_claim_ids": seeded_ids
    }
