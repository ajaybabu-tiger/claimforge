import json
from typing import Dict, Any
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.database import get_db
from app.repositories.claim_repo import ClaimRepository
from app.repositories.document_repo import DocumentRepository
from app.repositories.finding_repo import FindingRepository
from app.services.analysis_engine import AnalysisEngine
from app.services.readiness_service import ReadinessService
from app.services.ai_service import AIService
from app.models.models import AnalysisRun
from app.schemas.claim import ClaimUpdate
from app.schemas.readiness import ReadinessScoreResponse

router = APIRouter(tags=["Analysis"])

@router.post("/claims/{claim_id}/analyze")
async def trigger_claim_analysis(claim_id: str, db: AsyncSession = Depends(get_db)):
    """
    Executes full multi-document analysis, generates structured findings,
    calculates the Appeal Readiness Score, and persists results.
    """
    claim_repo = ClaimRepository(db)
    claim = await claim_repo.get_by_id(claim_id)
    if not claim:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Claim not found")

    doc_repo = DocumentRepository(db)
    docs = await doc_repo.get_by_claim_id(claim_id)

    # 1. Run Analysis Engine
    findings_to_create, analysis_mode = await AIService.analyze_claim_with_fallback(claim, docs)

    # 2. Persist findings (replacing previous runs for idempotency)
    finding_repo = FindingRepository(db)
    await finding_repo.delete_by_claim_id(claim_id)
    saved_findings = await finding_repo.create_many(findings_to_create)

    # 3. Calculate Appeal Readiness Score
    score_response = ReadinessService.calculate_score(claim, docs, saved_findings)

    # 4. Save Analysis Run
    run = AnalysisRun(
        claim_id=claim_id,
        processing_status="completed",
        analysis_mode=analysis_mode,
        readiness_score=score_response.readiness_score,
        score_breakdown=json.dumps(score_response.model_dump(), default=str)
    )
    db.add(run)

    # 5. Update claim status
    new_status = "analyzed" if claim.status in ["draft", "documents_uploaded"] else claim.status
    await claim_repo.update(claim_id, ClaimUpdate(status=new_status))
    await db.commit()

    return {
        "claim_id": claim_id,
        "status": "completed",
        "analysis_mode": analysis_mode,
        "findings_generated": len(saved_findings),
        "readiness_score": score_response.readiness_score,
        "readiness_level": score_response.readiness_level,
        "summary": score_response.summary
    }
