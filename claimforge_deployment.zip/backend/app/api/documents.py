import os
import uuid
import json
from pathlib import Path
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form, status
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.config import settings
from app.core.database import get_db
from app.repositories.claim_repo import ClaimRepository
from app.repositories.document_repo import DocumentRepository
from app.schemas.document import DocumentResponse, DocumentTextResponse
from app.services.extractor import DocumentExtractor
from app.schemas.claim import ClaimUpdate

router = APIRouter(tags=["Documents"])

def _format_doc_response(doc) -> DocumentResponse:
    meta = None
    if doc.extracted_metadata:
        try:
            meta = json.loads(doc.extracted_metadata) if isinstance(doc.extracted_metadata, str) else doc.extracted_metadata
        except Exception:
            meta = {}
    return DocumentResponse(
        id=doc.id,
        claim_id=doc.claim_id,
        original_filename=doc.original_filename,
        document_type=doc.document_type,
        storage_path=doc.storage_path,
        mime_type=doc.mime_type,
        file_size=doc.file_size,
        page_count=doc.page_count or 1,
        processing_status=doc.processing_status,
        extracted_text=doc.extracted_text,
        extracted_metadata=meta,
        error_message=doc.error_message,
        created_at=doc.created_at,
        updated_at=doc.updated_at
    )

@router.post("/claims/{claim_id}/documents", response_model=DocumentResponse, status_code=status.HTTP_201_CREATED)
async def upload_claim_document(
    claim_id: str,
    file: UploadFile = File(...),
    document_type: str = Form("other"),
    db: AsyncSession = Depends(get_db)
):
    claim_repo = ClaimRepository(db)
    claim = await claim_repo.get_by_id(claim_id)
    if not claim:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Claim not found")

    # Validate MIME type / extension
    filename = file.filename or "uploaded_document"
    ext = Path(filename).suffix.lower()
    content_type = file.content_type or "application/octet-stream"

    if content_type not in settings.ALLOWED_MIME_TYPES and ext not in [".pdf", ".png", ".jpg", ".jpeg", ".webp"]:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Unsupported file type: {content_type}. Allowed: PDF, PNG, JPEG, WEBP."
        )

    # Save file to storage directory
    safe_filename = f"{claim_id}_{uuid.uuid4().hex[:8]}_{Path(filename).name}"
    save_path = os.path.join(settings.UPLOAD_DIR, safe_filename)

    try:
        contents = await file.read()
        file_size = len(contents)
        if file_size > settings.MAX_UPLOAD_SIZE_BYTES:
            raise HTTPException(
                status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                detail=f"File exceeds maximum allowed size of {settings.MAX_UPLOAD_SIZE_BYTES / (1024*1024):.1f} MB."
            )

        with open(save_path, "wb") as f:
            f.write(contents)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Failed to save file: {str(e)}")

    # Extract text & entities
    extracted_text = ""
    entities = {}
    page_count = 1
    processing_status = "processed"
    error_msg = None

    try:
        extracted_text, entities, page_count = DocumentExtractor.extract_from_file(save_path, content_type)
        # If document_type was default "other", use inferred type if available
        if document_type == "other" and entities.get("document_type_inferred") and entities["document_type_inferred"] != "other":
            document_type = entities["document_type_inferred"]
    except Exception as e:
        processing_status = "failed"
        error_msg = str(e)

    # Save to database
    doc_repo = DocumentRepository(db)
    doc = await doc_repo.create(
        claim_id=claim_id,
        original_filename=filename,
        document_type=document_type,
        storage_path=save_path,
        mime_type=content_type,
        file_size=file_size,
        page_count=page_count,
        processing_status=processing_status
    )

    if processing_status == "processed":
        await doc_repo.update_extraction(
            document_id=doc.id,
            extracted_text=extracted_text,
            extracted_metadata=entities,
            page_count=page_count,
            processing_status=processing_status,
            error_message=error_msg
        )

    # Update claim status
    if claim.status == "draft":
        await claim_repo.update(claim_id, ClaimUpdate(status="documents_uploaded"))

    doc = await doc_repo.get_by_id(doc.id)
    return _format_doc_response(doc)

@router.get("/claims/{claim_id}/documents", response_model=List[DocumentResponse])
async def list_claim_documents(claim_id: str, db: AsyncSession = Depends(get_db)):
    claim_repo = ClaimRepository(db)
    claim = await claim_repo.get_by_id(claim_id)
    if not claim:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Claim not found")

    doc_repo = DocumentRepository(db)
    docs = await doc_repo.get_by_claim_id(claim_id)
    return [_format_doc_response(d) for d in docs]

@router.get("/documents/{document_id}/text", response_model=DocumentTextResponse)
async def get_document_text(document_id: str, db: AsyncSession = Depends(get_db)):
    doc_repo = DocumentRepository(db)
    doc = await doc_repo.get_by_id(document_id)
    if not doc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Document not found")

    meta = None
    if doc.extracted_metadata:
        try:
            meta = json.loads(doc.extracted_metadata) if isinstance(doc.extracted_metadata, str) else doc.extracted_metadata
        except Exception:
            meta = {}

    return DocumentTextResponse(
        id=doc.id,
        claim_id=doc.claim_id,
        original_filename=doc.original_filename,
        page_count=doc.page_count or 1,
        extracted_text=doc.extracted_text,
        extracted_metadata=meta
    )

@router.delete("/documents/{document_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_document(document_id: str, db: AsyncSession = Depends(get_db)):
    doc_repo = DocumentRepository(db)
    doc = await doc_repo.get_by_id(document_id)
    if not doc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Document not found")

    # Clean local file if exists
    if os.path.exists(doc.storage_path):
        try:
            os.remove(doc.storage_path)
        except Exception:
            pass

    await doc_repo.delete(document_id)
    return None
