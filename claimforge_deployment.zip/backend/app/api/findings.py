import json
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.database import get_db
from app.repositories.claim_repo import ClaimRepository
from app.repositories.finding_repo import FindingRepository
from app.schemas.finding import FindingResponse, FindingUpdate, FindingsGroupedResponse

router = APIRouter(tags=["Findings"])

def _format_finding(f) -> FindingResponse:
    doc_ids = []
    if f.supporting_document_ids:
        try:
            doc_ids = json.loads(f.supporting_document_ids) if isinstance(f.supporting_document_ids, str) else f.supporting_document_ids
        except Exception:
            doc_ids = []

    return FindingResponse(
        id=f.id,
        claim_id=f.claim_id,
        category=f.category,
        severity=f.severity,
        title=f.title,
        explanation=f.explanation,
        supporting_document_ids=doc_ids,
        evidence_reference=f.evidence_reference,
        confidence=f.confidence or 1.0,
        reviewer_status=f.reviewer_status or "unreviewed",
        reviewer_comment=f.reviewer_comment,
        created_at=f.created_at,
        updated_at=f.updated_at
    )

@router.get("/claims/{claim_id}/findings", response_model=FindingsGroupedResponse)
async def get_claim_findings(claim_id: str, db: AsyncSession = Depends(get_db)):
    claim_repo = ClaimRepository(db)
    claim = await claim_repo.get_by_id(claim_id)
    if not claim:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Claim not found")

    finding_repo = FindingRepository(db)
    findings = await finding_repo.get_by_claim_id(claim_id)
    formatted = [_format_finding(f) for f in findings]

    grouped = FindingsGroupedResponse(
        claim_id=claim_id,
        total_findings=len(formatted),
        extracted_facts=[f for f in formatted if f.category == "extracted_fact"],
        missing_evidence=[f for f in formatted if f.category == "missing_evidence"],
        cross_document_inconsistencies=[f for f in formatted if f.category == "cross_document_inconsistency"],
        document_integrity_indicators=[f for f in formatted if f.category == "document_integrity"],
        rejection_analysis=[f for f in formatted if f.category == "rejection_analysis"],
        recommended_actions=[f for f in formatted if f.category == "recommended_action"]
    )
    return grouped

@router.patch("/findings/{finding_id}", response_model=FindingResponse)
async def update_finding_review(finding_id: str, finding_update: FindingUpdate, db: AsyncSession = Depends(get_db)):
    finding_repo = FindingRepository(db)
    finding = await finding_repo.update(finding_id, finding_update)
    if not finding:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Finding not found")
    return _format_finding(finding)
