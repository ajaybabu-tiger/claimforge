import json
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query, Response, status
from fastapi.responses import StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession
import io
from app.core.database import get_db
from app.repositories.claim_repo import ClaimRepository
from app.repositories.document_repo import DocumentRepository
from app.repositories.finding_repo import FindingRepository
from app.repositories.appeal_repo import AppealRepository
from app.schemas.appeal import AppealCreate, AppealUpdate, AppealResponse
from app.schemas.claim import ClaimUpdate
from app.services.appeal_generator import AppealGenerator
from app.services.pdf_exporter import PDFExporter

router = APIRouter(tags=["Appeals"])

def _format_appeal(app) -> AppealResponse:
    secs = None
    if app.structured_sections:
        try:
            secs = json.loads(app.structured_sections) if isinstance(app.structured_sections, str) else app.structured_sections
        except Exception:
            secs = {}
    
    finding_ids = None
    if app.included_finding_ids:
        try:
            finding_ids = json.loads(app.included_finding_ids) if isinstance(app.included_finding_ids, str) else app.included_finding_ids
        except Exception:
            finding_ids = []

    return AppealResponse(
        id=app.id,
        claim_id=app.claim_id,
        appeal_title=app.appeal_title,
        draft_content=app.draft_content,
        structured_sections=secs,
        included_finding_ids=finding_ids,
        approval_status=app.approval_status,
        reviewer_notes=app.reviewer_notes,
        approved_by=app.approved_by,
        approved_at=app.approved_at,
        created_at=app.created_at,
        updated_at=app.updated_at
    )

@router.post("/claims/{claim_id}/appeals", response_model=AppealResponse, status_code=status.HTTP_201_CREATED)
async def generate_claim_appeal(
    claim_id: str,
    appeal_in: Optional[AppealCreate] = None,
    db: AsyncSession = Depends(get_db)
):
    claim_repo = ClaimRepository(db)
    claim = await claim_repo.get_by_id(claim_id)
    if not claim:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Claim not found")

    doc_repo = DocumentRepository(db)
    docs = await doc_repo.get_by_claim_id(claim_id)

    finding_repo = FindingRepository(db)
    findings = await finding_repo.get_by_claim_id(claim_id)

    # Filter findings if specific IDs requested (preserving reviewer selection order)
    if appeal_in and appeal_in.selected_finding_ids is not None:
        finding_map = {f.id: f for f in findings}
        findings = [finding_map[fid] for fid in appeal_in.selected_finding_ids if fid in finding_map]
    else:
        # Default: exclude dismissed findings
        findings = [f for f in findings if f.reviewer_status != "dismissed"]

    custom_instr = appeal_in.custom_instructions if appeal_in else None
    tone = appeal_in.tone if appeal_in and appeal_in.tone else "formal_professional"

    generated = AppealGenerator.generate_draft(claim, docs, findings, custom_instructions=custom_instr, tone=tone)

    appeal_repo = AppealRepository(db)
    appeal = await appeal_repo.create(
        claim_id=claim.id,
        appeal_title=generated["title"],
        draft_content=generated["draft_content"],
        structured_sections=generated["structured_sections"],
        included_finding_ids=generated["included_finding_ids"]
    )

    # Update claim status
    await claim_repo.update(claim_id, ClaimUpdate(status="appeal_generated"))

    return _format_appeal(appeal)

@router.get("/claims/{claim_id}/appeals", response_model=List[AppealResponse])
async def list_claim_appeals(claim_id: str, db: AsyncSession = Depends(get_db)):
    appeal_repo = AppealRepository(db)
    appeals = await appeal_repo.get_by_claim_id(claim_id)
    return [_format_appeal(a) for a in appeals]

@router.get("/appeals/{appeal_id}", response_model=AppealResponse)
async def get_appeal(appeal_id: str, db: AsyncSession = Depends(get_db)):
    appeal_repo = AppealRepository(db)
    appeal = await appeal_repo.get_by_id(appeal_id)
    if not appeal:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Appeal not found")
    return _format_appeal(appeal)

@router.patch("/appeals/{appeal_id}", response_model=AppealResponse)
async def update_appeal(appeal_id: str, appeal_update: AppealUpdate, db: AsyncSession = Depends(get_db)):
    appeal_repo = AppealRepository(db)
    appeal = await appeal_repo.update(appeal_id, appeal_update)
    if not appeal:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Appeal not found")

    claim_repo = ClaimRepository(db)
    if appeal_update.approval_status == "approved":
        await claim_repo.update(appeal.claim_id, ClaimUpdate(status="completed"))
    elif appeal_update.approval_status == "rejected":
        await claim_repo.update(appeal.claim_id, ClaimUpdate(status="in_review"))
    elif appeal_update.approval_status == "draft":
        await claim_repo.update(appeal.claim_id, ClaimUpdate(status="appeal_generated"))

    return _format_appeal(appeal)

@router.get("/appeals/{appeal_id}/export")
async def export_appeal(
    appeal_id: str,
    format: str = Query("pdf", description="Export format: pdf or txt"),
    db: AsyncSession = Depends(get_db)
):
    appeal_repo = AppealRepository(db)
    appeal = await appeal_repo.get_by_id(appeal_id)
    if not appeal:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Appeal not found")

    claim_repo = ClaimRepository(db)
    claim = await claim_repo.get_by_id(appeal.claim_id)
    if not claim:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Associated claim not found")

    safe_ref = claim.claim_reference.replace("/", "_").replace("\\", "_")

    if format.lower() == "txt":
        return Response(
            content=appeal.draft_content,
            media_type="text/plain; charset=utf-8",
            headers={"Content-Disposition": f'attachment; filename="ClaimForge_Appeal_{safe_ref}.txt"'}
        )

    # PDF Export
    pdf_bytes = PDFExporter.export_appeal_pdf(claim, appeal)
    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={"Content-Disposition": f'attachment; filename="ClaimForge_Appeal_{safe_ref}.pdf"'}
    )
