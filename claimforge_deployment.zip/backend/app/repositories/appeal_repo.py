import json
from datetime import datetime, timezone
from typing import Optional, List, Dict, Any
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update, delete, desc
from app.models.models import Appeal
from app.schemas.appeal import AppealUpdate

class AppealRepository:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def get_by_id(self, appeal_id: str) -> Optional[Appeal]:
        query = select(Appeal).where(Appeal.id == appeal_id)
        result = await self.session.execute(query)
        return result.scalar_one_or_none()

    async def get_by_claim_id(self, claim_id: str) -> List[Appeal]:
        query = select(Appeal).where(Appeal.claim_id == claim_id).order_by(desc(Appeal.created_at))
        result = await self.session.execute(query)
        return list(result.scalars().all())

    async def get_latest_by_claim_id(self, claim_id: str) -> Optional[Appeal]:
        query = select(Appeal).where(Appeal.claim_id == claim_id).order_by(desc(Appeal.created_at)).limit(1)
        result = await self.session.execute(query)
        return result.scalar_one_or_none()

    async def create(
        self,
        claim_id: str,
        appeal_title: str,
        draft_content: str,
        structured_sections: Optional[Dict[str, Any]] = None,
        included_finding_ids: Optional[List[str]] = None
    ) -> Appeal:
        appeal = Appeal(
            claim_id=claim_id,
            appeal_title=appeal_title,
            draft_content=draft_content,
            structured_sections=json.dumps(structured_sections) if structured_sections else None,
            included_finding_ids=json.dumps(included_finding_ids) if included_finding_ids else None,
            approval_status="draft"
        )
        self.session.add(appeal)
        await self.session.commit()
        await self.session.refresh(appeal)
        return appeal

    async def update(self, appeal_id: str, appeal_update: AppealUpdate) -> Optional[Appeal]:
        appeal = await self.get_by_id(appeal_id)
        if not appeal:
            return None
        
        update_data = appeal_update.model_dump(exclude_unset=True)
        if "structured_sections" in update_data and isinstance(update_data["structured_sections"], dict):
            appeal.structured_sections = json.dumps(update_data["structured_sections"])
            del update_data["structured_sections"]

        for key, value in update_data.items():
            setattr(appeal, key, value)

        if appeal_update.approval_status == "approved":
            if not appeal.approved_at:
                appeal.approved_at = datetime.now(timezone.utc)
        elif appeal_update.approval_status in ["draft", "rejected"]:
            appeal.approved_at = None
            
        await self.session.commit()
        await self.session.refresh(appeal)
        return appeal
