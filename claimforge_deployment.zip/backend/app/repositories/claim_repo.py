from typing import Optional, List
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update, delete, func, desc
from app.models.models import Claim, Document, Finding, Appeal, AnalysisRun
from app.schemas.claim import ClaimCreate, ClaimUpdate, DashboardStats

class ClaimRepository:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def get_all(self, status: Optional[str] = None, search: Optional[str] = None, limit: int = 100, offset: int = 0) -> List[Claim]:
        query = select(Claim).order_by(desc(Claim.created_at))
        if status and status != "all":
            query = query.where(Claim.status == status)
        if search:
            search_term = f"%{search}%"
            query = query.where(
                (Claim.claim_reference.ilike(search_term)) |
                (Claim.patient_reference.ilike(search_term)) |
                (Claim.insurer_name.ilike(search_term)) |
                (Claim.rejection_reason.ilike(search_term))
            )
        query = query.limit(limit).offset(offset)
        result = await self.session.execute(query)
        return list(result.scalars().all())

    async def get_by_id(self, claim_id: str) -> Optional[Claim]:
        query = select(Claim).where(Claim.id == claim_id)
        result = await self.session.execute(query)
        return result.scalar_one_or_none()

    async def get_by_reference(self, claim_reference: str) -> Optional[Claim]:
        query = select(Claim).where(Claim.claim_reference == claim_reference)
        result = await self.session.execute(query)
        return result.scalar_one_or_none()

    async def create(self, claim_in: ClaimCreate) -> Claim:
        claim = Claim(
            claim_reference=claim_in.claim_reference,
            patient_reference=claim_in.patient_reference,
            insurer_name=claim_in.insurer_name,
            claim_amount=claim_in.claim_amount,
            rejection_reason=claim_in.rejection_reason,
            rejection_code=claim_in.rejection_code,
            policy_number=claim_in.policy_number,
            date_of_service=claim_in.date_of_service,
            review_priority=claim_in.review_priority or "medium",
            reviewer_notes=claim_in.reviewer_notes,
            status="draft"
        )
        self.session.add(claim)
        await self.session.commit()
        await self.session.refresh(claim)
        return claim

    async def update(self, claim_id: str, claim_update: ClaimUpdate) -> Optional[Claim]:
        claim = await self.get_by_id(claim_id)
        if not claim:
            return None
        
        update_data = claim_update.model_dump(exclude_unset=True)
        for key, value in update_data.items():
            setattr(claim, key, value)
            
        await self.session.commit()
        await self.session.refresh(claim)
        return claim

    async def delete(self, claim_id: str) -> bool:
        claim = await self.get_by_id(claim_id)
        if not claim:
            return False
        await self.session.delete(claim)
        await self.session.commit()
        return True

    async def get_dashboard_stats(self) -> DashboardStats:
        total_claims_query = select(func.count(Claim.id))
        total_claims = (await self.session.execute(total_claims_query)).scalar() or 0

        awaiting_query = select(func.count(Claim.id)).where(Claim.status.in_(["draft", "documents_uploaded", "analyzed", "in_review"]))
        awaiting_review = (await self.session.execute(awaiting_query)).scalar() or 0

        completed_query = select(func.count(Claim.id)).where(Claim.status.in_(["appeal_generated", "completed"]))
        completed_reviews = (await self.session.execute(completed_query)).scalar() or 0

        disputed_query = select(func.sum(Claim.claim_amount))
        total_disputed = (await self.session.execute(disputed_query)).scalar() or 0.0

        # Claims with missing evidence findings
        missing_query = select(func.count(func.distinct(Finding.claim_id))).where(Finding.category == "missing_evidence")
        missing_evidence_count = (await self.session.execute(missing_query)).scalar() or 0

        # Average readiness score across latest runs
        avg_score_query = select(func.avg(AnalysisRun.readiness_score))
        avg_score = (await self.session.execute(avg_score_query)).scalar() or 0.0

        return DashboardStats(
            total_claims=total_claims,
            awaiting_review=awaiting_review,
            missing_evidence=missing_evidence_count,
            completed_reviews=completed_reviews,
            total_disputed_amount=float(total_disputed),
            avg_readiness_score=round(float(avg_score), 1)
        )
