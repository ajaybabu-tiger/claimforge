import json
from typing import Optional, List
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update, delete, desc
from app.models.models import Finding
from app.schemas.finding import FindingCreate, FindingUpdate

class FindingRepository:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def get_by_id(self, finding_id: str) -> Optional[Finding]:
        query = select(Finding).where(Finding.id == finding_id)
        result = await self.session.execute(query)
        return result.scalar_one_or_none()

    async def get_by_claim_id(self, claim_id: str) -> List[Finding]:
        query = select(Finding).where(Finding.claim_id == claim_id).order_by(Finding.created_at)
        result = await self.session.execute(query)
        return list(result.scalars().all())

    async def create(self, finding_in: FindingCreate) -> Finding:
        finding = Finding(
            claim_id=finding_in.claim_id,
            category=finding_in.category,
            severity=finding_in.severity,
            title=finding_in.title,
            explanation=finding_in.explanation,
            supporting_document_ids=json.dumps(finding_in.supporting_document_ids or []),
            evidence_reference=finding_in.evidence_reference,
            confidence=finding_in.confidence if finding_in.confidence is not None else 1.0,
            reviewer_status=finding_in.reviewer_status or "unreviewed",
            reviewer_comment=finding_in.reviewer_comment
        )
        self.session.add(finding)
        await self.session.commit()
        await self.session.refresh(finding)
        return finding

    async def create_many(self, findings: List[FindingCreate]) -> List[Finding]:
        db_findings = []
        for f in findings:
            finding = Finding(
                claim_id=f.claim_id,
                category=f.category,
                severity=f.severity,
                title=f.title,
                explanation=f.explanation,
                supporting_document_ids=json.dumps(f.supporting_document_ids or []),
                evidence_reference=f.evidence_reference,
                confidence=f.confidence if f.confidence is not None else 1.0,
                reviewer_status=f.reviewer_status or "unreviewed",
                reviewer_comment=f.reviewer_comment
            )
            self.session.add(finding)
            db_findings.append(finding)
        await self.session.commit()
        for f in db_findings:
            await self.session.refresh(f)
        return db_findings

    async def delete_by_claim_id(self, claim_id: str) -> int:
        query = delete(Finding).where(Finding.claim_id == claim_id)
        result = await self.session.execute(query)
        await self.session.commit()
        return result.rowcount

    async def update(self, finding_id: str, finding_update: FindingUpdate) -> Optional[Finding]:
        finding = await self.get_by_id(finding_id)
        if not finding:
            return None
        
        update_data = finding_update.model_dump(exclude_unset=True)
        for key, value in update_data.items():
            setattr(finding, key, value)
            
        await self.session.commit()
        await self.session.refresh(finding)
        return finding
