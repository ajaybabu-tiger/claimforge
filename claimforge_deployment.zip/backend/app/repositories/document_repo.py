import json
from typing import Optional, List, Dict, Any
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update, delete, desc
from app.models.models import Document

class DocumentRepository:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def get_by_id(self, document_id: str) -> Optional[Document]:
        query = select(Document).where(Document.id == document_id)
        result = await self.session.execute(query)
        return result.scalar_one_or_none()

    async def get_by_claim_id(self, claim_id: str) -> List[Document]:
        query = select(Document).where(Document.claim_id == claim_id).order_by(Document.created_at)
        result = await self.session.execute(query)
        return list(result.scalars().all())

    async def create(
        self,
        claim_id: str,
        original_filename: str,
        document_type: str,
        storage_path: str,
        mime_type: str,
        file_size: int,
        page_count: int = 1,
        processing_status: str = "pending"
    ) -> Document:
        doc = Document(
            claim_id=claim_id,
            original_filename=original_filename,
            document_type=document_type,
            storage_path=storage_path,
            mime_type=mime_type,
            file_size=file_size,
            page_count=page_count,
            processing_status=processing_status
        )
        self.session.add(doc)
        await self.session.commit()
        await self.session.refresh(doc)
        return doc

    async def update_extraction(
        self,
        document_id: str,
        extracted_text: str,
        extracted_metadata: Dict[str, Any],
        page_count: int = 1,
        processing_status: str = "processed",
        error_message: Optional[str] = None
    ) -> Optional[Document]:
        doc = await self.get_by_id(document_id)
        if not doc:
            return None
        doc.extracted_text = extracted_text
        doc.extracted_metadata = json.dumps(extracted_metadata) if extracted_metadata else None
        doc.page_count = page_count
        doc.processing_status = processing_status
        doc.error_message = error_message
        await self.session.commit()
        await self.session.refresh(doc)
        return doc

    async def delete(self, document_id: str) -> bool:
        doc = await self.get_by_id(document_id)
        if not doc:
            return False
        await self.session.delete(doc)
        await self.session.commit()
        return True
