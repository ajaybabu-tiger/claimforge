import re
import os
import json
import fitz # PyMuPDF
from typing import Dict, Any, List, Tuple
from pathlib import Path
from PIL import Image

class DocumentExtractor:
    @staticmethod
    def extract_from_file(file_path: str, mime_type: str) -> Tuple[str, Dict[str, Any], int]:
        """
        Extracts raw text, structured entities, page count, and document metadata from PDF or images.
        """
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")

        if mime_type == "application/pdf" or file_path.lower().endswith(".pdf"):
            return DocumentExtractor._extract_pdf(file_path)
        elif mime_type.startswith("image/") or any(file_path.lower().endswith(ext) for ext in [".png", ".jpg", ".jpeg", ".webp"]):
            return DocumentExtractor._extract_image(file_path)
        else:
            # Fallback text reading
            try:
                with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                    text = f.read()
                entities = DocumentExtractor._extract_entities(text)
                return text, entities, 1
            except Exception as e:
                return "", {"error": str(e)}, 1

    @staticmethod
    def _extract_pdf(file_path: str) -> Tuple[str, Dict[str, Any], int]:
        text_parts = []
        doc_metadata = {}
        font_names = set()
        page_count = 0
        integrity_flags = []

        try:
            doc = fitz.open(file_path)
            page_count = len(doc)
            doc_metadata = doc.metadata or {}

            # Check PDF metadata integrity
            mod_date = doc_metadata.get("modDate", "")
            creation_date = doc_metadata.get("creationDate", "")
            producer = doc_metadata.get("producer", "")

            for page_num in range(page_count):
                page = doc[page_num]
                page_text = page.get_text("text")
                text_parts.append(page_text)

                # Extract fonts for integrity heuristics
                try:
                    font_list = page.get_fonts()
                    for f in font_list:
                        if len(f) > 3:
                            font_names.add(f[3])
                except Exception:
                    pass

            doc.close()
        except Exception as e:
            # Fallback if fitz fails
            return "", {"error": f"PDF extraction failed: {str(e)}", "integrity_flags": ["Corrupted or unreadable PDF"]}, 1

        full_text = "\n\n--- Page Break ---\n\n".join(text_parts).strip()
        entities = DocumentExtractor._extract_entities(full_text)

        # Integrity checks on PDF
        if len(font_names) > 8:
            integrity_flags.append(f"Unusually high font diversity ({len(font_names)} fonts detected), possible document composition/overlay.")
        
        entities["pdf_metadata"] = {
            "producer": producer,
            "creation_date": creation_date,
            "mod_date": mod_date,
            "font_count": len(font_names)
        }
        entities["integrity_flags"].extend(integrity_flags)

        return full_text, entities, max(page_count, 1)

    @staticmethod
    def _extract_image(file_path: str) -> Tuple[str, Dict[str, Any], int]:
        integrity_flags = []
        metadata = {}
        try:
            with Image.open(file_path) as img:
                width, height = img.size
                format_name = img.format
                metadata = {
                    "dimensions": f"{width}x{height}",
                    "format": format_name,
                    "mode": img.mode
                }
                # Check aspect ratio or strange resolution
                if width < 300 or height < 300:
                    integrity_flags.append("Very low image resolution; fine text or signatures may be degraded.")
        except Exception as e:
            metadata["error"] = str(e)

        # Heuristic placeholder text if OCR engine is unavailable
        text = f"[Image Document: {Path(file_path).name} | Size: {metadata.get('dimensions', 'unknown')}]"
        entities = DocumentExtractor._extract_entities(text)
        entities["image_metadata"] = metadata
        entities["integrity_flags"].extend(integrity_flags)

        return text, entities, 1

    @staticmethod
    def _extract_entities(text: str) -> Dict[str, Any]:
        """
        Regex and heuristic entity extraction for medical and insurance documents.
        """
        entities: Dict[str, Any] = {
            "dates": [],
            "amounts": [],
            "total_amount": None,
            "patient_names": [],
            "provider_names": [],
            "diagnosis_codes": [],
            "procedure_codes": [],
            "pre_auth_numbers": [],
            "policy_numbers": [],
            "denial_codes": [],
            "document_type_inferred": "other",
            "integrity_flags": []
        }

        if not text:
            return entities

        # 1. Dates: YYYY-MM-DD, MM/DD/YYYY, DD-MM-YYYY, Month DD, YYYY
        date_patterns = [
            r'\b(?:19|20)\d{2}[-/](?:0[1-9]|1[0-2])[-/](?:0[1-9]|[12]\d|3[01])\b',
            r'\b(?:0[1-9]|1[0-2])[-/](?:0[1-9]|[12]\d|3[01])[-/](?:19|20)\d{2}\b',
            r'\b(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\s+\d{1,2},?\s+(?:19|20)\d{2}\b'
        ]
        found_dates = set()
        for pat in date_patterns:
            matches = re.findall(pat, text, re.IGNORECASE)
            for m in matches:
                found_dates.add(m)
        entities["dates"] = sorted(list(found_dates))

        # 2. Amounts: $X,XXX.XX or USD X,XXX.XX
        amount_pattern = r'(?:\$|USD\s*)\s*([0-9]{1,3}(?:,[0-9]{3})*(?:\.[0-9]{2})?)'
        found_amounts = []
        for m in re.findall(amount_pattern, text, re.IGNORECASE):
            try:
                val = float(m.replace(",", ""))
                if 0.5 <= val <= 1000000.0:
                    found_amounts.append(val)
            except ValueError:
                pass
        entities["amounts"] = sorted(list(set(found_amounts)))
        if found_amounts:
            entities["total_amount"] = max(found_amounts)

        # Check stated total vs line items or explicit discrepancy notes
        stated_total_match = re.search(r'(?:Total Charges Billed|Total Charges|Total Billed|Total Due|Balance Due|Modified Stated Total|Stated Total|Invoice Total)[\s:#\-_]+(?:\$|USD\s*)?([0-9]{1,3}(?:,[0-9]{3})*(?:\.[0-9]{2})?)', text, re.I)
        line_sum_match = re.search(r'(?:Sum of line items|Calculated Line Items Total|Subtotal)[\s:#\-_]+(?:\$|USD\s*)?([0-9]{1,3}(?:,[0-9]{3})*(?:\.[0-9]{2})?)', text, re.I)
        if stated_total_match and line_sum_match:
            try:
                st = float(stated_total_match.group(1).replace(",", ""))
                ls = float(line_sum_match.group(1).replace(",", ""))
                diff = abs(st - ls)
                if diff > 1.0:
                    entities["integrity_flags"].append(f"Arithmetic Discrepancy: Sum of itemized line charges (${ls:,.2f}) does not match stated invoice total (${st:,.2f}) (Discrepancy: ${diff:,.2f}).")
                    entities["arithmetic_validation"] = {"line_sum": ls, "stated_total": st, "discrepancy": diff}
            except Exception:
                pass
        elif "Discrepancy $" in text:
            disc_m = re.search(r'Discrepancy\s+\$([0-9]{1,3}(?:,[0-9]{3})*(?:\.[0-9]{2})?)', text, re.I)
            if disc_m:
                entities["integrity_flags"].append(f"Arithmetic Discrepancy detected in document: ${disc_m.group(1)}")

        # 3. ICD-10 Diagnosis Codes: e.g. M54.5, I10, E11.9, K21.0, S82.101A, R07.9
        icd_pattern = r'\b([A-TV-Z][0-9][0-9A-Z](?:\.[0-9A-Z]{1,4})?)\b'
        possible_icds = set()
        for m in re.findall(icd_pattern, text):
            # Filter out false positives
            if not re.match(r'^(?:AM|PM|BOX|PAGE|FAX|TEL|REF|VOL|SEC|JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC)\b', m, re.I):
                if any(char.isdigit() for char in m):
                    possible_icds.add(m)
        entities["diagnosis_codes"] = sorted(list(possible_icds))[:10]

        # 4. Procedure / CPT Codes: 5-digit numbers like 99213, 99214, 99285, 74177, 43239
        cpt_pattern = r'\b(99[2-4][0-9]{2}|[1-6][0-9]{4}|7[0-9]{4}|8[0-9]{4}|0[0-9]{4}T)\b'
        cpt_matches = set(re.findall(cpt_pattern, text))
        entities["procedure_codes"] = sorted(list(cpt_matches))[:10]

        # 5. Pre-auth numbers: AUTH-12345, PA# 88912, Pre-Auth: PA-9921
        pre_auth_pattern = r'(?:AUTH|PA|PRE-?AUTH|AUTHORIZATION)[\s:#\-_]+([A-Z0-9\-_]{5,20})'
        pre_auth_matches = set(re.findall(pre_auth_pattern, text, re.IGNORECASE))
        entities["pre_auth_numbers"] = sorted(list(pre_auth_matches))

        # 6. Policy numbers: POL-12345, Member ID: W12345678, Policy #: ...
        policy_pattern = r'(?:POLICY|MEMBER\s+ID|GROUP\s+NO|POLICY\s+#)[\s:#\-_]+([A-Z0-9\-_]{5,25})'
        policy_matches = set(re.findall(policy_pattern, text, re.IGNORECASE))
        entities["policy_numbers"] = sorted(list(policy_matches))

        # 7. Denial codes: CO-16, CO-197, PR-204, N56, EX-44
        denial_pattern = r'\b(CO-\d{1,3}|PR-\d{1,3}|OA-\d{1,3}|PI-\d{1,3}|N-?\d{2,4}|EX-\d{2,4})\b'
        denial_matches = set(re.findall(denial_pattern, text, re.IGNORECASE))
        entities["denial_codes"] = sorted(list(denial_matches))

        # 8. Patient Name heuristic
        patient_patterns = [
            r'(?:Patient\s+Name|Patient|Member\s+Name|Name of Patient)[\s:#\-_]+([A-Z][a-z]+(?:\s+[A-Z][a-z]+){1,3})',
            r'(?:Patient|Insured)[\s:#\-_]+([A-Z\s]{4,30})(?:\r|\n|$)'
        ]
        patient_names = set()
        for pat in patient_patterns:
            matches = re.findall(pat, text, re.IGNORECASE)
            for m in matches:
                cleaned = m.strip()
                if len(cleaned) > 2 and not any(kw in cleaned.lower() for kw in ["information", "signature", "billing", "hospital", "clinic", "address"]):
                    patient_names.add(cleaned)
        entities["patient_names"] = list(patient_names)[:3]

        # 9. Provider / Hospital heuristic
        provider_patterns = [
            r'([A-Z][A-Za-z\s&,\.]{3,40}(?:Hospital|Medical Center|Health|Clinic|Physicians|Emergency Group|Healthcare|Laboratories|Pathology|Surgery Center))',
            r'(?:Provider|Physician|Doctor|Attending(?:\s+Surgeon|\s+Physician)?|Surgeon)[\s:#\-_]+(Dr\.\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+){1,2})'
        ]
        providers = set()
        for pat in provider_patterns:
            matches = re.findall(pat, text, re.IGNORECASE)
            for m in matches:
                cleaned = m.strip()
                if 4 < len(cleaned) < 50:
                    providers.add(cleaned)
        entities["provider_names"] = list(providers)[:4]

        # 10. Infer document type
        lower_text = text.lower()
        if any(kw in lower_text for kw in ["denial", "rejection", "explanation of benefits", "eob", "adverse determination", "claim denied", "we cannot pay"]):
            entities["document_type_inferred"] = "denial_letter"
        elif any(kw in lower_text for kw in ["itemized bill", "hospital invoice", "total charges", "billing statement", "statement of account"]):
            entities["document_type_inferred"] = "medical_bill"
        elif any(kw in lower_text for kw in ["discharge summary", "discharge note", "history of present illness", "admission date", "hospital course"]):
            entities["document_type_inferred"] = "discharge_summary"
        elif any(kw in lower_text for kw in ["rx", "prescription", "sig:", "refills", "prescribing physician", "dispense as written"]):
            entities["document_type_inferred"] = "prescription"
        elif any(kw in lower_text for kw in ["diagnostic report", "mri report", "ct scan", "radiology report", "pathology report", "lab results"]):
            entities["document_type_inferred"] = "diagnostic_report"
        elif any(kw in lower_text for kw in ["prior authorization", "pre-authorization", "authorization approval", "auth request"]):
            entities["document_type_inferred"] = "pre_auth"

        return entities
