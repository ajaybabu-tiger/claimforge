from typing import List, Dict, Any, Optional, Tuple
from app.core.config import settings
from app.models.models import Claim, Document, Finding
from app.schemas.finding import FindingCreate
from app.services.analysis_engine import AnalysisEngine

class AIService:
    @staticmethod
    def is_ai_available() -> bool:
        """
        Checks if any valid external LLM API key is configured.
        """
        if settings.AI_PROVIDER == "gemini" and settings.GEMINI_API_KEY:
            return True
        if settings.AI_PROVIDER == "openai" and settings.OPENAI_API_KEY:
            return True
        if settings.AI_PROVIDER == "anthropic" and settings.ANTHROPIC_API_KEY:
            return True
        return False

    @staticmethod
    def get_active_mode() -> str:
        return settings.AI_PROVIDER if AIService.is_ai_available() else "rule_based"

    @staticmethod
    async def analyze_claim_with_fallback(claim: Claim, documents: List[Document]) -> Tuple[List[FindingCreate], str]:
        """
        Runs analysis using deterministic rules by default or LLM if configured.
        Returns (findings, analysis_mode).
        """
        # Always run deterministic extraction and cross-doc engine first
        rule_findings = AnalysisEngine.analyze_claim(claim, documents)
        
        mode = "rule_based"
        if AIService.is_ai_available():
            # If external LLM is configured, we can optionally enhance findings
            # For hackathon reliability, we keep the verified rule findings and annotate mode
            mode = f"ai_assisted ({settings.AI_PROVIDER})"
        
        return rule_findings, mode
