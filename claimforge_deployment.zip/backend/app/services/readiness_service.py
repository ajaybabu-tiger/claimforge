from datetime import datetime, timezone
from typing import List, Dict, Any
from app.models.models import Claim, Document, Finding
from app.schemas.readiness import ReadinessScoreResponse, ScoreComponent

class ReadinessService:
    @staticmethod
    def calculate_score(claim: Claim, documents: List[Document], findings: List[Finding]) -> ReadinessScoreResponse:
        """
        Calculates an explainable, transparent Appeal Readiness score (0-100)
        based on evidence completeness, cross-document consistency, rebuttal strength, and document integrity.
        """
        # 1. Component 1: Evidence Completeness (Weight: 30%)
        doc_types = {d.document_type for d in documents}
        completeness_score = 100.0
        completeness_penalties = []
        positive_factors = []
        negative_factors = []
        improvements = []

        has_bill = "medical_bill" in doc_types or any("bill" in (d.extracted_text or "").lower() for d in documents)
        has_clinical = any(t in doc_types for t in ["discharge_summary", "diagnostic_report", "prescription"]) or any("clinical" in (d.extracted_text or "").lower() for d in documents)
        has_denial = "denial_letter" in doc_types or any("denial" in (d.extracted_text or "").lower() for d in documents)

        if not has_bill:
            completeness_score -= 40.0
            completeness_penalties.append("Missing itemized bill (-40 pts)")
            negative_factors.append("No itemized billing ledger attached.")
            improvements.append("Upload itemized hospital bill (UB-04 / HCFA-1500).")
        else:
            positive_factors.append("Itemized billing documentation attached.")

        if not has_clinical:
            completeness_score -= 30.0
            completeness_penalties.append("Missing clinical documentation (-30 pts)")
            negative_factors.append("No clinical discharge or diagnostic reports attached.")
            improvements.append("Attach physician progress notes or diagnostic imaging results.")
        else:
            positive_factors.append("Clinical treatment notes available for substantiation.")

        if not has_denial:
            completeness_score -= 20.0
            completeness_penalties.append("Missing formal denial notice (-20 pts)")
            negative_factors.append("Formal insurer denial letter missing.")
            improvements.append("Upload insurer's formal denial notice / EOB.")
        else:
            positive_factors.append("Official denial determination letter on file.")

        completeness_score = max(0.0, min(100.0, completeness_score))

        # 2. Component 2: Cross-Document Consistency (Weight: 25%)
        consistency_score = 100.0
        consistency_penalties = []
        inconsistency_findings = [f for f in findings if f.category == "cross_document_inconsistency" and f.reviewer_status != "dismissed"]

        for f in inconsistency_findings:
            if f.severity == "critical":
                consistency_score -= 40.0
                consistency_penalties.append(f"{f.title} (-40 pts)")
                negative_factors.append(f"Critical discrepancy: {f.title}")
            elif f.severity == "high":
                consistency_score -= 25.0
                consistency_penalties.append(f"{f.title} (-25 pts)")
                negative_factors.append(f"Major discrepancy: {f.title}")
            elif f.severity == "medium":
                consistency_score -= 15.0
                consistency_penalties.append(f"{f.title} (-15 pts)")
                negative_factors.append(f"Discrepancy: {f.title}")

        if not inconsistency_findings:
            positive_factors.append("Dates, patient identifiers, and billed amounts are consistent across files.")
        consistency_score = max(0.0, min(100.0, consistency_score))

        # 3. Component 3: Rejection Rebuttal Strength (Weight: 25%)
        rebuttal_score = 80.0 # Base moderate
        rejection_findings = [f for f in findings if f.category == "rejection_analysis"]
        missing_critical = any(f.category == "missing_evidence" and f.severity in ["critical", "high"] for f in findings if f.reviewer_status != "dismissed")

        if missing_critical:
            rebuttal_score -= 30.0
            negative_factors.append("Key documentation needed to refute the insurer's rejection is still missing.")
            improvements.append("Obtain physician clinical attestation directly countering rejection reason.")
        else:
            rebuttal_score += 15.0
            positive_factors.append("Documented evidence directly addresses the insurer's stated denial basis.")

        # Check if medical necessity codes exist
        has_icd = any("ICD-10" in f.title for f in findings)
        if has_icd:
            rebuttal_score += 5.0
            positive_factors.append("Standardized ICD-10 diagnostic codes identified.")

        rebuttal_score = max(0.0, min(100.0, rebuttal_score))

        # 4. Component 4: Document Integrity (Weight: 20%)
        integrity_score = 100.0
        integrity_findings = [f for f in findings if f.category == "document_integrity" and f.reviewer_status != "dismissed"]
        for f in integrity_findings:
            if f.severity == "high":
                integrity_score -= 35.0
                negative_factors.append(f"Integrity alert: {f.title}")
            elif f.severity == "medium":
                integrity_score -= 15.0
            elif f.severity == "low":
                integrity_score -= 5.0

        if not integrity_findings:
            positive_factors.append("All document metadata and structures passed integrity checks.")
        integrity_score = max(0.0, min(100.0, integrity_score))

        # Overall Weighted Score (0-100)
        overall_score = (
            (completeness_score * 0.30) +
            (consistency_score * 0.25) +
            (rebuttal_score * 0.25) +
            (integrity_score * 0.20)
        )
        overall_score = round(max(0.0, min(100.0, overall_score)), 1)

        # Readiness Level
        if overall_score >= 80.0:
            level = "High Readiness"
            summary = "Case documentation is comprehensive and strongly aligned to refute the denial reason. Ready for appeal packet generation."
        elif overall_score >= 60.0:
            level = "Moderate Readiness"
            summary = "Core evidence is present, but minor document inconsistencies or missing attachments should be reviewed before filing."
        elif overall_score >= 40.0:
            level = "Low Readiness"
            summary = "Significant gaps in clinical documentation or billing ledgers. Additional supporting records strongly recommended."
        else:
            level = "Critical Deficiencies"
            summary = "Major required documents are missing or severe data discrepancies exist. Proceeding without rectifying will likely cause appeal rejection."

        components = [
            ScoreComponent(
                name="Evidence Completeness",
                weight=30.0,
                score=round(completeness_score, 1),
                status="good" if completeness_score >= 80 else ("warning" if completeness_score >= 50 else "critical"),
                details=f"Evaluates presence of itemized bills, clinical reports, and formal denial letters ({round(completeness_score)}/100).",
                impact=f"{'+' if completeness_score >= 80 else ''}{round(completeness_score * 0.30, 1)} pts"
            ),
            ScoreComponent(
                name="Cross-Document Consistency",
                weight=25.0,
                score=round(consistency_score, 1),
                status="good" if consistency_score >= 80 else ("warning" if consistency_score >= 50 else "critical"),
                details=f"Checks consistency of dates of service, patient IDs, provider names, and dollar amounts ({round(consistency_score)}/100).",
                impact=f"{'+' if consistency_score >= 80 else ''}{round(consistency_score * 0.25, 1)} pts"
            ),
            ScoreComponent(
                name="Rejection Rebuttal Strength",
                weight=25.0,
                score=round(rebuttal_score, 1),
                status="good" if rebuttal_score >= 80 else ("warning" if rebuttal_score >= 50 else "critical"),
                details=f"Assesses whether uploaded records provide concrete justification against the specific denial code ({round(rebuttal_score)}/100).",
                impact=f"{'+' if rebuttal_score >= 80 else ''}{round(rebuttal_score * 0.25, 1)} pts"
            ),
            ScoreComponent(
                name="Document Integrity",
                weight=20.0,
                score=round(integrity_score, 1),
                status="good" if integrity_score >= 80 else ("warning" if integrity_score >= 50 else "critical"),
                details=f"Scans for metadata anomalies, font discrepancies, or unverified alteration artifacts ({round(integrity_score)}/100).",
                impact=f"{'+' if integrity_score >= 80 else ''}{round(integrity_score * 0.20, 1)} pts"
            )
        ]

        if not improvements:
            improvements.append("Proceed to generate appeal letter draft and conduct reviewer sign-off.")

        return ReadinessScoreResponse(
            claim_id=claim.id,
            readiness_score=overall_score,
            readiness_level=level,
            analysis_mode="rule_based",
            summary=summary,
            components=components,
            positive_factors=positive_factors,
            negative_factors=negative_factors,
            recommended_improvements=improvements,
            calculated_at=datetime.now(timezone.utc)
        )
