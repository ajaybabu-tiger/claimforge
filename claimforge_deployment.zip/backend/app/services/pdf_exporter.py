import io
import re
import html
from datetime import datetime, timezone
from typing import Optional, Dict, Any
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.lib.units import inch
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable, KeepTogether
)
from reportlab.pdfgen import canvas
from app.models.models import Claim, Appeal

class NumberedCanvas(canvas.Canvas):
    """
    Two-pass canvas to dynamically compute and draw exact total page counts
    and professional running headers/footers on every page.
    """
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._saved_page_states = []
        self._claim_ref = getattr(NumberedCanvas, "current_claim_ref", "CLAIMFORGE")

    def showPage(self):
        self._saved_page_states.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        num_pages = len(self._saved_page_states)
        for state in self._saved_page_states:
            self.__dict__.update(state)
            self.draw_header_footer(num_pages)
            super().showPage()
        super().save()

    def draw_header_footer(self, page_count: int):
        self.saveState()
        self.setFont("Helvetica", 8)
        self.setFillColor(colors.HexColor("#64748b"))

        # Running header on page 2+
        if self._pageNumber > 1:
            self.drawString(0.65 * inch, 10.45 * inch, "CLAIMFORGE • EVIDENCE-BACKED APPEAL PACKET")
            self.drawRightString(7.85 * inch, 10.45 * inch, f"Case Ref: {self._claim_ref}")
            self.setStrokeColor(colors.HexColor("#cbd5e1"))
            self.setLineWidth(0.6)
            self.line(0.65 * inch, 10.38 * inch, 7.85 * inch, 10.38 * inch)

        # Running footer on every page
        self.setStrokeColor(colors.HexColor("#e2e8f0"))
        self.setLineWidth(0.6)
        self.line(0.65 * inch, 0.48 * inch, 7.85 * inch, 0.48 * inch)

        footer_text = f"CONFIDENTIAL HEALTHCARE RECORD  •  ClaimForge Decision-Support Engine  •  Page {self._pageNumber} of {page_count}"
        self.drawCentredString(4.25 * inch, 0.35 * inch, footer_text)
        self.restoreState()


class PDFExporter:
    @staticmethod
    def _format_markdown_for_reportlab(text: str) -> str:
        """
        Safely converts markdown bold, italics, code, and bullet symbols to ReportLab XML format.
        Guarantees that ANY &, <, > in raw text is escaped first so ReportLab XML never crashes.
        """
        if not text:
            return ""

        # Step 1: Escape all raw XML entities first
        escaped = html.escape(text.strip())

        # Step 2: Convert markdown bold **text** to <b>text</b>
        escaped = re.sub(r'\*\*(.+?)\*\*', r'<b>\1</b>', escaped)

        # Step 3: Convert markdown italic *text* to <i>text</i>
        escaped = re.sub(r'(?<!\*)\*([^*]+?)\*(?!\*)', r'<i>\1</i>', escaped)

        # Step 4: Convert markdown inline code `code` to Courier font
        escaped = re.sub(r'`(.+?)`', r"<font name='Courier' color='#0f766e'><b>\1</b></font>", escaped)

        return escaped

    @staticmethod
    def export_appeal_pdf(claim: Claim, appeal: Appeal) -> bytes:
        """
        Exports an appeal letter to a polished, professional, audit-ready PDF document.
        Uses real persisted claim fields, reviewer determinations, and verified citations.
        """
        # Set current claim reference for canvas header
        NumberedCanvas.current_claim_ref = claim.claim_reference

        buffer = io.BytesIO()
        doc = SimpleDocTemplate(
            buffer,
            pagesize=letter,
            rightMargin=0.65 * inch,
            leftMargin=0.65 * inch,
            topMargin=0.65 * inch,
            bottomMargin=0.65 * inch
        )

        styles = getSampleStyleSheet()

        # Harmonious color palette (Deep Teal, Emerald, Slate, Indigo)
        primary_teal = colors.HexColor("#0f766e")
        dark_slate = colors.HexColor("#1e293b")
        light_gray = colors.HexColor("#f8fafc")
        border_gray = colors.HexColor("#cbd5e1")
        muted_slate = colors.HexColor("#64748b")
        denial_red = colors.HexColor("#b91c1c")
        approved_green = colors.HexColor("#047857")

        # Custom typography styles
        title_style = ParagraphStyle(
            'ClaimForgeTitle',
            parent=styles['Heading1'],
            fontSize=15,
            leading=18,
            textColor=primary_teal,
            spaceAfter=3,
            fontName="Helvetica-Bold"
        )

        subtitle_style = ParagraphStyle(
            'ClaimForgeSubtitle',
            parent=styles['Normal'],
            fontSize=8.5,
            leading=11,
            textColor=muted_slate,
            fontName="Helvetica-Bold",
            spaceAfter=2
        )

        section_heading = ParagraphStyle(
            'ClaimForgeSection',
            parent=styles['Heading2'],
            fontSize=10.5,
            leading=14,
            textColor=primary_teal,
            spaceBefore=8,
            spaceAfter=4,
            fontName="Helvetica-Bold"
        )

        body_style = ParagraphStyle(
            'ClaimForgeBody',
            parent=styles['Normal'],
            fontSize=8.5,
            leading=12,
            textColor=dark_slate,
            spaceAfter=4,
            fontName="Helvetica"
        )

        bullet_style = ParagraphStyle(
            'ClaimForgeBullet',
            parent=body_style,
            leftIndent=12,
            firstLineIndent=-10,
            spaceAfter=3
        )

        meta_label = ParagraphStyle(
            'ClaimForgeMetaLabel',
            parent=styles['Normal'],
            fontSize=8,
            leading=10,
            textColor=muted_slate,
            fontName="Helvetica-Bold"
        )

        meta_val = ParagraphStyle(
            'ClaimForgeMetaVal',
            parent=styles['Normal'],
            fontSize=8,
            leading=10,
            textColor=dark_slate,
            fontName="Helvetica"
        )

        elements = []

        # 1. Header Banner
        elements.append(Paragraph("CLAIMFORGE &bull; AI-ASSISTED CLAIM APPEAL & VERIFICATION PLATFORM", subtitle_style))
        elements.append(Paragraph(html.escape(appeal.appeal_title or f"Formal Appeal for Claim {claim.claim_reference}"), title_style))
        elements.append(HRFlowable(width="100%", thickness=1.5, color=primary_teal, spaceBefore=3, spaceAfter=8))

        # 2. Persisted Case Metadata Table (2-column layout)
        dos_text = claim.date_of_service or "Pending Confirmation"
        pol_text = claim.policy_number or "N/A"
        code_text = claim.rejection_code or "Notice"

        meta_data = [
            [
                Paragraph("<b>Claim Reference:</b>", meta_label),
                Paragraph(f"<font color='#0f766e'><b>{html.escape(claim.claim_reference)}</b></font>", meta_val),
                Paragraph("<b>Date of Service:</b>", meta_label),
                Paragraph(html.escape(dos_text), meta_val),
            ],
            [
                Paragraph("<b>Patient / Member ID:</b>", meta_label),
                Paragraph(html.escape(claim.patient_reference), meta_val),
                Paragraph("<b>Total Disputed Amount:</b>", meta_label),
                Paragraph(f"<font color='#047857'><b>${claim.claim_amount:,.2f} USD</b></font>", meta_val),
            ],
            [
                Paragraph("<b>Insurance Provider:</b>", meta_label),
                Paragraph(html.escape(claim.insurer_name), meta_val),
                Paragraph("<b>Policy / Group #:</b>", meta_label),
                Paragraph(html.escape(pol_text), meta_val),
            ],
            [
                Paragraph("<b>Stated Denial Reason:</b>", meta_label),
                Paragraph(f"<font color='#b91c1c'><b>{html.escape(claim.rejection_reason)}</b></font>", meta_val),
                Paragraph("<b>Denial Code (CARC):</b>", meta_label),
                Paragraph(f"<font color='#b91c1c'><b>{html.escape(code_text)}</b></font>", meta_val),
            ],
        ]

        meta_table = Table(meta_data, colWidths=[1.35 * inch, 2.25 * inch, 1.35 * inch, 2.25 * inch])
        meta_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, -1), light_gray),
            ('BOX', (0, 0), (-1, -1), 1, border_gray),
            ('INNERGRID', (0, 0), (-1, -1), 0.5, colors.HexColor("#e2e8f0")),
            ('TOPPADDING', (0, 0), (-1, -1), 3.5),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 3.5),
            ('LEFTPADDING', (0, 0), (-1, -1), 5),
            ('RIGHTPADDING', (0, 0), (-1, -1), 5),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ]))

        elements.append(meta_table)
        elements.append(Spacer(1, 8))

        # 3. Parse Draft Content into Flowables
        draft_text = appeal.draft_content or ""
        lines = draft_text.split("\n")

        for line in lines:
            line_str = line.strip()
            if not line_str:
                elements.append(Spacer(1, 2.5))
                continue

            # Skip redundant raw markdown headers since they are already presented in the styled metadata table
            if (line_str.startswith("# ") or line_str.startswith("---") or
                line_str.startswith("**DATE:**") or line_str.startswith("**TO:**") or
                line_str.startswith("**INSURER:**") or line_str.startswith("**CLAIM REFERENCE") or
                line_str.startswith("**PATIENT") or line_str.startswith("**POLICY") or
                line_str.startswith("**TOTAL DISPUTED") or line_str.startswith("**DENIAL")):
                continue

            # Heading 3
            if line_str.startswith("### "):
                clean_h = PDFExporter._format_markdown_for_reportlab(line_str.replace("### ", ""))
                elements.append(Paragraph(clean_h, section_heading))
            # Heading 2
            elif line_str.startswith("## "):
                clean_h = PDFExporter._format_markdown_for_reportlab(line_str.replace("## ", ""))
                elements.append(Paragraph(clean_h, section_heading))
            # Bullets
            elif line_str.startswith("- ") or line_str.startswith("* "):
                bullet_content = line_str[2:]
                formatted_bullet = PDFExporter._format_markdown_for_reportlab(bullet_content)
                elements.append(Paragraph(f"&bull; {formatted_bullet}", bullet_style))
            # Numbered items
            elif re.match(r'^\d+\.\s', line_str):
                formatted_num = PDFExporter._format_markdown_for_reportlab(line_str)
                elements.append(Paragraph(formatted_num, bullet_style))
            # Regular paragraphs
            else:
                formatted_line = PDFExporter._format_markdown_for_reportlab(line_str)
                elements.append(Paragraph(formatted_line, body_style))

        # 4. Official Reviewer Determination & Audit Block
        elements.append(Spacer(1, 10))

        status_str = (appeal.approval_status or "draft").upper()
        if status_str == "APPROVED":
            status_color = "#047857"
            status_bg = "#ecfdf5"
            status_desc = "OFFICIALLY APPROVED FOR SUBMISSION"
        elif status_str == "REJECTED":
            status_color = "#b91c1c"
            status_bg = "#fef2f2"
            status_desc = "REJECTED / RETURNED FOR CORRECTIONS"
        else:
            status_color = "#b45309"
            status_bg = "#fffbeb"
            status_desc = "DRAFT / PENDING REVIEWER SIGN-OFF"

        reviewer_name_str = appeal.approved_by or "Pending Reviewer Signature"
        review_date_str = appeal.approved_at.strftime("%Y-%m-%d %H:%M UTC") if appeal.approved_at else datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
        notes_str = appeal.reviewer_notes or "No internal comments logged."

        audit_data = [
            [
                Paragraph("<b>Determination Status:</b>", meta_label),
                Paragraph(f"<font color='{status_color}'><b>{status_desc}</b></font>", meta_val),
                Paragraph("<b>Audit Timestamp:</b>", meta_label),
                Paragraph(review_date_str, meta_val),
            ],
            [
                Paragraph("<b>Authorized Reviewer:</b>", meta_label),
                Paragraph(f"<b>{html.escape(reviewer_name_str)}</b>", meta_val),
                Paragraph("<b>Signature:</b>", meta_label),
                Paragraph("________________________", meta_val),
            ],
            [
                Paragraph("<b>Reviewer Notes:</b>", meta_label),
                Paragraph(html.escape(notes_str), meta_val),
                Paragraph("<b>System Notice:</b>", meta_label),
                Paragraph("Audited via ClaimForge Engine", meta_val),
            ]
        ]

        audit_table = Table(audit_data, colWidths=[1.4 * inch, 2.2 * inch, 1.3 * inch, 2.3 * inch])
        audit_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor(status_bg)),
            ('BOX', (0, 0), (-1, -1), 1, colors.HexColor(status_color)),
            ('INNERGRID', (0, 0), (-1, -1), 0.5, colors.HexColor("#e2e8f0")),
            ('TOPPADDING', (0, 0), (-1, -1), 3),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 3),
            ('LEFTPADDING', (0, 0), (-1, -1), 5),
            ('RIGHTPADDING', (0, 0), (-1, -1), 5),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ]))

        elements.append(KeepTogether([
            Paragraph("<b>OFFICIAL REVIEWER DETERMINATION & AUDIT VERIFICATION</b>", subtitle_style),
            Spacer(1, 2),
            audit_table
        ]))

        # Build document with NumberedCanvas
        doc.build(elements, canvasmaker=NumberedCanvas)
        buffer.seek(0)
        return buffer.getvalue()
