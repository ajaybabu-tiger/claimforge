import json
import re
from typing import List, Dict, Any, Tuple
from app.models.models import Claim, Document
from app.schemas.finding import FindingCreate

class AnalysisEngine:
    @staticmethod
    def analyze_claim(claim: Claim, documents: List[Document]) -> List[FindingCreate]:
        """
        Executes a deterministic, explainable, rule-based cross-document analysis.
        Returns a list of FindingCreate objects categorized by type.
        """
        findings: List[FindingCreate] = []

        # Parse document metadata
        parsed_docs: List[Dict[str, Any]] = []
        doc_types_present = set()
        all_dates = {}
        all_amounts = {}
        all_patient_names = {}
        all_providers = {}
        all_icd_codes = {}
        all_cpt_codes = {}
        all_pre_auths = {}

        all_policy_numbers = {}

        for doc in documents:
            meta = {}
            if doc.extracted_metadata:
                try:
                    meta = json.loads(doc.extracted_metadata) if isinstance(doc.extracted_metadata, str) else doc.extracted_metadata
                except Exception:
                    meta = {}

            doc_type = doc.document_type if doc.document_type != "other" else meta.get("document_type_inferred", "other")
            doc_types_present.add(doc_type)

            parsed_doc = {
                "id": doc.id,
                "filename": doc.original_filename,
                "type": doc_type,
                "text": doc.extracted_text or "",
                "metadata": meta,
                "entities": meta
            }
            parsed_docs.append(parsed_doc)

            # Aggregate entities
            doc_id = doc.id
            for d in meta.get("dates", []):
                all_dates.setdefault(d, []).append(doc_id)
            for a in meta.get("amounts", []):
                all_amounts.setdefault(a, []).append(doc_id)
            for p in meta.get("patient_names", []):
                all_patient_names.setdefault(p, []).append(doc_id)
            for pr in meta.get("provider_names", []):
                all_providers.setdefault(pr, []).append(doc_id)
            for icd in meta.get("diagnosis_codes", []):
                all_icd_codes.setdefault(icd, []).append(doc_id)
            for cpt in meta.get("procedure_codes", []):
                all_cpt_codes.setdefault(cpt, []).append(doc_id)
            for pa in meta.get("pre_auth_numbers", []):
                all_pre_auths.setdefault(pa, []).append(doc_id)
            for pol in meta.get("policy_numbers", []):
                all_policy_numbers.setdefault(pol, []).append(doc_id)

        # -------------------------------------------------------------
        # 1. EXTRACTED FACTS
        # -------------------------------------------------------------
        # Verified Claim Entities
        if all_icd_codes:
            icd_list_str = ", ".join(list(all_icd_codes.keys())[:5])
            findings.append(FindingCreate(
                claim_id=claim.id,
                category="extracted_fact",
                severity="info",
                title=f"Extracted Diagnosis Codes (ICD-10): {icd_list_str}",
                explanation=f"Identified standardized clinical diagnosis codes across uploaded medical records: {icd_list_str}.",
                supporting_document_ids=list({did for ids in all_icd_codes.values() for did in ids})[:5],
                evidence_reference=f"ICD-10: {icd_list_str}",
                confidence=0.98,
                reviewer_status="unreviewed"
            ))

        if all_cpt_codes:
            cpt_list_str = ", ".join(list(all_cpt_codes.keys())[:5])
            findings.append(FindingCreate(
                claim_id=claim.id,
                category="extracted_fact",
                severity="info",
                title=f"Extracted Procedure Codes (CPT/HCPCS): {cpt_list_str}",
                explanation=f"Identified billed procedural codes corresponding to clinical interventions: {cpt_list_str}.",
                supporting_document_ids=list({did for ids in all_cpt_codes.values() for did in ids})[:5],
                evidence_reference=f"CPT: {cpt_list_str}",
                confidence=0.98,
                reviewer_status="unreviewed"
            ))

        if all_providers:
            provider_list_str = ", ".join(list(all_providers.keys())[:3])
            findings.append(FindingCreate(
                claim_id=claim.id,
                category="extracted_fact",
                severity="info",
                title="Treating Facilities & Providers Identified",
                explanation=f"Documented healthcare providers on file: {provider_list_str}.",
                supporting_document_ids=list({did for ids in all_providers.values() for did in ids})[:3],
                evidence_reference=f"Providers: {provider_list_str}",
                confidence=0.95,
                reviewer_status="unreviewed"
            ))

        if all_dates:
            dates_list_str = ", ".join(list(all_dates.keys())[:4])
            findings.append(FindingCreate(
                claim_id=claim.id,
                category="extracted_fact",
                severity="info",
                title=f"Extracted Dates of Service: {dates_list_str}",
                explanation=f"Documented timeline and dates of care across records: {dates_list_list_str if 'dates_list_list_str' in locals() else dates_list_str}.",
                supporting_document_ids=list({did for ids in all_dates.values() for did in ids})[:4],
                evidence_reference=f"DOS: {dates_list_str}",
                confidence=0.98,
                reviewer_status="unreviewed"
            ))

        if all_patient_names or all_policy_numbers:
            p_names = ", ".join(list(all_patient_names.keys())[:2]) if all_patient_names else claim.patient_reference
            p_pols = ", ".join(list(all_policy_numbers.keys())[:2]) if all_policy_numbers else (claim.policy_number or "N/A")
            findings.append(FindingCreate(
                claim_id=claim.id,
                category="extracted_fact",
                severity="info",
                title="Verified Patient & Policy Identifiers",
                explanation=f"Documented patient identity: '{p_names}' | Policy/Member ID: '{p_pols}'.",
                supporting_document_ids=list({did for ids in (list(all_patient_names.values()) + list(all_policy_numbers.values())) for did in ids})[:3],
                evidence_reference=f"Patient: {p_names} | Member: {p_pols}",
                confidence=0.96,
                reviewer_status="unreviewed"
            ))

        if all_amounts:
            max_amt = max(all_amounts.keys())
            findings.append(FindingCreate(
                claim_id=claim.id,
                category="extracted_fact",
                severity="info",
                title=f"Extracted Total Charges Billed: ${max_amt:,.2f}",
                explanation=f"Identified itemized billing ledger charges up to ${max_amt:,.2f} documented across records.",
                supporting_document_ids=all_amounts.get(max_amt, [])[:2],
                evidence_reference=f"Extracted Total: ${max_amt:,.2f}",
                confidence=0.98,
                reviewer_status="unreviewed"
            ))

        # -------------------------------------------------------------
        # 2. MISSING EVIDENCE DETECTION
        # -------------------------------------------------------------
        has_bill = "medical_bill" in doc_types_present
        has_clinical = any(t in doc_types_present for t in ["discharge_summary", "diagnostic_report", "prescription"])
        has_denial = "denial_letter" in doc_types_present

        if not has_bill:
            findings.append(FindingCreate(
                claim_id=claim.id,
                category="missing_evidence",
                severity="high",
                title="Missing Itemized Medical Bill / UB-04 / HCFA-1500",
                explanation="No itemized medical billing statement was detected. Insurers require line-item breakdowns with revenue codes and unit charges to process appeals.",
                supporting_document_ids=[],
                evidence_reference="Required Documentation Checklist",
                confidence=1.0,
                reviewer_status="unreviewed"
            ))

        if not has_clinical:
            findings.append(FindingCreate(
                claim_id=claim.id,
                category="missing_evidence",
                severity="high",
                title="Missing Clinical Notes or Diagnostic Report",
                explanation="No clinical discharge summary, operative report, or diagnostic imaging findings were attached to substantiate medical necessity.",
                supporting_document_ids=[],
                evidence_reference="Clinical Documentation Checklist",
                confidence=1.0,
                reviewer_status="unreviewed"
            ))

        if not has_denial:
            findings.append(FindingCreate(
                claim_id=claim.id,
                category="missing_evidence",
                severity="medium",
                title="Missing Official Explanation of Benefits (EOB) / Denial Letter",
                explanation="The insurer's formal written denial letter or EOB is not uploaded. Attaching the primary denial letter ensures the appeal cites the exact determination date and appeal address.",
                supporting_document_ids=[],
                evidence_reference="Adverse Benefit Determination Record",
                confidence=0.95,
                reviewer_status="unreviewed"
            ))

        # Check specific rejection reasons for missing supporting records
        rejection_lower = (claim.rejection_reason or "").lower()
        if ("prior auth" in rejection_lower or "pre-authorization" in rejection_lower or "pre-auth" in rejection_lower or claim.rejection_code in ["CO-197", "197"]):
            has_preauth_doc = "pre_auth" in doc_types_present or len(all_pre_auths) > 0
            # Check if emergency was documented
            emergency_documented = False
            for d in parsed_docs:
                if any(kw in d["text"].lower() for kw in ["emergency", "emergent", "acute onset", "trauma", "er admission", "ed visit", "emtala"]):
                    emergency_documented = True
                    break

            if not has_preauth_doc and not emergency_documented:
                findings.append(FindingCreate(
                    claim_id=claim.id,
                    category="missing_evidence",
                    severity="critical",
                    title="Denial Cites Missing Prior Authorization",
                    explanation="The claim was denied for lack of pre-authorization, and no approval reference or emergency exception documentation was found in the record.",
                    supporting_document_ids=[d["id"] for d in parsed_docs if d["type"] == "denial_letter"][:1],
                    evidence_reference="Prior Auth Protocol",
                    confidence=0.95,
                    reviewer_status="unreviewed"
                ))

        if any(kw in rejection_lower for kw in ["medical necessity", "not medically necessary", "experimental", "co-50"]) and "diagnostic_report" not in doc_types_present:
            findings.append(FindingCreate(
                claim_id=claim.id,
                category="missing_evidence",
                severity="high",
                title="Missing Objective Diagnostic Imaging or Pathology Report",
                explanation="Denial cites medical necessity (CO-50). Standard appeal protocols require objective diagnostic imaging, biopsy, or lab reports to validate clinical necessity under established guidelines.",
                supporting_document_ids=[],
                evidence_reference="Medical Necessity Diagnostic Standard",
                confidence=0.92,
                reviewer_status="unreviewed"
            ))

        if any(kw in rejection_lower for kw in ["out of network", "out-of-network", "non-participating", "pr-204"]) and not any(kw in d["text"].lower() for d in parsed_docs for kw in ["in-network", "participating", "emergency", "emtala"]):
            findings.append(FindingCreate(
                claim_id=claim.id,
                category="missing_evidence",
                severity="high",
                title="Missing In-Network Facility Verification or Emergency Involuntary Care Proof",
                explanation="Denial cites out-of-network balance billing (PR-204). To invoke No Surprises Act protections, documentation must establish that services were rendered at an in-network facility or were involuntary emergency care.",
                supporting_document_ids=[],
                evidence_reference="No Surprises Act Involuntary Care Standard",
                confidence=0.90,
                reviewer_status="unreviewed"
            ))

        # -------------------------------------------------------------
        # 3. CROSS-DOCUMENT INCONSISTENCIES
        # -------------------------------------------------------------
        # A. Patient Name Mismatches
        if len(all_patient_names) > 1:
            names = list(all_patient_names.keys())
            findings.append(FindingCreate(
                claim_id=claim.id,
                category="cross_document_inconsistency",
                severity="high",
                title="Discrepancy in Patient Identification Across Documents",
                explanation=f"Multiple distinct patient names were found across files: '{names[0]}' vs '{names[1]}'. Verify if one is the subscriber/policyholder and the other is the dependent.",
                supporting_document_ids=[did for ids in all_patient_names.values() for did in ids][:3],
                evidence_reference=f"Names: {', '.join(names[:2])}",
                confidence=0.90,
                reviewer_status="unreviewed"
            ))

        # B. Claim Amount vs Extracted Bill Amounts
        if all_amounts:
            max_extracted = max(all_amounts.keys())
            diff = abs(claim.claim_amount - max_extracted)
            if diff > 10.0 and max_extracted > 0:
                findings.append(FindingCreate(
                    claim_id=claim.id,
                    category="cross_document_inconsistency",
                    severity="medium",
                    title=f"Claim Amount Discrepancy (${claim.claim_amount:,.2f} vs Extracted ${max_extracted:,.2f})",
                    explanation=f"The stated claim amount of ${claim.claim_amount:,.2f} differs by ${diff:,.2f} from the maximum total charges found in the attached billing documents (${max_extracted:,.2f}).",
                    supporting_document_ids=all_amounts.get(max_extracted, [])[:2],
                    evidence_reference=f"Case Amount: ${claim.claim_amount:,.2f} | Document Amount: ${max_extracted:,.2f}",
                    confidence=0.88,
                    reviewer_status="unreviewed"
                ))

        # C. Date of Service Alignment
        if claim.date_of_service and all_dates:
            dos_matched = any(claim.date_of_service in d or d in claim.date_of_service for d in all_dates.keys())
            if not dos_matched and len(all_dates) > 0:
                sample_dates = list(all_dates.keys())[:3]
                findings.append(FindingCreate(
                    claim_id=claim.id,
                    category="cross_document_inconsistency",
                    severity="medium",
                    title="Case Date of Service Not Explicitly Found in Documents",
                    explanation=f"Case date of service '{claim.date_of_service}' does not directly match extracted document dates ({', '.join(sample_dates)}).",
                    supporting_document_ids=list({did for ids in all_dates.values() for did in ids})[:2],
                    evidence_reference=f"Stated DOS: {claim.date_of_service}",
                    confidence=0.82,
                    reviewer_status="unreviewed"
                ))

        # D. Document-to-Document Date Discrepancy
        doc_dates = {d["id"]: d["metadata"].get("dates", []) for d in parsed_docs if d["metadata"].get("dates")}
        if len(doc_dates) >= 2:
            doc_list = list(doc_dates.items())
            for i in range(len(doc_list)):
                for j in range(i + 1, len(doc_list)):
                    d1_id, d1_dates = doc_list[i]
                    d2_id, d2_dates = doc_list[j]
                    if d1_dates and d2_dates and not (set(d1_dates) & set(d2_dates)):
                        d1_name = next((d["filename"] for d in parsed_docs if d["id"] == d1_id), "Doc 1")
                        d2_name = next((d["filename"] for d in parsed_docs if d["id"] == d2_id), "Doc 2")
                        findings.append(FindingCreate(
                            claim_id=claim.id,
                            category="cross_document_inconsistency",
                            severity="medium",
                            title=f"Date Discrepancy Between '{d1_name}' and '{d2_name}'",
                            explanation=f"Dates of service on '{d1_name}' ({', '.join(d1_dates[:2])}) do not match dates on '{d2_name}' ({', '.join(d2_dates[:2])}).",
                            supporting_document_ids=[d1_id, d2_id],
                            evidence_reference=f"{d1_name}: {d1_dates[0]} vs {d2_name}: {d2_dates[0]}",
                            confidence=0.85,
                            reviewer_status="unreviewed"
                        ))
                        break

        # E. Policy / Member ID Inconsistency
        if len(all_policy_numbers) > 1:
            pols = list(all_policy_numbers.keys())
            findings.append(FindingCreate(
                claim_id=claim.id,
                category="cross_document_inconsistency",
                severity="high",
                title="Policy / Member ID Inconsistency Across Documents",
                explanation=f"Differing policy or member identification numbers found: '{pols[0]}' vs '{pols[1]}'.",
                supporting_document_ids=[did for ids in all_policy_numbers.values() for did in ids][:2],
                evidence_reference=f"Policy Numbers: {', '.join(pols[:2])}",
                confidence=0.90,
                reviewer_status="unreviewed"
            ))

        # F. Arithmetic Discrepancy in Invoices
        for doc in parsed_docs:
            av = doc.get("metadata", {}).get("arithmetic_validation")
            if av:
                findings.append(FindingCreate(
                    claim_id=claim.id,
                    category="cross_document_inconsistency",
                    severity="critical",
                    title=f"Arithmetic Discrepancy in Invoice Line Items ({doc['filename']})",
                    explanation=f"The sum of line items (${av['line_sum']:,.2f}) does not match the stated invoice total (${av['stated_total']:,.2f}), reflecting an unexplained discrepancy of ${av['discrepancy']:,.2f}.",
                    supporting_document_ids=[doc["id"]],
                    evidence_reference=f"Line Sum: ${av['line_sum']:,.2f} | Stated Total: ${av['stated_total']:,.2f}",
                    confidence=0.99,
                    reviewer_status="unreviewed"
                ))

        # -------------------------------------------------------------
        # 4. DOCUMENT INTEGRITY & FORENSIC INDICATORS
        # -------------------------------------------------------------
        for doc in parsed_docs:
            meta = doc.get("metadata", {})
            integrity_flags = meta.get("integrity_flags", [])

            # Check PDF metadata
            pdf_meta = meta.get("pdf_metadata", {})
            font_count = pdf_meta.get("font_count", 0)
            if font_count > 10:
                findings.append(FindingCreate(
                    claim_id=claim.id,
                    category="document_integrity",
                    severity="medium",
                    title=f"High Font Diversity in {doc['filename']}",
                    explanation=f"Document contains {font_count} embedded fonts, which can indicate multi-source document assembly or text block layering.",
                    supporting_document_ids=[doc["id"]],
                    evidence_reference=f"Font Count: {font_count}",
                    confidence=0.75,
                    reviewer_status="unreviewed"
                ))

            for flag in integrity_flags:
                findings.append(FindingCreate(
                    claim_id=claim.id,
                    category="document_integrity",
                    severity="low",
                    title=f"Document Artifact: {doc['filename']}",
                    explanation=flag,
                    supporting_document_ids=[doc["id"]],
                    evidence_reference=flag,
                    confidence=0.80,
                    reviewer_status="unreviewed"
                ))

        # -------------------------------------------------------------
        # 5. REJECTION REASON & REBUTTAL ANALYSIS
        # -------------------------------------------------------------
        # Analyze denial context
        rebuttal_points = []
        if any(kw in rejection_lower for kw in ["medical necessity", "not medically necessary", "experimental", "investigational", "co-50", "co-57"]):
            # Check if diagnosis codes support medical necessity
            if all_icd_codes:
                rebuttal_points.append("Clinical ICD-10 diagnosis codes and attached medical records substantiate clinical necessity under established clinical practice guidelines.")
            findings.append(FindingCreate(
                claim_id=claim.id,
                category="rejection_analysis",
                severity="info",
                title="Medical Necessity Denial Analysis",
                explanation=f"The insurer denied coverage citing lack of medical necessity ('{claim.rejection_reason}'). Appeal strategy: cite specific ICD-10 codes ({', '.join(list(all_icd_codes.keys())[:3]) or 'documented'}), physician clinical notes, and peer-reviewed treatment guidelines.",
                supporting_document_ids=[d["id"] for d in parsed_docs if d["type"] in ["diagnostic_report", "discharge_summary", "denial_letter"]][:3],
                evidence_reference=f"Denial: {claim.rejection_reason}",
                confidence=0.92,
                reviewer_status="unreviewed"
            ))

        elif any(kw in rejection_lower for kw in ["pre-auth", "prior auth", "authorization", "co-197"]):
            # Check if emergency care
            is_emergency = any("emergency" in d["text"].lower() or "emergent" in d["text"].lower() or "acute" in d["text"].lower() for d in parsed_docs)
            if is_emergency:
                findings.append(FindingCreate(
                    claim_id=claim.id,
                    category="rejection_analysis",
                    severity="info",
                    title="Prior Authorization Rebuttal: Emergency Exception (EMTALA)",
                    explanation="Although denied for lack of prior authorization, clinical documentation confirms the patient presented with an emergency medical condition. Federal regulations (EMTALA / ACA § 2719A) prohibit requiring prior authorization for emergency screening and stabilization.",
                    supporting_document_ids=[d["id"] for d in parsed_docs if "discharge_summary" == d["type"] or "emergency" in d["text"].lower()][:2],
                    evidence_reference="Emergency Exception under 42 U.S.C. § 1395dd",
                    confidence=0.96,
                    reviewer_status="unreviewed"
                ))
            else:
                findings.append(FindingCreate(
                    claim_id=claim.id,
                    category="rejection_analysis",
                    severity="high",
                    title="Prior Authorization Denial Analysis",
                    explanation=f"Insurer denied claim due to missing prior authorization. Recommend obtaining retroactive authorization letter or peer-to-peer physician clinical attestation.",
                    supporting_document_ids=[d["id"] for d in parsed_docs if d["type"] == "denial_letter"][:1],
                    evidence_reference=f"Denial: {claim.rejection_reason}",
                    confidence=0.90,
                    reviewer_status="unreviewed"
                ))

        elif any(kw in rejection_lower for kw in ["out of network", "out-of-network", "non-participating", "pr-204", "balance billing"]):
            findings.append(FindingCreate(
                claim_id=claim.id,
                category="rejection_analysis",
                severity="info",
                title="Out-of-Network Denial: No Surprises Act Protections",
                explanation="The claim was denied or subject to high cost-sharing due to out-of-network status. Under the federal No Surprises Act (effective Jan 2022), patients receiving emergency services or non-emergency services at in-network facilities are protected from surprise balance billing.",
                supporting_document_ids=[d["id"] for d in parsed_docs if d["type"] in ["medical_bill", "denial_letter"]][:2],
                evidence_reference="No Surprises Act / Consolidated Appropriations Act 2021",
                confidence=0.94,
                reviewer_status="unreviewed"
            ))

        elif any(kw in rejection_lower for kw in ["timely filing", "untimely", "co-29", "past deadline"]):
            findings.append(FindingCreate(
                claim_id=claim.id,
                category="rejection_analysis",
                severity="medium",
                title="Timely Filing Dispute Analysis",
                explanation=f"Insurer alleges untimely claim submission. Appeal must include EDI batch confirmation, clearinghouse electronic acceptance report, or proof of timely initial billing.",
                supporting_document_ids=[d["id"] for d in parsed_docs if d["type"] == "denial_letter"][:1],
                evidence_reference=f"Denial: {claim.rejection_reason}",
                confidence=0.90,
                reviewer_status="unreviewed"
            ))
        else:
            findings.append(FindingCreate(
                claim_id=claim.id,
                category="rejection_analysis",
                severity="info",
                title="General Adverse Determination Review",
                explanation=f"Denial Reason: '{claim.rejection_reason}'. The appeal will systematically address the insurer's stated grounds, provide itemized substantiation, and request full reconsideration.",
                supporting_document_ids=[d["id"] for d in parsed_docs][:2],
                evidence_reference=claim.rejection_reason,
                confidence=0.88,
                reviewer_status="unreviewed"
            ))

        # -------------------------------------------------------------
        # 6. RECOMMENDED ACTIONS FOR HUMAN REVIEWER
        # -------------------------------------------------------------
        recs = []
        if not has_bill:
            recs.append("Upload itemized hospital billing ledger (UB-04 / CMS-1500) showing CPT codes.")
        if not has_clinical:
            recs.append("Obtain signed clinical discharge notes or treating physician letter of medical necessity.")
        if len(all_patient_names) > 1:
            recs.append("Confirm primary subscriber vs dependent relationship in insurance portal.")
        if not recs:
            recs.append("Review generated appeal letter draft, verify factual citations, and export signed packet.")

        for idx, rec in enumerate(recs):
            findings.append(FindingCreate(
                claim_id=claim.id,
                category="recommended_action",
                severity="info",
                title=f"Action Item #{idx+1}",
                explanation=rec,
                supporting_document_ids=[],
                evidence_reference="Workflow Recommendation",
                confidence=1.0,
                reviewer_status="unreviewed"
            ))

        return findings
