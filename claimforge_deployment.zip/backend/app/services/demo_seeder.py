import os
import json
from pathlib import Path
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.config import settings
from app.models.models import Claim, Document, Finding, Appeal, AnalysisRun
from app.services.extractor import DocumentExtractor
from app.services.analysis_engine import AnalysisEngine
from app.services.readiness_service import ReadinessService
from app.services.appeal_generator import AppealGenerator
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors

class DemoSeeder:
    @staticmethod
    def create_sample_pdf(file_path: str, title: str, content_lines: list[str]) -> str:
        """
        Creates a valid, searchable synthetic PDF file with text and tables for demo fixtures.
        """
        dirname = os.path.dirname(file_path)
        if dirname:
            os.makedirs(dirname, exist_ok=True)
        doc = SimpleDocTemplate(file_path, pagesize=letter, rightMargin=40, leftMargin=40, topMargin=40, bottomMargin=40)
        styles = getSampleStyleSheet()

        title_style = ParagraphStyle('TStyle', parent=styles['Heading1'], fontSize=14, leading=18, textColor=colors.HexColor("#0f766e"))
        body_style = ParagraphStyle('BStyle', parent=styles['Normal'], fontSize=9, leading=13, textColor=colors.HexColor("#1e293b"))

        elements = [
            Paragraph(title, title_style),
            Spacer(1, 10)
        ]

        for line in content_lines:
            if line.startswith("TABLE:"):
                # Parse simple table format
                table_raw = line.replace("TABLE:", "").strip()
                rows = [r.split("|") for r in table_raw.split(";")]
                t = Table(rows)
                t.setStyle(TableStyle([
                    ('BACKGROUND', (0,0), (-1,0), colors.HexColor("#f1f5f9")),
                    ('TEXTCOLOR', (0,0), (-1,-1), colors.HexColor("#1e293b")),
                    ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor("#cbd5e1")),
                    ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
                    ('FONTSIZE', (0,0), (-1,-1), 8),
                ]))
                elements.append(t)
                elements.append(Spacer(1, 8))
            else:
                elements.append(Paragraph(line, body_style))
                elements.append(Spacer(1, 4))

        doc.build(elements)
        return file_path

    @staticmethod
    async def seed_all(session: AsyncSession) -> list[str]:
        """
        Seeds 4 realistic synthetic cases and creates the document files and findings.
        """
        fixtures_dir = Path(settings.UPLOAD_DIR) / "fixtures"
        os.makedirs(fixtures_dir, exist_ok=True)

        scenarios = [
            {
                "claim_ref": "CLM-2026-9011",
                "patient_ref": "PAT-EMERG-441",
                "insurer": "BlueShield Horizon",
                "amount": 8450.00,
                "rejection_reason": "Claim denied: Missing prior authorization for acute inpatient surgical admission.",
                "rejection_code": "CO-197",
                "policy_no": "BSH-99281-X",
                "dos": "2026-01-14",
                "priority": "high",
                "docs": [
                    {
                        "filename": "hospital_itemized_bill_CLM9011.pdf",
                        "type": "medical_bill",
                        "title": "ST. JUDE REGIONAL MEDICAL CENTER - ITEMIZED BILLING LEDGER",
                        "lines": [
                            "Patient Name: Alexander Wright | Member ID: BSH-99281-X",
                            "Date of Service: 2026-01-14 | Account #: ACC-99410",
                            "Treating Provider: St. Jude Regional Medical Center Emergency Dept",
                            "TABLE:Rev Code|CPT Code|Description|Units|Charge;0450|99285|Emergency Dept Visit Level 5|1|$1,850.00;0360|44970|Laparoscopic Appendectomy|1|$5,400.00;0250|J3490|IV Anesthesia & Medications|1|$1,200.00",
                            "Total Charges Billed: $8,450.00 | Balance Due: $8,450.00"
                        ]
                    },
                    {
                        "filename": "er_discharge_summary_CLM9011.pdf",
                        "type": "discharge_summary",
                        "title": "EMERGENCY DEPARTMENT CLINICAL DISCHARGE SUMMARY",
                        "lines": [
                            "Patient: Alexander Wright | Admission Date: 2026-01-14 | Discharge Date: 2026-01-15",
                            "Attending Physician: Dr. Marcus Vance, MD (General Surgery)",
                            "Chief Complaint: Severe acute lower right quadrant abdominal pain with rebound tenderness.",
                            "Clinical Assessment: Acute Appendicitis with localized peritonitis. Immediate emergency surgical intervention required.",
                            "Diagnosis Codes: ICD-10 K35.80 (Unspecified acute appendicitis), R10.31 (Right lower quadrant pain).",
                            "Procedure: Laparoscopic Appendectomy (CPT 44970). Emergent admission directly from Emergency Department under EMTALA guidelines.",
                            "Discharge Condition: Stable, postoperative recovery uneventful."
                        ]
                    },
                    {
                        "filename": "denial_letter_CLM9011.pdf",
                        "type": "denial_letter",
                        "title": "BLUESHIELD HORIZON - ADVERSE BENEFIT DETERMINATION",
                        "lines": [
                            "Claim Reference: CLM-2026-9011 | Patient: Alexander Wright | Policy: BSH-99281-X",
                            "Billed Amount: $8,450.00 | Date of Service: 2026-01-14",
                            "Determination: DENIED IN FULL (Remittance Code: CO-197).",
                            "Reason: Inpatient surgical admission requires prior authorization approval prior to service rendering. No prior auth on file.",
                            "Appeal Filing Deadline: 180 days from receipt of this notice."
                        ]
                    }
                ]
            },
            {
                "claim_ref": "CLM-2026-7823",
                "patient_ref": "PAT-CARDIO-102",
                "insurer": "Aetna Premier Health",
                "amount": 3200.00,
                "rejection_reason": "Denied as not medically necessary / investigational diagnostic imaging.",
                "rejection_code": "CO-50",
                "policy_no": "AET-55420-C",
                "dos": "2026-02-02",
                "priority": "medium",
                "docs": [
                    {
                        "filename": "cardiac_mri_diagnostic_report.pdf",
                        "type": "diagnostic_report",
                        "title": "METRO CARDIOLOGY INSTITUTE - DIAGNOSTIC MRI REPORT",
                        "lines": [
                            "Patient Name: Eleanor Vance | Member ID: AET-55420-C",
                            "Date of Service: 2026-02-02 | Ordering Physician: Dr. Sarah Lin, FACC",
                            "Study: Cardiac Magnetic Resonance Imaging (CPT 75561) with and without contrast.",
                            "Indication: Evaluation of unexplained cardiomyopathy, progressive dyspnea, abnormal echocardiogram.",
                            "Findings: Left ventricular dilation with reduced ejection fraction (EF 34%). Late gadolinium enhancement indicates non-ischemic cardiomyopathy.",
                            "Diagnosis: ICD-10 I42.0 (Dilated cardiomyopathy), I50.9 (Heart failure, unspecified).",
                            "Clinical Necessity: Guideline-directed Class I indication under ACC/AHA clinical consensus."
                        ]
                    },
                    {
                        "filename": "aetna_denial_eob_CLM7823.pdf",
                        "type": "denial_letter",
                        "title": "AETNA PREMIER HEALTH - EXPLANATION OF BENEFITS",
                        "lines": [
                            "Claim Reference: CLM-2026-7823 | Insured: Eleanor Vance",
                            "Billed Amount: $3,200.00 | Denial Code: CO-50",
                            "Denial Reason: Service is deemed not medically necessary or investigational for the reported primary diagnosis.",
                            "Appeal Instructions: Submit clinical records to Clinical Appeals Unit within 60 days."
                        ]
                    }
                ]
            },
            {
                "claim_ref": "CLM-2026-3118",
                "patient_ref": "PAT-ORTHO-802",
                "insurer": "Cigna Global Care",
                "amount": 5600.00,
                "rejection_reason": "Out-of-network physician balance billing not covered under in-network plan tier.",
                "rejection_code": "PR-204",
                "policy_no": "CG-77192",
                "dos": "2026-01-20",
                "priority": "high",
                "docs": [
                    {
                        "filename": "physician_specialist_bill.pdf",
                        "type": "medical_bill",
                        "title": "ADVANCED ORTHOPEDIC TRAUMA SURGEONS - INVOICE",
                        "lines": [
                            "Patient Name: David Chen | Date of Service: 2026-01-20",
                            "Facility: City General Hospital (In-Network Participating Facility)",
                            "Treating On-Call Surgeon: Dr. Robert Keller, MD (Non-Participating / OON)",
                            "TABLE:Code|Description|Units|Billed;27244|Treatment of intertrochanteric fracture|1|$4,400.00;99285|Emergency Consultation Level 5|1|$1,200.00",
                            "Total Charges: $5,600.00"
                        ]
                    },
                    {
                        "filename": "emergency_trauma_admission_record.pdf",
                        "type": "discharge_summary",
                        "title": "CITY GENERAL HOSPITAL - EMERGENCY ADMISSION RECORD",
                        "lines": [
                            "Patient: David Chen | Admission Date: 2026-01-20",
                            "Admitted via Emergency Department following acute traumatic fall.",
                            "Diagnosis: ICD-10 S72.141A (Displaced intertrochanteric fracture of right femur).",
                            "Emergency On-Call Coverage: Patient did not have choice of on-call orthopedic surgeon during emergent admission."
                        ]
                    }
                ]
            },
            {
                "claim_ref": "CLM-2026-4409",
                "patient_ref": "PAT-TRAUMA-991",
                "insurer": "United Healthcare",
                "amount": 14800.00,
                "rejection_reason": "Billed amount exceeds allowable schedule and invoice contains unverified line items.",
                "rejection_code": "CO-16",
                "policy_no": "UHC-00441",
                "dos": "2026-02-10",
                "priority": "urgent",
                "docs": [
                    {
                        "filename": "altered_invoice_sample.pdf",
                        "type": "medical_bill",
                        "title": "VALLEY HEALTH CLINIC - BILLING STATEMENT",
                        "lines": [
                            "Patient: Jonathan Reed | Date of Service: 2026-02-10",
                            "TABLE:Item|Code|Description|Amount;1|99214|Complex Office Visit|$350.00;2|73721|MRI Lower Extremity|$2,850.00;3|29881|Arthroscopy Knee|$8,000.00",
                            "Sum of line items: $11,200.00",
                            "Modified Stated Total: $14,800.00 (Calculated Line Items Total $11,200.00 - Discrepancy $3,600.00)"
                        ]
                    }
                ]
            }
        ]

        seeded_claim_ids = []

        for item in scenarios:
            # Check if claim already exists
            from sqlalchemy import select
            existing = await session.execute(select(Claim).where(Claim.claim_reference == item["claim_ref"]))
            claim = existing.scalar_one_or_none()

            if not claim:
                claim = Claim(
                    claim_reference=item["claim_ref"],
                    patient_reference=item["patient_ref"],
                    insurer_name=item["insurer"],
                    claim_amount=item["amount"],
                    rejection_reason=item["rejection_reason"],
                    rejection_code=item["rejection_code"],
                    policy_number=item["policy_no"],
                    date_of_service=item["dos"],
                    status="draft",
                    review_priority=item["priority"],
                    reviewer_notes=f"Synthetic demo case for {item['insurer']} claim review."
                )
                session.add(claim)
                await session.commit()
                await session.refresh(claim)

            # Create Documents
            docs_created = []
            for d in item["docs"]:
                pdf_path = str(fixtures_dir / f"{claim.id}_{d['filename']}")
                DemoSeeder.create_sample_pdf(pdf_path, d["title"], d["lines"])

                # Extract text & entities
                text, entities, pages = DocumentExtractor.extract_from_file(pdf_path, "application/pdf")

                # Check if doc exists
                doc_query = await session.execute(select(Document).where(
                    Document.claim_id == claim.id,
                    Document.original_filename == d["filename"]
                ))
                doc = doc_query.scalar_one_or_none()
                if not doc:
                    doc = Document(
                        claim_id=claim.id,
                        original_filename=d["filename"],
                        document_type=d["type"],
                        storage_path=pdf_path,
                        mime_type="application/pdf",
                        file_size=os.path.getsize(pdf_path),
                        page_count=pages,
                        processing_status="processed",
                        extracted_text=text,
                        extracted_metadata=json.dumps(entities)
                    )
                    session.add(doc)
                    await session.commit()
                    await session.refresh(doc)
                docs_created.append(doc)

            # Run Analysis
            findings = AnalysisEngine.analyze_claim(claim, docs_created)
            
            # Delete old findings
            from sqlalchemy import delete
            await session.execute(delete(Finding).where(Finding.claim_id == claim.id))
            await session.commit()

            db_findings = []
            for f in findings:
                df = Finding(
                    claim_id=claim.id,
                    category=f.category,
                    severity=f.severity,
                    title=f.title,
                    explanation=f.explanation,
                    supporting_document_ids=json.dumps(f.supporting_document_ids or []),
                    evidence_reference=f.evidence_reference,
                    confidence=f.confidence or 1.0,
                    reviewer_status="unreviewed"
                )
                session.add(df)
                db_findings.append(df)
            await session.commit()

            # Calculate Readiness Score
            score_res = ReadinessService.calculate_score(claim, docs_created, db_findings)
            
            # Save Analysis Run
            run = AnalysisRun(
                claim_id=claim.id,
                processing_status="completed",
                analysis_mode="rule_based",
                readiness_score=score_res.readiness_score,
                score_breakdown=json.dumps(score_res.model_dump(), default=str)
            )
            session.add(run)

            # Generate Appeal Draft for the high-readiness cases
            if score_res.readiness_score >= 80.0:
                draft = AppealGenerator.generate_draft(claim, docs_created, db_findings)
                # Check if appeal exists
                app_query = await session.execute(select(Appeal).where(Appeal.claim_id == claim.id))
                app = app_query.scalars().first()
                if not app:
                    app = Appeal(
                        claim_id=claim.id,
                        appeal_title=draft["title"],
                        draft_content=draft["draft_content"],
                        structured_sections=json.dumps(draft["structured_sections"]),
                        included_finding_ids=json.dumps(draft["included_finding_ids"]),
                        approval_status="draft"
                    )
                    session.add(app)
                claim.status = "appeal_generated"
            else:
                claim.status = "analyzed"

            await session.commit()
            seeded_claim_ids.append(claim.id)

        return seeded_claim_ids
