# ClaimForge — VISTERA 2026 Hackathon Demo Guide

This guide describes the 4 pre-built realistic synthetic scenarios ready to present to hackathon judges without needing real patient data or external paid API keys.

---

## Quick Demo Flow for Judges (3-Minute Tour)

1. **Step 1: Open the Landing Page** (`http://localhost:3000`)
   - Highlight the problem: Medical insurance claim rejections cause immense financial stress. Many legitimate claims are denied because of clerical misalignments or misunderstood denial codes.
   - Point to the live metrics ticker: Connected directly to the backend database.
   - Click **"Explore Demo Scenarios"**.

2. **Step 2: Choose a Synthetic Scenario** (`/demo`)
   - Click on **Scenario 1: Emergency Appendectomy Prior-Auth Dispute**.
   - Show how ClaimForge loads all three original synthetic documents:
     1. Itemized hospital billing ledger ($8,450.00, CPT 44970)
     2. Emergency clinical discharge summary (Acute Appendicitis, ICD-10 K35.80, Emergent Admission)
     3. Insurer denial letter (citing Code CO-197: Lack of prior authorization)

3. **Step 3: Inspect Findings & Appeal Readiness** (`/claims/[id]`)
   - Notice the **Appeal Readiness Score: 91/100 (High Readiness)**.
   - Review the **Rejection Analysis Finding**: ClaimForge identifies that under federal **EMTALA (42 U.S.C. § 1395dd)** and **ACA § 2719A**, emergency screening and surgical stabilization *cannot* be denied for lack of prior authorization.
   - Show the **Extracted Facts**: Verified ICD-10 `K35.80`, CPT `44970`, and treating surgeon `Dr. Marcus Vance`.
   - Show human reviewer interaction: Click to **Confirm** the finding.

4. **Step 4: Review and Edit the Appeal Letter** (`/claims/[id]/appeal`)
   - Inspect the generated appeal draft: It cites the exact statutory grounds, itemizes the enclosed documentary exhibits (Exhibit A, B, C), and highlights missing information in explicit placeholders (`[REVIEWER_OR_PATIENT_NAME]`).
   - Switch Tone: Click between **Formal Professional**, **Assertive Legal (ERISA/EMTALA)**, and **Clinical Concise**.
   - Reviewer Approval: Click **"Approve Appeal Draft"**.

5. **Step 5: Export Official PDF Packet**
   - Click **"Download Official PDF Packet"**.
   - Open the generated PDF: Show the professional header, metadata summary box, exhibit table, and audit trail notice.

---

## The 4 Synthetic Scenarios

| # | Scenario Title | Insurer & Disputed Amount | Stated Denial Reason | Key Engine Discovery | Readiness Score |
|---|----------------|---------------------------|----------------------|----------------------|-----------------|
| 1 | **Emergency Appendectomy** | BlueShield Horizon ($8,450.00) | Missing prior authorization (CO-197) | Clinical records prove acute emergency admission exempt from pre-auth under EMTALA & ACA. | **91% (High)** |
| 2 | **Cardiac MRI Rebuttal** | Aetna Premier Health ($3,200.00) | Investigational / Not Medically Necessary (CO-50) | Missing UB-04 bill detected; Clinical guidelines (ACC/AHA Class I) substantiate cardiomyopathy diagnosis. | **74% (Moderate)** |
| 3 | **Trauma Out-of-Network** | Cigna Global Care ($5,600.00) | Out-of-network provider balance billing (PR-204) | On-call trauma surgeon at in-network facility protected under federal **No Surprises Act**. | **94% (High)** |
| 4 | **Altered Invoice Flag** | United Healthcare ($14,800.00) | Unverified billing line items (CO-16) | Mathematical discrepancy: Sum of items ($11,200) vs stated total ($14,800). High font diversity flag. | **42% (Low)** |

---

## Testing Live Creation & Document Upload
Judges can also create a new claim from scratch:
1. Click **"New Claim"** in the top navigation.
2. Fill in custom claim details (e.g. `CLM-DEMO-LIVE`, Amount `$2,800.00`).
3. Drag-and-drop or select any PDF file.
4. Click **"Create & Run Analysis"**.
5. Watch the backend extract text, recognize entities, and calculate the readiness score in real time.
