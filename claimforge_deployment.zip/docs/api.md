# ClaimForge — REST API Reference

The ClaimForge backend exposes a fully documented RESTful API with OpenAPI/Swagger specifications available at `http://127.0.0.1:8000/docs`.

---

## Base URLs
- **Local API Base**: `http://127.0.0.1:8000/api`
- **Health Check**: `http://127.0.0.1:8000/health`
- **Swagger Documentation**: `http://127.0.0.1:8000/docs`
- **ReDoc Documentation**: `http://127.0.0.1:8000/redoc`

---

## 1. System Health
### `GET /health`
Returns the status of backend services, database connection, storage mode, and active AI analysis engine.
**Response (200 OK):**
```json
{
  "status": "healthy",
  "service": "ClaimForge API",
  "version": "1.0.0",
  "environment": "development",
  "database": "connected",
  "storage_mode": "local",
  "ai_provider": "rule_based",
  "ai_active_mode": "rule_based"
}
```

---

## 2. Dashboard Analytics
### `GET /api/dashboard/stats`
Returns aggregated live metrics for the dashboard overview.
**Response (200 OK):**
```json
{
  "total_claims": 4,
  "awaiting_review": 1,
  "missing_evidence": 3,
  "completed_reviews": 3,
  "total_disputed_amount": 32050.0,
  "avg_readiness_score": 85.7
}
```

---

## 3. Claims Management
### `GET /api/claims`
List all insurance claims with optional status and search filtering.
- Query Parameters:
  - `status` (string, optional): Filter by status (`draft`, `documents_uploaded`, `analyzed`, `in_review`, `appeal_generated`, `completed`)
  - `search` (string, optional): Substring match on claim reference, patient name, insurer, or rejection reason.
  - `limit` (int, default 100)
  - `offset` (int, default 0)

### `POST /api/claims`
Create a new claim case.
**Request Body:**
```json
{
  "claim_reference": "CLM-2026-9011",
  "patient_reference": "PAT-EMERG-441",
  "insurer_name": "BlueShield Horizon",
  "claim_amount": 8450.00,
  "rejection_reason": "Claim denied: Missing prior authorization for acute inpatient surgical admission.",
  "rejection_code": "CO-197",
  "policy_number": "BSH-99281-X",
  "date_of_service": "2026-01-14",
  "review_priority": "high",
  "reviewer_notes": "Emergency surgery review"
}
```

### `GET /api/claims/{claim_id}`
Retrieve complete claim details by ID.

### `PATCH /api/claims/{claim_id}`
Update claim fields, priority, status, or reviewer notes.

### `DELETE /api/claims/{claim_id}`
Deletes claim and cascades deletion of attached documents, findings, appeals, and analysis runs.

---

## 4. Document Management
### `POST /api/claims/{claim_id}/documents`
Uploads a document (PDF, PNG, JPEG, WEBP) via `multipart/form-data`.
- Form fields:
  - `file`: Binary file upload
  - `document_type`: `medical_bill`, `discharge_summary`, `diagnostic_report`, `prescription`, `denial_letter`, `pre_auth`, or `other`
- Extracts text and structured entities immediately upon upload.

### `GET /api/claims/{claim_id}/documents`
Lists all documents associated with a claim, including extraction status, page count, and file size.

### `GET /api/documents/{document_id}/text`
Returns the extracted plain text and structured JSON metadata for a specific document.

### `DELETE /api/documents/{document_id}`
Removes a document from disk storage and database.

---

## 5. Evidence Analysis & Findings
### `POST /api/claims/{claim_id}/analyze`
Triggers cross-document analysis across all uploaded records.
- Extracts entities (ICD-10, CPT, amounts, dates, providers).
- Performs cross-document consistency checks and arithmetic validations.
- Calculates Appeal Readiness Score and records an analysis run.

### `GET /api/claims/{claim_id}/findings`
Returns all findings grouped into 6 structured categories:
- `extracted_facts`
- `missing_evidence`
- `cross_document_inconsistencies`
- `document_integrity_indicators`
- `rejection_analysis`
- `recommended_actions`

### `PATCH /api/findings/{finding_id}`
Allows human reviewer to confirm, dismiss, or annotate a finding:
```json
{
  "reviewer_status": "confirmed",
  "reviewer_comment": "Verified that appendectomy was performed on an emergency basis."
}
```

---

## 6. Appeal Readiness Score
### `GET /api/claims/{claim_id}/readiness`
Returns the transparent 0–100 score with component weights:
- Evidence Completeness (30%)
- Cross-Document Consistency (25%)
- Rejection Rebuttal Strength (25%)
- Document Integrity (20%)
Includes positive factors, negative factors, and recommended improvements.

---

## 7. Appeal Letter Generation & Export
### `POST /api/claims/{claim_id}/appeals`
Generates an evidence-linked appeal draft.
- Optional body:
  - `tone`: `formal_professional`, `assertive_legal`, or `clinical_concise`
  - `custom_instructions`: string
  - `selected_finding_ids`: list of finding IDs

### `GET /api/claims/{claim_id}/appeals`
Lists all generated appeal drafts for a claim.

### `PATCH /api/appeals/{appeal_id}`
Update draft text, approval status (`draft`, `pending_approval`, `approved`, `rejected`), and reviewer sign-off notes.

### `GET /api/appeals/{appeal_id}/export?format={pdf|txt}`
Downloads the appeal as a professionally formatted PDF packet (default) or plain text document.

---

## 8. Interactive Demo & Seeding
### `GET /api/demo/cases`
Lists available synthetic demo scenarios.

### `POST /api/demo/seed`
Seeds 4 realistic synthetic cases into the database with synthetic PDF documents and pre-computed findings.
