# ClaimForge — System Architecture

**ClaimForge** is an AI-assisted healthcare insurance claim verification and evidence-backed appeal preparation platform built for the **VISTERA 2026 National Hackathon**.

---

## 1. High-Level Architecture Overview

ClaimForge follows a modular, decoupled architecture:
- **Presentation Layer**: Next.js 14+ (React, TypeScript, Tailwind CSS, Lucide Icons) with responsive design, real-time client state management, and clear review workflows.
- **Application & API Layer**: Python FastAPI with Pydantic request/response validation, asynchronous database access (SQLAlchemy AsyncIO), and RESTful endpoints documented via OpenAPI/Swagger.
- **Document Processing Pipeline**: PyMuPDF (`fitz`) and Pillow for PDF/image ingestion, text layer extraction, embedded font enumeration, and metadata anomaly detection.
- **Cross-Document Analysis Engine**: Deterministic, rule-based cross-document comparison engine that extracts medical entities (ICD-10, CPT, amounts, dates, providers, pre-auth numbers) and cross-checks them across uploaded records without hallucination.
- **Provider-Independent AI Service**: Pluggable LLM adapter (Gemini, OpenAI, Anthropic) with transparent rule-based fallback when external API keys are unavailable. Findings are explicitly labeled `rule_based` vs `ai_generated`.
- **Appeal Readiness Scoring Engine**: Transparent 0–100 scoring model based on Evidence Completeness (30%), Cross-Document Consistency (25%), Rejection Rebuttal Strength (25%), and Document Integrity (20%).
- **Appeal Generation & Export**: Automated evidence-linked legal/clinical appeal packet generator with human review workflow (draft, edit, approve/reject) and professional ReportLab PDF export.
- **Storage & Persistence**:
  - **Local Development Mode**: SQLite (`aiosqlite`) + local secure uploads directory (`/backend/uploads/`). Zero external dependencies or paid APIs required for testing.
  - **Production/Cloud Mode**: Supabase PostgreSQL with Row Level Security (RLS) + Supabase Storage for private document buckets.

---

## 2. Component Diagram

```
+------------------------------------------------------------------+
|                    ClaimForge Frontend (Next.js)                 |
|  - Landing Page     - Dashboard (Real Metrics) - New Claim Wizard|
|  - Claim Detail     - Findings & Matrix        - Appeal Editor   |
+---------------------------------+--------------------------------+
                                  | HTTP / JSON REST APIs
                                  v
+------------------------------------------------------------------+
|                    FastAPI Backend (Port 8000)                   |
|  - /api/claims      - /api/documents           - /api/analysis   |
|  - /api/findings    - /api/readiness           - /api/appeals    |
|  - /api/demo        - /health                  - /docs           |
+--------+------------------------+-------------------+------------+
         |                        |                   |
         v                        v                   v
+------------------+    +-------------------+   +------------------+
| Document Service |    |  Analysis Engine  |   | Appeal Generator |
| - PyMuPDF Text   |    | - Entity Extract  |   | - Legal Sections |
| - Font Diversity |    | - Cross-Doc Match |   | - Exhibit Linking|
| - Pillow Image   |    | - Denial Analysis |   | - ReportLab PDF  |
| - Metadata Flags |    | - Readiness Score |   | - TXT Export     |
+--------+---------+    +---------+---------+   +--------+---------+
         |                        |                      |
         +------------------------+----------------------+
                                  |
                                  v
                   +-----------------------------+
                   |     Persistence Layer       |
                   | - SQLite / Supabase Postgres|
                   | - Private Document Storage  |
                   +-----------------------------+
```

---

## 3. The 9-Step Verification & Appeal Pipeline

1. **Case Intake**: Reviewer inputs claim reference, pseudonymous patient identifier, insurer name, billed amount, and stated rejection reason.
2. **Document Upload**: Multi-file drag-and-drop upload (PDF/images) categorized by document type (Itemized Bill, Discharge Summary, Diagnostic Report, Prescription, Denial Letter).
3. **Extraction**: PyMuPDF extracts raw text, page count, font counts, and PDF metadata. Regex engines extract structured ICD-10, CPT, dates, amounts, and provider names.
4. **Cross-Document Analysis**:
   - Compares dates across hospital ledger and discharge summary.
   - Compares claim amount against extracted line items (flags arithmetic alterations).
   - Verifies whether patient name is uniform across all documents.
   - Cross-references insurer denial code (e.g. `CO-197`, `CO-50`, `PR-204`) with documentary evidence.
5. **Findings Generation**: Findings are saved to the database with categories (`extracted_fact`, `missing_evidence`, `cross_document_inconsistency`, `document_integrity`, `rejection_analysis`, `recommended_action`), confidence scores, and severity levels.
6. **Readiness Calculation**: Calculates the Appeal Readiness Score (0-100) and displays an itemized breakdown explaining what improves or lowers the score.
7. **Draft Generation**: Builds a structured appeal letter citing verified evidence, clinical guidelines (e.g. EMTALA emergency exceptions, No Surprises Act, ACC/AHA cardiology guidelines), and explicitly marks missing items with placeholders.
8. **Human Review**: A human reviewer inspects findings, marks them confirmed or dismissed, modifies draft text, and provides approval sign-off.
9. **Export & Delivery**: Generates an audit-ready, styled PDF appeal packet with letterhead, exhibit tables, and reviewer signature block.

---

## 4. Responsible AI & Decision Support Principles

- **Decision-Support, Not Autonomous Fraud Detection**: ClaimForge flags inconsistencies for human review; it never accuses anyone of fraud or guarantees appeal success.
- **No Hallucinations**: When documents lack required information, ClaimForge places explicit bracketed placeholders (e.g. `[PATIENT_DATE_OF_BIRTH]`, `[TREATING_PHYSICIAN_SIGNATURE]`) rather than fabricating data.
- **Untrusted Document Ingestion**: Document contents are treated strictly as untrusted evidence data and are never interpreted as system execution instructions.
- **Transparent Mode Attribution**: All findings and score outputs indicate whether they were produced via deterministic rules (`rule_based`) or AI enhancement (`ai_assisted`).
