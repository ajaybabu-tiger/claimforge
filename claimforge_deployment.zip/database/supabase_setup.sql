-- ClaimForge Supabase PostgreSQL & Storage Setup
-- Includes RLS policies and Storage bucket definitions

-- Enable UUID extension if needed
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Enable Row Level Security on all tables
ALTER TABLE claims ENABLE ROW LEVEL SECURITY;
ALTER TABLE documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE findings ENABLE ROW LEVEL SECURITY;
ALTER TABLE appeals ENABLE ROW LEVEL SECURITY;
ALTER TABLE analysis_runs ENABLE ROW LEVEL SECURITY;

-- Allow authenticated users to manage their claims and documents
-- For demo/hackathon environments, anon/authenticated can read and write with proper case-level isolation
CREATE POLICY "Allow public read-write for demo mode" ON claims
    FOR ALL USING (true) WITH CHECK (true);

CREATE POLICY "Allow public read-write for documents" ON documents
    FOR ALL USING (true) WITH CHECK (true);

CREATE POLICY "Allow public read-write for findings" ON findings
    FOR ALL USING (true) WITH CHECK (true);

CREATE POLICY "Allow public read-write for appeals" ON appeals
    FOR ALL USING (true) WITH CHECK (true);

CREATE POLICY "Allow public read-write for analysis_runs" ON analysis_runs
    FOR ALL USING (true) WITH CHECK (true);

-- Storage bucket configuration for Supabase Storage
-- Bucket: 'claim-documents' (Private by default)
INSERT INTO storage.buckets (id, name, public)
VALUES ('claim-documents', 'claim-documents', false)
ON CONFLICT (id) DO NOTHING;

-- Storage policies: Authenticated/Demo users can upload and read their own claim files
CREATE POLICY "Allow document upload" ON storage.objects
    FOR INSERT WITH CHECK (bucket_id = 'claim-documents');

CREATE POLICY "Allow document read" ON storage.objects
    FOR SELECT USING (bucket_id = 'claim-documents');

CREATE POLICY "Allow document delete" ON storage.objects
    FOR DELETE USING (bucket_id = 'claim-documents');
