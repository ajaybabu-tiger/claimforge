-- ClaimForge Initial Database Schema
-- Compatible with Supabase PostgreSQL and SQLite (with type affinities)

-- 1. Claims Table
CREATE TABLE IF NOT EXISTS claims (
    id TEXT PRIMARY KEY,
    claim_reference TEXT NOT NULL UNIQUE,
    patient_reference TEXT NOT NULL,
    insurer_name TEXT NOT NULL,
    claim_amount REAL NOT NULL,
    rejection_reason TEXT NOT NULL,
    rejection_code TEXT,
    policy_number TEXT,
    date_of_service TEXT,
    status TEXT NOT NULL DEFAULT 'draft', -- draft, documents_uploaded, processing, analyzed, in_review, appeal_generated, completed, archived
    review_priority TEXT NOT NULL DEFAULT 'medium', -- low, medium, high, urgent
    reviewer_notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_claims_status ON claims(status);
CREATE INDEX IF NOT EXISTS idx_claims_created_at ON claims(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_claims_ref ON claims(claim_reference);

-- 2. Documents Table
CREATE TABLE IF NOT EXISTS documents (
    id TEXT PRIMARY KEY,
    claim_id TEXT NOT NULL,
    original_filename TEXT NOT NULL,
    document_type TEXT NOT NULL DEFAULT 'other', -- medical_bill, diagnostic_report, prescription, discharge_summary, denial_letter, pre_auth, other
    storage_path TEXT NOT NULL,
    mime_type TEXT NOT NULL,
    file_size INTEGER NOT NULL,
    page_count INTEGER DEFAULT 1,
    processing_status TEXT NOT NULL DEFAULT 'pending', -- pending, extracting, processed, failed
    extracted_text TEXT,
    extracted_metadata TEXT, -- JSON string of structured entities (dates, amounts, codes, providers)
    error_message TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (claim_id) REFERENCES claims(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_documents_claim_id ON documents(claim_id);

-- 3. Findings Table
CREATE TABLE IF NOT EXISTS findings (
    id TEXT PRIMARY KEY,
    claim_id TEXT NOT NULL,
    category TEXT NOT NULL, -- missing_evidence, cross_document_inconsistency, document_integrity, rejection_analysis, extracted_fact, recommended_action
    severity TEXT NOT NULL DEFAULT 'info', -- info, low, medium, high, critical
    title TEXT NOT NULL,
    explanation TEXT NOT NULL,
    supporting_document_ids TEXT, -- JSON array of document IDs
    evidence_reference TEXT, -- quotes, page numbers, or field names
    confidence REAL DEFAULT 1.0,
    reviewer_status TEXT NOT NULL DEFAULT 'unreviewed', -- unreviewed, confirmed, dismissed, edited
    reviewer_comment TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (claim_id) REFERENCES claims(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_findings_claim_id ON findings(claim_id);
CREATE INDEX IF NOT EXISTS idx_findings_category ON findings(category);
CREATE INDEX IF NOT EXISTS idx_findings_severity ON findings(severity);

-- 4. Appeals Table
CREATE TABLE IF NOT EXISTS appeals (
    id TEXT PRIMARY KEY,
    claim_id TEXT NOT NULL,
    appeal_title TEXT NOT NULL,
    draft_content TEXT NOT NULL,
    structured_sections TEXT, -- JSON string of sections: header, summary, grounds, evidence_table, requested_relief
    included_finding_ids TEXT, -- JSON array of finding IDs used in this draft
    approval_status TEXT NOT NULL DEFAULT 'draft', -- draft, pending_approval, approved, rejected
    reviewer_notes TEXT,
    approved_by TEXT,
    approved_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (claim_id) REFERENCES claims(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_appeals_claim_id ON appeals(claim_id);

-- 5. Analysis Runs Table
CREATE TABLE IF NOT EXISTS analysis_runs (
    id TEXT PRIMARY KEY,
    claim_id TEXT NOT NULL,
    processing_status TEXT NOT NULL DEFAULT 'completed', -- running, completed, failed
    analysis_mode TEXT NOT NULL DEFAULT 'rule_based', -- rule_based, ai_assisted, hybrid
    readiness_score REAL NOT NULL DEFAULT 0.0, -- 0 to 100
    score_breakdown TEXT, -- JSON string: { evidence_completeness, consistency_score, rejection_match_score, integrity_score, summary }
    error_message TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (claim_id) REFERENCES claims(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_analysis_runs_claim_id ON analysis_runs(claim_id);
